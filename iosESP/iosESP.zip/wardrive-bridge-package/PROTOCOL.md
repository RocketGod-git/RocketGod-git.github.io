# iosESP protocol v1.1

## GATT

No encryption or authentication flags. One phone connection per board.

| Role | UUID | Properties |
|---|---|---|
| Service | `47686F73-7445-5350-4272-696467655376` | primary, advertised |
| RX (phone → board) | `0147686F-7374-4553-5042-726964675852` | write, write without response |
| TX (board → phone) | `0247686F-7374-4553-5042-726964675854` | notify |
| CTRL (phone → board) | `0347686F-7374-4553-5042-72694C525443` | write, write without response |

The scan response carries the name `iosESP-XXXX` (last two bytes of the BLE address).

## Frames

12-byte header, then payload. Little-endian.

| Offset | Size | Field |
|---|---|---|
| 0 | 1 | `0x47` |
| 1 | 1 | `0x42` |
| 2 | 1 | version `0x01` |
| 3 | 1 | type: 1 CMD, 2 ACK, 3 DATA, 4 END, 5 ERR |
| 4 | 1 | status |
| 5 | 1 | flags (CMD: `0x01` first, `0x02` more) |
| 6 | 4 | command id |
| 10 | 2 | payload length |
| 12 | n | payload |

- Each command is one CMD frame. The board replies with an ACK carrying the same id.
- Output is text in DATA frames sized to the MTU. Join payloads in order and split on `\n`.
- Unframed text written to RX or CTRL is also accepted as a command.

## Commands

| Command | Effect |
|---|---|
| contains `stop` | stop scanning, send `WD:END` |
| contains `caps` | send `WD:CAPS` |
| anything else, e.g. `wdstream start -wifi` | start scanning |
| `... -ch 1,6,11,36` | scan only these channels, starting at the next sweep |

- Without `-ch` the board scans every channel it supports.
- Unsupported channels are dropped. If none remain the board replies `WD:ERR reason=no_supported_channels`.
- The channel list resets to all supported channels on every connect and disconnect.
- Scanning also starts when the phone subscribes to TX.

## Output lines

Space-separated `key=value` pairs. Ignore unknown keys.

| Line | Sent |
|---|---|
| `WD:CAPS fw=1.1 chip=esp32c5 bands=2g,5g chans=1,6,11,36,...` | at scan start and on `caps` |
| `WD:BEGIN type=wifi interval=0 channel=auto` | scan started |
| `WD:PLAN chans=1,6,11` | at scan start and after `-ch` |
| `WD:AP ts=<ms> bssid=AA:BB:CC:DD:EE:FF ssid_hex=<hex> rssi=<dBm> ch=<n> auth=<token> hidden=<0\|1>` | per AP |
| `WD:STATUS aps=<n> scans=<n>` | after each sweep |
| `WD:END reason=stop` | scan stopped |
| `WD:ERR reason=<text>` | command refused |

- `ts`: milliseconds since boot.
- `ssid_hex`: SSID bytes as lower-case hex; empty with `hidden=1`.
- `ch` above 14 is 5 GHz (5000 + 5 × ch MHz).
- `auth`: `OPEN`, `WEP`, `WPA`, `WPA2`, `WPA3`, `WPA2_WPA3`, `UNKNOWN`.
- Firmware before 1.1 sends no `WD:CAPS` and ignores `-ch`.

## Scanning

- 2.4 GHz: active, driver default dwell.
- 5 GHz (ESP32-C5): passive, 120 ms per channel, limited to channels the country setting allows.
