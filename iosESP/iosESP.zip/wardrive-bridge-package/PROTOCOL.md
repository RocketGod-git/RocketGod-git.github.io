# WardriveESP protocol v1.6

The board speaks one text protocol over two transports: Bluetooth LE (below) and USB (1.6+, see "USB").

## GATT

No encryption or authentication flags. One phone connection per board.

| Role | UUID | Properties |
|---|---|---|
| Service | `47686F73-7445-5350-4272-696467655376` | primary, advertised |
| RX (phone → board) | `0147686F-7374-4553-5042-726964675852` | write, write without response |
| TX (board → phone) | `0247686F-7374-4553-5042-726964675854` | notify |
| CTRL (phone → board) | `0347686F-7374-4553-5042-72694C525443` | write, write without response |
| OTA (phone → board) | `0447686F-7374-4553-5042-72694F544144` | write without response (firmware image bytes, 1.2+) |

The advertisement carries the service UUID. The scan response carries the name `WardriveESP-XXXX` (last two bytes
of the BLE address). Firmware before 1.6.1 advertised `iosESP-XXXX` (a bare `iosESP` before 1.1); apps should find
boards by the service UUID and accept both names.

### Status beacon (1.6.5+)

Every phone nearby can see every board, linked or not, and who has it.

- **Free board**: advertises the service UUID, connectable, exactly as before. The scan response carries the name and
  bytes 0-8 of the status below.
- **Linked board**: a board only takes one phone, so while linked it advertises non-connectable (scannable, about once
  a second) with the **status UUID** `0547686F-7374-4553-5042-726964675354` instead of the service UUID. Apps that
  predate 1.6.5 look for the service UUID only, so they never try to connect to a board that is taken. The scan
  response carries the status below, including the holder's nickname.

Status = manufacturer-specific data, company id `0xFFFF`, little-endian:

| Byte | Meaning |
|---|---|
| 0 | `W` (0x57) |
| 1 | flags: bit 0 linked, bit 1 scanning, bits 2-3 mode (0 Wi-Fi, 1 Bluetooth, 2 capture), bit 4 a USB host has a session, bit 5 GPS, bit 6 updating, bit 7 the holder is an iPhone |
| 2 | chip temperature, °C, signed (-128 = unknown) |
| 3-4 | Wi-Fi: APs in the last sweep. Bluetooth: devices in the last window. Capture: APs this session |
| 5 | firmware major << 4 \| minor |
| 6 | firmware patch |
| 7-8 | the two address bytes in the name (`WardriveESP-%02X%02X`), so a linked board can be named without its name in the advert |
| 9+ | linked boards only: the holder's nickname, UTF-8, up to 18 bytes (whole characters), empty when the app didn't say |

The status refreshes every 5 s when anything in it changes.

## Frames

12-byte header, then payload. Little-endian.

| Offset | Size | Field |
|---|---|---|
| 0 | 1 | `0x47` |
| 1 | 1 | `0x42` |
| 2 | 1 | version `0x01` |
| 3 | 1 | type: 1 CMD, 2 ACK, 3 DATA, 4 END, 5 ERR |
| 4 | 1 | status |
| 5 | 1 | flags (CMD: `0x01` first, `0x02` more) |
| 6 | 4 | command id |
| 10 | 2 | payload length |
| 12 | n | payload |

- Each command is one CMD frame. The board replies with an ACK carrying the same id.
- Output is text in DATA frames sized to the MTU. Join payloads in order and split on `\n`.
- Unframed text written to RX or CTRL is also accepted as a command.

## Commands

The first word picks the command. Replies to terminal commands are plain text lines.

| Command | Effect |
|---|---|
| `wdstream start -wifi [-ch 1,6,11,36]` | start scanning; `-ch` limits this board to those channels from the next sweep |
| `wdstream stop`, `stop` | stop scanning, send `WD:END`; from 1.6.3 records still queued on the board are sent before it |
| `start` | start scanning in the board's current mode |
| `bt on`, `bt off`, `bt` | scan Bluetooth instead of Wi-Fi, back to Wi-Fi, or show the mode (1.3+) |
| `cap on`, `cap off`, `cap` | passive capture (handshakes, PMKIDs, clients) instead of Wi-Fi, back to Wi-Fi, or show the mode (1.5+) |
| `caps` | send `WD:CAPS` |
| `help` | list the terminal commands |
| `info` | firmware, chip, MAC, uptime, last reset, memory, flash, slot |
| `status` | scanning state, sweeps, APs last sweep, channels, MTU |
| `link` | what the board is connected to: phone address, how long, signal, link timing, last drop (1.6.4+) |
| `drop` | disconnect the phone so another one can link (1.6.4+) |
| `iam a <nickname>`, `iam i <nickname>` | the app says who it is (`a` Android, `i` iPhone), once after linking. No reply. Shown by `link` and in the status beacon (1.6.5+) |
| `ch`, `ch 1,6,11`, `ch all` | show, set or reset this board's channels |
| `led`, `led alert <pattern> <rrggbb> [seconds] [label]`, `led test`, `led off` | LED ring (boards with `led=` in `WD:CAPS`, 1.6.6+): plays a pattern in a color for a few seconds, then returns to the idle breath; `off` returns to idle now, `led` alone shows the state. Replies `led <pattern> <rrggbb> <seconds>s`. Patterns (default color, seconds): `police` red/blue chase, color ignored (8); `heartbeat` lub-dub (FF4FA3, 6); `strobe` hard flashes (FF3B30, 6); `spin` a circling comet (00C8FF, 6); `pulse` a fast breath (FFC800, 6); `sparkle` flares that fade (FFAA00, 3); `rainbow` the swirl the ring plays when a phone or USB host links (2). A new alert replaces the one playing; alerts take priority over the link swirl. Older names still work: `led police|drone|notable|capture|storm [rrggbb] [seconds]`. On a board with a screen (`disp=` in `WD:CAPS`) the alert also takes over the screen; `label` is one word of up to 12 characters shown there (`_` for a space, shown in capitals), defaulting to the pattern name |
| `led bright <0-100>`, `led stealth on\|off` | ring brightness (default 40), stealth keeps the ring dark; both saved on the board (1.6.6+) |
| `screen` | boards with `disp=`: the frame on the screen as `WD:SCREEN page=<0-3> x=<0\|64> <128 hex digits>` lines, 64 column bytes each, bit 0 the top pixel of the 8-pixel page (1.6.6+) |
| `reboot` | restart the board; from 1.6.3 it stops scanning and sends queued records first |
| `ota begin <size>`, `ota end`, `ota abort` | firmware update (below) |

Anything else gets `unknown command '<word>'` followed by the help list.

- Without `-ch` the board scans every channel it supports.
- Unsupported channels are dropped. If none remain the board replies `WD:ERR reason=no_supported_channels`.
- The channel list resets to all supported channels on every connect and disconnect, unless another host is
  still linked (1.6+).
- Scanning also starts when the phone subscribes to TX. If a scan is already running for another host, the phone
  gets `WD:CAPS`, `WD:BOOT`, `WD:CRASH`, `WD:LINK`, `WD:MODE`, `WD:BEGIN` and `WD:PLAN` instead.

## Output lines

Space-separated `key=value` pairs. Ignore unknown keys.

| Line | Sent |
|---|---|
| `WD:CAPS fw=1.6.0 chip=esp32c5 bands=2g,5g ota=1 bt=1 gps=<0\|1> cap=1 usb=1 [board=<id> board_name=<name>] [led=ring<n>] [batt=1] [disp=128x32] link=<ble\|usb\|uart> chans=1,6,11,36,...` | at scan start, on `caps`, and when a host joins a running scan; `link` names the transport that line was sent on (1.6+). 1.6.6+, each key only when it applies: `board=` the board the firmware identified from its hardware (`crumb` Biscuit Crumb, `poltergeist` Rabbit Labs Poltergeist; absent on generic boards) with `board_name=` its display name, spaces as `_`; `led=ring<n>` the board drives an n-pixel LED ring (1 = a single LED) and takes `led` commands; `batt=1` it has a battery gauge, reported in `WD:HEALTH`; `disp=128x32` it has a status screen (see "Screen") |
| `WD:MODE mode=wifi\|bt\|cap` | at scan start and when the mode changes (1.3+; `cap` 1.5+) |
| `WD:BOOT fw= slot= image= reset= boots= prev_fw= prev_stage= rolled_back=` | at scan start and in `info` (1.2.2+) |
| `WD:CRASH kind=panic\|stack_overflow reason= task= pc=0x… core= up_ms= last= ch= heap_min=` | at scan start and in `info` after a crash or watchdog reset (1.5.3+); `reason=unrecorded` when no record survived |
| `WD:LINK conns=<n> mtu=<n> prev_disc=<0x… \| none> prev_disc_ago=<s>` | at scan start (1.5.3+): links since boot and why the last one ended |
| `WD:CONN itvl_ms=<n> latency=<n> timeout_ms=<n> status=<n>` | BLE only, when the link timing changes (1.6.2+). After connecting, the board asks for a 30-50 ms interval with a 5 s supervision timeout (15-30 ms during a firmware update); the phone may keep its own |
| `WD:HEALTH up=<s> heap= heap_min= largest= stack_scan= stack_bt= stack_cap= stack_gps= stack_usb= stack_health= low_stack= mtu= last= [batt=<%> batt_mv=<mV>]` | every 15 s while a host is linked (1.5.3+; `stack_usb` 1.6+; `batt` on boards with a gauge, 1.6.6+); `stack_*` = least bytes ever left (-1 = not running) |
| `WD:BEGIN type=wifi interval=0 channel=auto` | scan started |
| `WD:PLAN chans=1,6,11` | at scan start and after `-ch` |
| `WD:AP ts=<ms> bssid=AA:BB:CC:DD:EE:FF ssid_hex=<hex> rssi=<dBm> ch=<n> auth=<token> hidden=<0\|1>` | per AP |
| `WD:STATUS aps=<n> scans=<n>` | after each Wi-Fi sweep; `aps` = APs heard in that sweep |
| `WD:BT ts=<ms> mac=AA:BB:CC:DD:EE:FF type=<public\|random> rssi=<dBm> name_hex=<hex> mfg=<id> conn=<0\|1>` | per Bluetooth device, about once per window (1.3+) |
| `WD:STATUS bt=<n> scans=<n> dropped=<n>` | after each Bluetooth window; `bt` = devices reported in it |
| `WD:GPS ts=<ms> lat=<deg> lon=<deg> alt=<m> fix=1 sats=<n>` | per GPS fix, at most once a second (1.4+); `alt` omitted when the sentence carried none |
| `WD:HS ts=<ms> bssid=… sta=… ssid_hex=<hex> ch=<n> rssi=<dBm> hc22000=WPA*02*…*00` | per captured WPA 4-way handshake (1.5+) |
| `WD:PMKID ts=<ms> bssid=… sta=… ssid_hex=<hex> ch=<n> rssi=<dBm> pmkid=<32 hex>` | per captured RSN PMKID (1.5+) |
| `WD:CLIENT ts=<ms> mac=… bssid=… rssi=<dBm> ch=<n>` | per station seen in capture mode, once per session (1.5+); `bssid` empty when unknown (probe-request) |
| `WD:STATUS cap=1 aps=<n> hs=<n> pmkid=<n> clients=<n> data=<n> scans=<n> dropped=<n>` | after each capture sweep (1.5+) |
| `WD:END reason=stop` | scan stopped |
| `WD:USB pong`, `WD:USB bye reason=<host\|idle>` | USB session replies (1.6+, see "USB") |
| `WD:ERR reason=<text>` | command refused |

- `ts`: milliseconds since boot.
- `ssid_hex`: SSID bytes as lower-case hex; empty with `hidden=1`.
- `ch` above 14 is 5 GHz (5000 + 5 × ch MHz).
- `auth`: `OPEN`, `WEP`, `WPA`, `WPA2`, `WPA3`, `WPA2_WPA3`, `UNKNOWN`.
- Firmware before 1.1 sends no `WD:CAPS` and ignores `-ch`.

## Firmware update (1.2+)

Boards that send `ota=1` in `WD:CAPS` accept a new app image over BLE, and from 1.6 over a USB session (see "USB").

1. Phone sends `ota begin <size>` (bytes of the app image, e.g. `wardrive_bridge.bin`). The board stops scanning
   and replies `WD:OTA ready window=<bytes> size=<bytes>`, or `WD:OTA error=<reason>`. `size` (1.6.3+) is the
   receive buffer the board could allocate; `window` is sized to fit it, so always use the `window` sent. More
   fields may follow in later versions.
2. Phone writes the image in order to the OTA characteristic, never more than `window` bytes past the last ack.
3. The board replies `WD:OTA ack=<bytes written>` every 4 KB (every `window / 2` when `window` is under 8 KB) and
   when the whole image is written.
4. After `ack=<size>`, phone sends `ota end`. The board checks the image, replies `WD:OTA done` and restarts into it.
5. `ota abort` or a disconnect cancels. The running firmware is untouched until `WD:OTA done`.

`WD:OTA` lines go only to the host that sent `ota begin`. One update runs at a time; a second `ota begin` gets
`WD:OTA error=busy`.

From 1.6.3 the board sends the records it still holds (`WD:AP`, `WD:BT`, `WD:CLIENT`, `WD:HS`, `WD:PMKID`) and
`WD:END` before `WD:OTA ready`. A handshake still waiting for its second message is not reported. Phones should send
`stop` and read until `WD:END` (or about 2 s) before `ota begin` or `reboot`, which also covers older firmware.

`WD:OTA error=no_memory`: the board couldn't allocate a receive buffer. Before 1.6.3 this happens on a board that has
been scanning for hours (the 24 KB buffer needs one contiguous block). Send `reboot`, wait for the board to link
again, and retry.

New firmware that fails to bring up Wi-Fi and BLE is rolled back on the next boot. From 1.2.2 a board on trial
firmware that isn't up within 30 s restarts itself, so the rollback happens without a power-cycle.

`WD:BOOT` fields: `slot` running app slot; `image` its state at boot (`trial` = first boot after an update,
`confirmed`, …); `reset` last reset cause (`power_on`, `software`, `crash`, `watchdog`, `brownout`, …); `boots` boot
count; `prev_fw` / `prev_stage` how far the previous boot got (`storage`, `wifi`, `bluetooth`, `ready`,
`boot_watchdog`); `rolled_back` the slot of an update that was rolled back, or `none`.

## USB (1.6+)

Boards with `usb=1` in `WD:CAPS` speak the same protocol over their USB port. Two ports are served, and a host can
use whichever one the board exposes:

| Port | Boards | Host sees |
|---|---|---|
| USB-Serial-JTAG | native USB (ESP32-C3/C5/C6/S3 wired straight to the connector) | CDC-ACM, `303a:1001` |
| UART0 | boards with a USB-UART bridge | the bridge (CP210x `10c4:ea60`, CH34x `1a86:7523` / `1a86:55d4`, ...) |

UART0 runs at 115200 baud, 8N1, no flow control (the console rate). The USB-Serial-JTAG port ignores the baud rate.

### Lines

- Text only, no binary frames: one command per line from the host, one output line per line from the board.
  Lines end in `\n`; a `\r` before it is ignored. Command lines are at most 240 bytes.
- The board sends exactly the lines it sends over BLE (every `WD:` line and every terminal reply), with no 12-byte
  frame header, no CMD/ACK ids and no MTU chunking.
- The only binary data is a firmware image during an update (below), and only after `WD:OTA ready`.

### Session

The port starts in log mode: ESP-IDF log text and boot messages, no protocol output. In log mode the board only
reacts to `wdusb hello`.

| Host sends | Board does |
|---|---|
| `wdusb hello` | opens a session on that port and replies with `WD:CAPS ... link=usb` (or `link=uart`), `WD:BOOT`, `WD:CRASH`, `WD:LINK`, `WD:MODE`, `WD:BEGIN`, `WD:PLAN`; starts scanning if it wasn't |
| `wdusb ping` | `WD:USB pong` |
| `wdusb bye` | `WD:USB bye reason=host`, then back to log mode |
| any other line | runs it as a command (same table as BLE) |

- From the hello on, that port carries only protocol lines; log output is held off it (and still goes to the other
  port when that one is in log mode).
- The session ends and the port returns to log mode after 60 s with nothing received (`WD:USB bye reason=idle`),
  on `wdusb bye`, when a native USB host disconnects or stops reading for 5 s, and on reboot. Send `wdusb ping`
  (or any line) at least every 20 s to keep it open.
- Until the session opens, expect boot and log text on the port. Send `wdusb hello` about once a second until a
  `WD:CAPS` line comes back, and skip any line that doesn't parse (a rare log line can still appear mid-session).
- `WD:CAPS` and the other start lines can arrive more than once; treat them as current state.

Everything a BLE host gets also arrives over a USB session: every `WD:` line (`WD:AP`, `WD:BT`, `WD:CLIENT`,
`WD:HS`, `WD:PMKID`, `WD:GPS`, `WD:STATUS`, `WD:HEALTH` every 15 s, `WD:MODE`/`BEGIN`/`PLAN`/`END`, `WD:CONN` excepted
as it is BLE-only) and every reply to a command.

### USB holds the board (1.6.6+)

Opening a session takes the board off Bluetooth: a linked phone is disconnected, then Bluetooth is switched off
entirely (host stopped, controller freed), so Wi-Fi has the radio to itself with no Wi-Fi/Bluetooth coexistence.
With Bluetooth off there is no advertising and no
status beacon: phones nearby simply stop seeing the board. Choosing the Bluetooth scan (`bt on`) during a session
brings Bluetooth back for the scan, and while it runs the board sends the linked-board status beacon (`STATUS_UUID`,
the USB flag set, the last holder's nickname) but takes no phone. Scanning, mode and channels carry on across the
switch. When the last session ends (`wdusb bye`, idle, unplug) Bluetooth comes back, the board advertises normally
again and phones relink by themselves.

### Several hosts

Before 1.6.6 a BLE phone and USB sessions could be active at the same time; from 1.6.6 a USB session ends the
Bluetooth link (above), and several USB ports can still be open together. Every host gets the full output stream, including
replies to commands another host sent. Commands from any host control the board and the last one wins (mode,
channels, start/stop). Connecting or disconnecting a host resets mode and channels only when no other host is
linked. Scanning stops when the last host goes away.

### Firmware update over USB

Same flow as BLE, with the image sent on the session port instead of the OTA characteristic:

1. Host sends `ota begin <size>`. On `WD:OTA ready window=<bytes> size=<bytes>` the next `<size>` bytes on the port are image
   data, not lines.
2. Host writes the raw image, never more than `window` bytes past the last `WD:OTA ack`. UART0 has no flow control,
   so the window is required there.
3. After `WD:OTA ack=<size>`, host sends `ota end` as a line. `WD:OTA done`, then the board restarts (a native USB
   port re-enumerates).

If no image byte arrives for 10 s the update is aborted and the port goes back to reading lines. Ending the
session aborts an update that port started.

### Download mode

The USB protocol never touches the reset lines. Flashing tools reset into the ROM bootloader with DTR/RTS exactly
as before. To talk to the firmware without resetting it, open the port with DTR and RTS both deasserted and leave
RTS deasserted (on native USB, RTS asserted with DTR deasserted resets the chip; on bridge boards RTS drives EN).

### Telling boards apart

`303a:1001` and the common UART bridges are shared by every ESP32 firmware. A board is WardriveESP when it answers
`wdusb hello` with a `WD:CAPS` line carrying `usb=1`.

## Bluetooth (1.3+)

Boards with `bt=1` in `WD:CAPS` can scan Bluetooth LE instead of Wi-Fi. `bt on` stops Wi-Fi scanning and starts
BLE discovery in 10 s windows with duplicate filtering, so each device is reported about once per window. The board
keeps its link to the phone while it scans. The mode resets to Wi-Fi on every connect and disconnect.

- `mac`: the address as broadcast, most significant byte first. `type` says whether it is a public or random address.
- `name_hex`: the advertised name as lower-case hex, empty when none was heard.
- `mfg`: the Bluetooth SIG company id from manufacturer data, as 4 hex digits, or empty.
- `conn`: 1 when the advertisement is connectable.

## GPS (1.4+)

Boards with `gps=1` in `WD:CAPS` have a UART NMEA receiver and stream fixes as `WD:GPS` lines. The phone uses
the board's position as a location source when its own fix is stale or was never granted, so a wardrive is never
left without coordinates. The capability is runtime-detected: a board only advertises `gps=1`, and only sends
`WD:GPS`, once it has parsed a valid fix — so a board with no GPS wired up never claims it.

- `lat` / `lon`: signed decimal degrees (south and west negative).
- `alt`: meters above sea level; omitted when the NMEA sentence carried no altitude.
- `fix`: always `1` (the board only emits a line once it has a valid fix).
- `sats`: satellites in use, when reported.
- Emitted at most once a second while connected. The board reads `$??GGA` and `$??RMC` sentences (any talker id).
- UART pins and baud are set in `menuconfig` under *WardriveESP* (default UART1, RX GPIO 4, 9600 baud, TX disabled).
- From 1.6.6, when the configured pin stays silent for the first 2.5 s, an ESP32-C6 also listens (input only) on
  GPIO 2 at 9600 baud and uses it if a module streams NMEA there. A pin the board's own hardware uses is skipped.

## Capture (1.5+)

Boards with `cap=1` in `WD:CAPS` can do **passive** 802.11 promiscuous capture instead of Wi-Fi scanning. `cap on`
puts the radio in monitor mode and camps each planned channel ~300 ms, reporting three kinds of artifact. It is
**receive-only** — the board never transmits, deauthenticates or injects, so an artifact appears only when a client
associates (or probes) on its own. For authorized security research / your own networks. The mode resets to Wi-Fi on
every connect and disconnect, same as Bluetooth.

Capture is a **superset of a Wi-Fi scan** (1.5.1+): it also emits `WD:AP` from the beacons and probe-responses it
hears (BSSID, SSID, RSSI, channel, auth parsed from the RSN/WPA IEs, hidden flag), reporting an AP the first time it
is seen and again when a later sighting is notably stronger. So a board left in capture mode still fills the wardrive
map and WiGLE CSV with APs — it just adds handshakes, PMKIDs and clients on top. (It is passive beacon listening, not
active probing, so a plain scan still edges it slightly on probe-only APs and channel-cycle speed.)

- `WD:HS` carries a full hashcat-22000 line in `hc22000` (`WPA*02*MIC*AP*STA*ESSID*ANONCE*EAPOL*00`): the board pairs
  the handshake's M1 ANonce with the M2 by replay counter and zeroes the MIC field in the EAPOL copy, so the phone can
  append the line to a `.hc22000` hashlist as-is.
- `WD:PMKID` carries the RSN PMKID an AP puts in EAPOL-Key M1 (only some APs do). Build `WPA*01*PMKID*AP*STA*ESSID***`.
- `WD:CLIENT` is a station MAC seen associating, probing or in a data frame, with its BSSID when known. Reported once
  per device per capture session.
- `bssid`/`sta`: most significant byte first. `ssid_hex`: the ESSID the board learned from a beacon/probe-response for
  that BSSID, as lower-case hex; empty when it hasn't heard one yet.
- Each artifact is deduped for the session on the board (handshake by MIC, PMKID by value, client by MAC); the phone
  should dedup again by `pmkid`/MIC and by client MAC.
- Longer per-channel dwell than a scan, because handshakes are opportunistic. Set `ch 1,6,11` to camp fewer channels.

## Scanning

- 2.4 GHz: channels 1–14, active, driver default dwell.
- 5 GHz (ESP32-C5): passive, 120 ms per channel. From 1.5.5 `chans` lists every 5 GHz channel the radio tunes —
  36–64, 100–144 and 149–177 — receive-only: passive scan in Wi-Fi mode, promiscuous RX in capture mode, no probes.
- The board requests its maximum allowed TX power at start (1.5+) so active-scan probe requests reach farther APs;
  the driver clamps to the chip and country ceiling. RX sensitivity is fixed hardware — there is no RX-power setting.

## LED alerts (1.6.6+)

The app picks a pattern per kind of alert and passes the alert banner's category color:

| App alert | Pattern |
|---|---|
| Police / fire / EMS responders | `police` |
| Adult toys, health devices | `heartbeat` |
| Attack tools (Flipper, RF and hacking gadgets), gunshot sensors | `strobe` |
| Trackers and Find My, drones, Remote ID | `spin` |
| Cameras (Flock, ALPR, CCTV, body cams, spy cams, glasses, home cams) | `pulse` |
| Captured handshake / PMKID (gold), cracked password (green) | `sparkle` |
| Celebrations | `rainbow` |

Example: `led alert heartbeat FF4FA3 5`, or with a screen label `led alert spin 00C8FF 6 DRONE` /
`led alert heartbeat FF4FA3 5 ADULT_TOY`. Boards without `led=` in `WD:CAPS` reply `no LED ring on this board`, so the
app only sends these to boards that report a ring.

## Screen (1.6.6+)

Boards with `disp=128x32` in `WD:CAPS` (the Rabbit Labs Poltergeist) run a status screen on their own; the app sends
nothing for it beyond what it already sends:

- Boot: the WardriveESP wordmark, firmware version and board name.
- Dashboard: who holds the board (`BT` or `USB` plus the `iam` nickname) and uptime; the number of different APs seen
  since boot in large digits with a `+N new` count for the last 10 s; mode and channel (or Bluetooth devices); the
  capture count; a strip of per-channel activity (2.4 GHz left, 5 GHz right) with a mark under the channel being scanned.
- `led alert ...` (and `led <pattern> ...`) also shows a full-screen banner with the label, flashing in step with the
  LED, for the alert's seconds; `led off` ends it. A phone or USB host linking shows `LINKED` for 1.5 s.
- `led stealth on` turns the screen off as well. The picture moves by a pixel every 3 minutes and dims after 30 s with
  no host, so it doesn't burn in.
- `screen` returns the frame being shown (see "Commands").
