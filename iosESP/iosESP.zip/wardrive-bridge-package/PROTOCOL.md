# iosESP protocol v1.3

## GATT

No encryption or authentication flags. One phone connection per board.

| Role | UUID | Properties |
|---|---|---|
| Service | `47686F73-7445-5350-4272-696467655376` | primary, advertised |
| RX (phone → board) | `0147686F-7374-4553-5042-726964675852` | write, write without response |
| TX (board → phone) | `0247686F-7374-4553-5042-726964675854` | notify |
| CTRL (phone → board) | `0347686F-7374-4553-5042-72694C525443` | write, write without response |
| OTA (phone → board) | `0447686F-7374-4553-5042-72694F544144` | write without response (firmware image bytes, 1.2+) |

The scan response carries the name `iosESP-XXXX` (last two bytes of the BLE address).

## Frames

12-byte header, then payload. Little-endian.

| Offset | Size | Field |
|---|---|---|
| 0 | 1 | `0x47` |
| 1 | 1 | `0x42` |
| 2 | 1 | version `0x01` |
| 3 | 1 | type: 1 CMD, 2 ACK, 3 DATA, 4 END, 5 ERR |
| 4 | 1 | status |
| 5 | 1 | flags (CMD: `0x01` first, `0x02` more) |
| 6 | 4 | command id |
| 10 | 2 | payload length |
| 12 | n | payload |

- Each command is one CMD frame. The board replies with an ACK carrying the same id.
- Output is text in DATA frames sized to the MTU. Join payloads in order and split on `\n`.
- Unframed text written to RX or CTRL is also accepted as a command.

## Commands

The first word picks the command. Replies to terminal commands are plain text lines.

| Command | Effect |
|---|---|
| `wdstream start -wifi [-ch 1,6,11,36]` | start scanning; `-ch` limits this board to those channels from the next sweep |
| `wdstream stop`, `stop` | stop scanning, send `WD:END` |
| `start` | start scanning in the board's current mode |
| `bt on`, `bt off`, `bt` | scan Bluetooth instead of Wi-Fi, back to Wi-Fi, or show the mode (1.3+) |
| `caps` | send `WD:CAPS` |
| `help` | list the terminal commands |
| `info` | firmware, chip, MAC, uptime, last reset, memory, flash, slot |
| `status` | scanning state, sweeps, APs last sweep, channels, MTU, LED |
| `ch`, `ch 1,6,11`, `ch all` | show, set or reset this board's channels |
| `led on`, `led off` | status LED, saved across reboots |
| `reboot` | restart the board |
| `ota begin <size>`, `ota end`, `ota abort` | firmware update (below) |

Anything else gets `unknown command '<word>'` followed by the help list.

- Without `-ch` the board scans every channel it supports.
- Unsupported channels are dropped. If none remain the board replies `WD:ERR reason=no_supported_channels`.
- The channel list resets to all supported channels on every connect and disconnect.
- Scanning also starts when the phone subscribes to TX.

## Output lines

Space-separated `key=value` pairs. Ignore unknown keys.

| Line | Sent |
|---|---|
| `WD:CAPS fw=1.3 chip=esp32c5 bands=2g,5g ota=1 bt=1 chans=1,6,11,36,...` | at scan start and on `caps` |
| `WD:MODE mode=wifi\|bt` | at scan start and when the mode changes (1.3+) |
| `WD:BOOT fw= slot= image= reset= boots= prev_fw= prev_stage= rolled_back=` | at scan start and in `info` (1.2.2+) |
| `WD:BEGIN type=wifi interval=0 channel=auto` | scan started |
| `WD:PLAN chans=1,6,11` | at scan start and after `-ch` |
| `WD:AP ts=<ms> bssid=AA:BB:CC:DD:EE:FF ssid_hex=<hex> rssi=<dBm> ch=<n> auth=<token> hidden=<0\|1>` | per AP |
| `WD:STATUS aps=<n> scans=<n>` | after each Wi-Fi sweep; `aps` = APs heard in that sweep |
| `WD:BT ts=<ms> mac=AA:BB:CC:DD:EE:FF type=<public\|random> rssi=<dBm> name_hex=<hex> mfg=<id> conn=<0\|1>` | per Bluetooth device, about once per window (1.3+) |
| `WD:STATUS bt=<n> scans=<n> dropped=<n>` | after each Bluetooth window; `bt` = devices reported in it |
| `WD:END reason=stop` | scan stopped |
| `WD:ERR reason=<text>` | command refused |

- `ts`: milliseconds since boot.
- `ssid_hex`: SSID bytes as lower-case hex; empty with `hidden=1`.
- `ch` above 14 is 5 GHz (5000 + 5 × ch MHz).
- `auth`: `OPEN`, `WEP`, `WPA`, `WPA2`, `WPA3`, `WPA2_WPA3`, `UNKNOWN`.
- Firmware before 1.1 sends no `WD:CAPS` and ignores `-ch`.

## Firmware update (1.2+)

Boards that send `ota=1` in `WD:CAPS` accept a new app image over BLE.

1. Phone sends `ota begin <size>` (bytes of the app image, e.g. `wardrive_bridge.bin`). The board stops scanning
   and replies `WD:OTA ready window=<bytes>`, or `WD:OTA error=<reason>`.
2. Phone writes the image in order to the OTA characteristic, never more than `window` bytes past the last ack.
3. The board replies `WD:OTA ack=<bytes written>` every 4 KB and when the whole image is written.
4. After `ack=<size>`, phone sends `ota end`. The board checks the image, replies `WD:OTA done` and restarts into it.
5. `ota abort` or a disconnect cancels. The running firmware is untouched until `WD:OTA done`.

New firmware that fails to bring up Wi-Fi and BLE is rolled back on the next boot. From 1.2.2 a board on trial
firmware that isn't up within 30 s restarts itself, so the rollback happens without a power-cycle.

`WD:BOOT` fields: `slot` running app slot; `image` its state at boot (`trial` = first boot after an update,
`confirmed`, …); `reset` last reset cause (`power_on`, `software`, `crash`, `watchdog`, `brownout`, …); `boots` boot
count; `prev_fw` / `prev_stage` how far the previous boot got (`storage`, `led`, `wifi`, `bluetooth`, `ready`,
`boot_watchdog`); `rolled_back` the slot of an update that was rolled back, or `none`.

## Bluetooth (1.3+)

Boards with `bt=1` in `WD:CAPS` can scan Bluetooth LE instead of Wi-Fi. `bt on` stops Wi-Fi scanning and starts
BLE discovery in 10 s windows with duplicate filtering, so each device is reported about once per window. The board
keeps its link to the phone while it scans. The mode resets to Wi-Fi on every connect and disconnect.

- `mac`: the address as broadcast, most significant byte first. `type` says whether it is a public or random address.
- `name_hex`: the advertised name as lower-case hex, empty when none was heard.
- `mfg`: the Bluetooth SIG company id from manufacturer data, as 4 hex digits, or empty.
- `conn`: 1 when the advertisement is connectable.

## Scanning

- 2.4 GHz: active, driver default dwell.
- 5 GHz (ESP32-C5): passive, 120 ms per channel, limited to channels the country setting allows.
