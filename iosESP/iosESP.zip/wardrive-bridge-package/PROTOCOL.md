# iosESP protocol v1.5

## GATT

No encryption or authentication flags. One phone connection per board.

| Role | UUID | Properties |
|---|---|---|
| Service | `47686F73-7445-5350-4272-696467655376` | primary, advertised |
| RX (phone → board) | `0147686F-7374-4553-5042-726964675852` | write, write without response |
| TX (board → phone) | `0247686F-7374-4553-5042-726964675854` | notify |
| CTRL (phone → board) | `0347686F-7374-4553-5042-72694C525443` | write, write without response |
| OTA (phone → board) | `0447686F-7374-4553-5042-72694F544144` | write without response (firmware image bytes, 1.2+) |

The scan response carries the name `iosESP-XXXX` (last two bytes of the BLE address).

## Frames

12-byte header, then payload. Little-endian.

| Offset | Size | Field |
|---|---|---|
| 0 | 1 | `0x47` |
| 1 | 1 | `0x42` |
| 2 | 1 | version `0x01` |
| 3 | 1 | type: 1 CMD, 2 ACK, 3 DATA, 4 END, 5 ERR |
| 4 | 1 | status |
| 5 | 1 | flags (CMD: `0x01` first, `0x02` more) |
| 6 | 4 | command id |
| 10 | 2 | payload length |
| 12 | n | payload |

- Each command is one CMD frame. The board replies with an ACK carrying the same id.
- Output is text in DATA frames sized to the MTU. Join payloads in order and split on `\n`.
- Unframed text written to RX or CTRL is also accepted as a command.

## Commands

The first word picks the command. Replies to terminal commands are plain text lines.

| Command | Effect |
|---|---|
| `wdstream start -wifi [-ch 1,6,11,36]` | start scanning; `-ch` limits this board to those channels from the next sweep |
| `wdstream stop`, `stop` | stop scanning, send `WD:END` |
| `start` | start scanning in the board's current mode |
| `bt on`, `bt off`, `bt` | scan Bluetooth instead of Wi-Fi, back to Wi-Fi, or show the mode (1.3+) |
| `cap on`, `cap off`, `cap` | passive capture (handshakes, PMKIDs, clients) instead of Wi-Fi, back to Wi-Fi, or show the mode (1.5+) |
| `caps` | send `WD:CAPS` |
| `help` | list the terminal commands |
| `info` | firmware, chip, MAC, uptime, last reset, memory, flash, slot |
| `status` | scanning state, sweeps, APs last sweep, channels, MTU, LED |
| `ch`, `ch 1,6,11`, `ch all` | show, set or reset this board's channels |
| `led on`, `led off` | status LED, saved across reboots |
| `reboot` | restart the board |
| `ota begin <size>`, `ota end`, `ota abort` | firmware update (below) |

Anything else gets `unknown command '<word>'` followed by the help list.

- Without `-ch` the board scans every channel it supports.
- Unsupported channels are dropped. If none remain the board replies `WD:ERR reason=no_supported_channels`.
- The channel list resets to all supported channels on every connect and disconnect.
- Scanning also starts when the phone subscribes to TX.

## Output lines

Space-separated `key=value` pairs. Ignore unknown keys.

| Line | Sent |
|---|---|
| `WD:CAPS fw=1.5 chip=esp32c5 bands=2g,5g ota=1 bt=1 gps=<0\|1> cap=1 chans=1,6,11,36,...` | at scan start and on `caps` |
| `WD:MODE mode=wifi\|bt\|cap` | at scan start and when the mode changes (1.3+; `cap` 1.5+) |
| `WD:BOOT fw= slot= image= reset= boots= prev_fw= prev_stage= rolled_back=` | at scan start and in `info` (1.2.2+) |
| `WD:BEGIN type=wifi interval=0 channel=auto` | scan started |
| `WD:PLAN chans=1,6,11` | at scan start and after `-ch` |
| `WD:AP ts=<ms> bssid=AA:BB:CC:DD:EE:FF ssid_hex=<hex> rssi=<dBm> ch=<n> auth=<token> hidden=<0\|1>` | per AP |
| `WD:STATUS aps=<n> scans=<n>` | after each Wi-Fi sweep; `aps` = APs heard in that sweep |
| `WD:BT ts=<ms> mac=AA:BB:CC:DD:EE:FF type=<public\|random> rssi=<dBm> name_hex=<hex> mfg=<id> conn=<0\|1>` | per Bluetooth device, about once per window (1.3+) |
| `WD:STATUS bt=<n> scans=<n> dropped=<n>` | after each Bluetooth window; `bt` = devices reported in it |
| `WD:GPS ts=<ms> lat=<deg> lon=<deg> alt=<m> fix=1 sats=<n>` | per GPS fix, at most once a second (1.4+); `alt` omitted when the sentence carried none |
| `WD:HS ts=<ms> bssid=… sta=… ssid_hex=<hex> ch=<n> rssi=<dBm> hc22000=WPA*02*…*00` | per captured WPA 4-way handshake (1.5+) |
| `WD:PMKID ts=<ms> bssid=… sta=… ssid_hex=<hex> ch=<n> rssi=<dBm> pmkid=<32 hex>` | per captured RSN PMKID (1.5+) |
| `WD:CLIENT ts=<ms> mac=… bssid=… rssi=<dBm> ch=<n>` | per station seen in capture mode, once per session (1.5+); `bssid` empty when unknown (probe-request) |
| `WD:STATUS cap=1 aps=<n> hs=<n> pmkid=<n> clients=<n> data=<n> scans=<n> dropped=<n>` | after each capture sweep (1.5+) |
| `WD:END reason=stop` | scan stopped |
| `WD:ERR reason=<text>` | command refused |

- `ts`: milliseconds since boot.
- `ssid_hex`: SSID bytes as lower-case hex; empty with `hidden=1`.
- `ch` above 14 is 5 GHz (5000 + 5 × ch MHz).
- `auth`: `OPEN`, `WEP`, `WPA`, `WPA2`, `WPA3`, `WPA2_WPA3`, `UNKNOWN`.
- Firmware before 1.1 sends no `WD:CAPS` and ignores `-ch`.

## Firmware update (1.2+)

Boards that send `ota=1` in `WD:CAPS` accept a new app image over BLE.

1. Phone sends `ota begin <size>` (bytes of the app image, e.g. `wardrive_bridge.bin`). The board stops scanning
   and replies `WD:OTA ready window=<bytes>`, or `WD:OTA error=<reason>`.
2. Phone writes the image in order to the OTA characteristic, never more than `window` bytes past the last ack.
3. The board replies `WD:OTA ack=<bytes written>` every 4 KB and when the whole image is written.
4. After `ack=<size>`, phone sends `ota end`. The board checks the image, replies `WD:OTA done` and restarts into it.
5. `ota abort` or a disconnect cancels. The running firmware is untouched until `WD:OTA done`.

New firmware that fails to bring up Wi-Fi and BLE is rolled back on the next boot. From 1.2.2 a board on trial
firmware that isn't up within 30 s restarts itself, so the rollback happens without a power-cycle.

`WD:BOOT` fields: `slot` running app slot; `image` its state at boot (`trial` = first boot after an update,
`confirmed`, …); `reset` last reset cause (`power_on`, `software`, `crash`, `watchdog`, `brownout`, …); `boots` boot
count; `prev_fw` / `prev_stage` how far the previous boot got (`storage`, `led`, `wifi`, `bluetooth`, `ready`,
`boot_watchdog`); `rolled_back` the slot of an update that was rolled back, or `none`.

## Bluetooth (1.3+)

Boards with `bt=1` in `WD:CAPS` can scan Bluetooth LE instead of Wi-Fi. `bt on` stops Wi-Fi scanning and starts
BLE discovery in 10 s windows with duplicate filtering, so each device is reported about once per window. The board
keeps its link to the phone while it scans. The mode resets to Wi-Fi on every connect and disconnect.

- `mac`: the address as broadcast, most significant byte first. `type` says whether it is a public or random address.
- `name_hex`: the advertised name as lower-case hex, empty when none was heard.
- `mfg`: the Bluetooth SIG company id from manufacturer data, as 4 hex digits, or empty.
- `conn`: 1 when the advertisement is connectable.

## GPS (1.4+)

Boards with `gps=1` in `WD:CAPS` have a UART NMEA receiver and stream fixes as `WD:GPS` lines. The phone uses
the board's position as a location source when its own fix is stale or was never granted, so a wardrive is never
left without coordinates. The capability is runtime-detected: a board only advertises `gps=1`, and only sends
`WD:GPS`, once it has parsed a valid fix — so a board with no GPS wired up never claims it.

- `lat` / `lon`: signed decimal degrees (south and west negative).
- `alt`: metres above sea level; omitted when the NMEA sentence carried no altitude.
- `fix`: always `1` (the board only emits a line once it has a valid fix).
- `sats`: satellites in use, when reported.
- Emitted at most once a second while connected. The board reads `$??GGA` and `$??RMC` sentences (any talker id).
- UART pins and baud are set in `menuconfig` under *iosESP* (default UART1, RX GPIO 4, 9600 baud, TX disabled).

## Capture (1.5+)

Boards with `cap=1` in `WD:CAPS` can do **passive** 802.11 promiscuous capture instead of Wi-Fi scanning. `cap on`
puts the radio in monitor mode and camps each planned channel ~300 ms, reporting three kinds of artifact. It is
**receive-only** — the board never transmits, deauthenticates or injects, so an artifact appears only when a client
associates (or probes) on its own. For authorized security research / your own networks. The mode resets to Wi-Fi on
every connect and disconnect, same as Bluetooth.

Capture is a **superset of a Wi-Fi scan** (1.5.1+): it also emits `WD:AP` from the beacons and probe-responses it
hears (BSSID, SSID, RSSI, channel, auth parsed from the RSN/WPA IEs, hidden flag), reporting an AP the first time it
is seen and again when a later sighting is notably stronger. So a board left in capture mode still fills the wardrive
map and WiGLE CSV with APs — it just adds handshakes, PMKIDs and clients on top. (It is passive beacon listening, not
active probing, so a plain scan still edges it slightly on probe-only APs and channel-cycle speed.)

- `WD:HS` carries a full hashcat-22000 line in `hc22000` (`WPA*02*MIC*AP*STA*ESSID*ANONCE*EAPOL*00`): the board pairs
  the handshake's M1 ANonce with the M2 by replay counter and zeroes the MIC field in the EAPOL copy, so the phone can
  append the line to a `.hc22000` hashlist as-is.
- `WD:PMKID` carries the RSN PMKID an AP puts in EAPOL-Key M1 (only some APs do). Build `WPA*01*PMKID*AP*STA*ESSID***`.
- `WD:CLIENT` is a station MAC seen associating, probing or in a data frame, with its BSSID when known. Reported once
  per device per capture session.
- `bssid`/`sta`: most significant byte first. `ssid_hex`: the ESSID the board learned from a beacon/probe-response for
  that BSSID, as lower-case hex; empty when it hasn't heard one yet.
- Each artifact is deduped for the session on the board (handshake by MIC, PMKID by value, client by MAC); the phone
  should dedup again by `pmkid`/MIC and by client MAC.
- Longer per-channel dwell than a scan, because handshakes are opportunistic. Set `ch 1,6,11` to camp fewer channels.

## Scanning

- 2.4 GHz: active, driver default dwell.
- 5 GHz (ESP32-C5): passive, 120 ms per channel, limited to channels the country setting allows.
- The board requests its maximum allowed TX power at start (1.5+) so active-scan probe requests reach farther APs;
  the driver clamps to the chip and country ceiling. RX sensitivity is fixed hardware — there is no RX-power setting.
