# WarBLE Wardrive Bridge — one board, no terminal

A dedicated, single-purpose ESP32 firmware for **WarBLE Go**. Flash it to any
BLE-capable ESP32, power on, and it just works:

- Boots straight into bridge mode — **no serial commands, no `blebridge`, nothing to type.**
- Advertises the **`iosESP`** BLE service the app already looks for (matched by UUID).
- When the phone connects, it hops the 2.4 GHz channels and streams every Wi-Fi AP
  it hears back over BLE as `WD:AP …` lines — the exact format WarBLE Go parses.
- One chip. No second board, no UART wiring, no pairing.

This is **not** GhostESP and needs no patch. It reimplements only the slice of the
GhostLink BLE protocol WarBLE Go needs, so **the app runs against it unmodified**.
(If you'd rather run full GhostESP on the board and just add this capability, the
`../ghostlink-solo/` patch does that instead — but for "only our purpose," use this.)

## Build & flash (any board)

Needs ESP-IDF **v5.1 or newer** installed (`. $IDF_PATH/export.sh`).

```sh
cd firmware/wardrive-bridge
idf.py set-target esp32c5      # or: esp32c6 · esp32s3 · esp32 · esp32c3 · esp32s2*
idf.py build flash monitor
```

The code is target-agnostic — it uses only the radio, no board-specific pins — so
the same source builds for every target. Pick the one matching your chip.

\* ESP32-S2 has no Bluetooth and won't work; every other target above does.
Assumes ≥4 MB flash (the default on virtually all modules).

## Use it

1. Flash one board, power it.
2. In **WarBLE Go**, turn on the Wi-Fi bridge. It connects with no pairing prompt
   and APs start filling the HUD and the wardrive CSV within a second or two.
3. Walk/drive. Disconnecting the phone stops the scan automatically.

That's the whole workflow. There is no configuration.

## Status LED

A single status light tells you what the board is doing, no serial monitor needed:

| State | LED |
|---|---|
| Powered, BLE not up yet | off |
| Advertising (waiting for the phone) | **slow blue blink** |
| Streaming (phone connected, APs flowing) | **solid green** |

Configure it in `idf.py menuconfig` → **WarBLE Wardrive Bridge**:
- **Addressable RGB (WS2812)** — default, GPIO 8 (the onboard LED on most C3/C6 devkits).
- **Simple on/off GPIO LED** — set the GPIO and active-low if needed.
- **None**.

If your board's LED is on a different pin (or is a plain LED), change it there and
rebuild. The default prebuilt bins assume a WS2812 on GPIO 8; the bridge itself works
regardless of whether the LED is correct.

## Prebuilt binaries

The **Firmware (wardrive-bridge)** GitHub Actions workflow builds every target and
publishes a `wardrive-bridge-package` zip (also on the `fw-wardrive-latest` release)
with the full source plus, per chip: a single `wardrive-bridge-merged.bin`, the three
separate bins, `flash_args`, and a `FLASH.txt`.

Easiest — one merged file at `0x0` (offsets baked in; wipe first):

```sh
esptool --chip <target> -p <PORT> erase_flash
esptool --chip <target> -p <PORT> -b 460800 write_flash 0x0 wardrive-bridge-merged.bin
```

**ESP32-C5 note:** the C5 bootloader lives at `0x2000`, not `0x0` like the C3/C6.
The merged image and `flash_args` handle this; just don't hand-flash a C5 bootloader
to `0x0` (that causes an `invalid header: 0xffffffff` boot loop).

## How it works

| Piece | What it does |
|---|---|
| NimBLE GATT server | Advertises service `47686F73-…-696467655376`; RX (write), TX (notify), CTRL (write) — same UUIDs the app decodes |
| Auto-start | On BLE subscribe (and on the app's `wdstream start -wifi`), the scan task starts; on disconnect it stops |
| Scan task | STA-mode active scan across channels 1–13, ~120 ms dwell each, continuous sweep |
| Framing | Each `WD:AP` line is sent as GB DATA frame(s) over TX notify; the app reassembles and parses |

Wi-Fi scanning and the BLE link share the single 2.4 GHz radio through ESP-IDF's
software coexistence arbiter (`CONFIG_ESP_COEX_SW_COEXIST_ENABLE`). AP records are
small and infrequent, so BLE only sees mild extra latency. If BLE ever drops during
scans on your board, widen the per-channel dwell / add a cycle pause in
`SCAN_DWELL_MS` / the `scan_task` loop in `main/wardrive_bridge.c`.

## Status

Written and reviewed against the app's wire contract (`AdControl/GhostLink.swift`)
and the ESP-IDF v5.x NimBLE + esp_wifi APIs. **Not yet flashed/tested on hardware** —
build it, flash a board, and report back; any adjustments will be small (MTU/dwell
tuning, a target-specific sdkconfig tweak).
