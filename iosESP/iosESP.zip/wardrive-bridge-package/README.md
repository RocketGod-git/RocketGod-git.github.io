# iosESP

ESP32 Wi-Fi bridge for Wardrive Go on iPhone. The board scans Wi-Fi and streams every network it hears to the
app over Bluetooth. No pairing, no setup.

Flash from your browser: https://rocketgod.dev/iosESP/

## Flash

Use your chip's folder under `firmware-bins/`:

```sh
esptool --chip <chip> -p <PORT> erase_flash
esptool --chip <chip> -p <PORT> -b 460800 write_flash 0x0 wardrive-bridge-merged.bin
```

## Build

ESP-IDF 5.5. Targets: ESP32-C3, C5, C6, S3.

```sh
idf.py set-target <chip>
idf.py build flash
```

## Use

Power the board and turn on the Wi-Fi bridge in Wardrive Go. The ESP32-C5 also scans 5 GHz. Several boards can
link at once.

MIT license. Protocol: `PROTOCOL.md`.
