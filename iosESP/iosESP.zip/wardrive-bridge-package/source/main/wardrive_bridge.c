// iosESP — Wi-Fi scanner for Wardrive Go over BLE. Protocol: PROTOCOL.md
// SPDX-License-Identifier: MIT

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include "sdkconfig.h"
#include "soc/soc_caps.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/stream_buffer.h"
#include "freertos/queue.h"
#include "esp_ota_ops.h"
#include "esp_system.h"

#include "esp_log.h"
#include "esp_timer.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "nvs_flash.h"
#include "esp_chip_info.h"
#include "esp_flash.h"
#include "esp_mac.h"

#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "host/ble_att.h"
#include "host/util/util.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"

#include "status_led.h"

static const char *TAG = "iosESP";

#define FW_VERSION     "1.3"
#define NAME_PREFIX    "iosESP"

enum {
    FR_MAGIC_0 = 0x47, FR_MAGIC_1 = 0x42, FR_VERSION = 0x01, FR_HEADER = 12,
    FR_CMD = 1, FR_ACK = 2, FR_DATA = 3, FR_END = 4, FR_ERR = 5,
};

// UUIDs are least-significant byte first.
static const ble_uuid128_t SVC_UUID  = BLE_UUID128_INIT(
    0x76,0x53,0x65,0x67,0x64,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47);
static const ble_uuid128_t RX_UUID   = BLE_UUID128_INIT(
    0x52,0x58,0x67,0x64,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x01);
static const ble_uuid128_t TX_UUID   = BLE_UUID128_INIT(
    0x54,0x58,0x67,0x64,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x02);
static const ble_uuid128_t CTRL_UUID = BLE_UUID128_INIT(
    0x43,0x54,0x52,0x4C,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x03);
static const ble_uuid128_t OTA_UUID  = BLE_UUID128_INIT(
    0x44,0x41,0x54,0x4F,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x04);

#define OTA_BUF_BYTES   (24 * 1024)
#define OTA_WINDOW      (12 * 1024)   // max bytes the phone sends ahead of the last ack
#define OTA_ACK_STEP    (4 * 1024)

static StreamBufferHandle_t s_ota_buf;
static TaskHandle_t s_ota_task;
static esp_ota_handle_t s_ota_handle;
static const esp_partition_t *s_ota_part;
static volatile bool s_ota_active = false;
static volatile bool s_ota_end_req = false;
static volatile bool s_ota_abort_req = false;
static volatile uint32_t s_ota_size = 0;

static const uint8_t CH_ORDER[] = { 1, 6, 11, 36, 40, 44, 48, 149, 153, 157, 161,
                                    2, 3, 4, 5, 7, 8, 9, 10, 12, 13 };
#define CH_ORDER_N       (sizeof(CH_ORDER) / sizeof(CH_ORDER[0]))
#define MAX_CHANNELS     CH_ORDER_N
#define PASSIVE_DWELL_MS 120
#define MAX_AP_PER_SCAN  60
#define CMD_MAX          240

static uint8_t  s_supported[MAX_CHANNELS];
static size_t   s_supported_n = 0;
static bool     s_has_5g = false;

static uint8_t  s_plan[MAX_CHANNELS];
static size_t   s_plan_n = 0;
static portMUX_TYPE s_plan_lock = portMUX_INITIALIZER_UNLOCKED;

static char     s_name[16] = NAME_PREFIX;
static uint8_t  s_own_addr_type;
static uint16_t s_conn_handle   = BLE_HS_CONN_HANDLE_NONE;
static uint16_t s_tx_val_handle = 0;
static volatile bool s_notify_enabled = false;
static volatile bool s_streaming      = false;
static TaskHandle_t  s_scan_task      = NULL;
static volatile uint32_t s_reply_id   = 1;
static volatile uint32_t s_ap_count   = 0;
static volatile uint32_t s_sweeps     = 0;
static volatile uint32_t s_last_aps   = 0;

// Bluetooth role: the board scans BLE instead of Wi-Fi. Reset to Wi-Fi on every connect and disconnect.
#define BT_WINDOW_MS  10000
#define BT_QUEUE_LEN  48

typedef struct {
    uint8_t  mac[6];      // most significant byte first
    uint8_t  addr_type;
    int8_t   rssi;
    uint8_t  conn;
    uint8_t  name_len;
    char     name[29];
    uint8_t  has_company;
    uint16_t company;
} bt_rec_t;

static QueueHandle_t s_bt_queue;
static TaskHandle_t  s_bt_task          = NULL;
static volatile bool s_bt_mode          = false;
static volatile bool s_bt_running       = false;
static volatile bool s_bt_window_done   = false;
static volatile bool s_switch_pending   = false;
static volatile uint32_t s_bt_count     = 0;
static volatile uint32_t s_bt_windows   = 0;
static volatile uint32_t s_bt_last      = 0;
static volatile uint32_t s_bt_dropped   = 0;

static int  on_gap_event(struct ble_gap_event *event, void *arg);
static void start_advertising(void);
static void stream_start(void);

static bool is_5ghz(uint8_t ch) { return ch > 14; }

static bool channel_supported(uint8_t ch) {
    for (size_t i = 0; i < s_supported_n; i++) if (s_supported[i] == ch) return true;
    return false;
}

#if SOC_WIFI_SUPPORT_5G
// Bit index in wifi_country_t.wifi_5g_channel_mask.
static int ch5_mask_bit(uint8_t ch) {
    if (ch >= 36 && ch <= 64 && ch % 4 == 0)   return 1 + (ch - 36) / 4;
    if (ch >= 100 && ch <= 144 && ch % 4 == 0) return 9 + (ch - 100) / 4;
    if (ch >= 149 && ch <= 177 && ch % 4 == 1) return 21 + (ch - 149) / 4;
    return -1;
}
#endif

static void build_supported_channels(void) {
    uint32_t mask5 = 0;   // 0 = all channels allowed
#if SOC_WIFI_SUPPORT_5G
    wifi_country_t country = {0};
    if (esp_wifi_get_country(&country) == ESP_OK) mask5 = country.wifi_5g_channel_mask;
#endif
    s_supported_n = 0;
    for (size_t i = 0; i < CH_ORDER_N; i++) {
        uint8_t ch = CH_ORDER[i];
        if (is_5ghz(ch)) {
            if (!s_has_5g) continue;
#if SOC_WIFI_SUPPORT_5G
            int bit = ch5_mask_bit(ch);
            if (mask5 != 0 && (bit < 0 || !(mask5 & (1u << bit)))) continue;
#endif
        }
        s_supported[s_supported_n++] = ch;
    }
    (void)mask5;
}

static void plan_reset_to_all(void) {
    portENTER_CRITICAL(&s_plan_lock);
    memcpy(s_plan, s_supported, s_supported_n);
    s_plan_n = s_supported_n;
    portEXIT_CRITICAL(&s_plan_lock);
}

static size_t plan_copy(uint8_t *out) {
    portENTER_CRITICAL(&s_plan_lock);
    size_t n = s_plan_n;
    memcpy(out, s_plan, n);
    portEXIT_CRITICAL(&s_plan_lock);
    return n;
}

static size_t parse_channel_list(const char *s, uint8_t *out) {
    size_t n = 0;
    while (*s && n < MAX_CHANNELS) {
        while (*s == ',' || *s == ' ') s++;
        if (*s < '0' || *s > '9') break;
        long v = strtol(s, (char **)&s, 10);
        if (v <= 0 || v > 255 || !channel_supported((uint8_t)v)) continue;
        bool dup = false;
        for (size_t i = 0; i < n; i++) if (out[i] == (uint8_t)v) dup = true;
        if (!dup) out[n++] = (uint8_t)v;
    }
    return n;
}

static int format_channel_list(char *buf, int len, int cap, const uint8_t *ch, size_t n) {
    for (size_t i = 0; i < n && len < cap - 5; i++)
        len += snprintf(buf + len, cap - len, i ? ",%u" : "%u", (unsigned)ch[i]);
    return len;
}

static size_t max_payload_per_notify(void) {
    uint16_t mtu = (s_conn_handle != BLE_HS_CONN_HANDLE_NONE) ? ble_att_mtu(s_conn_handle) : 23;
    if (mtu < 23) mtu = 23;
    size_t room = (size_t)mtu - 3;
    return room > FR_HEADER ? room - FR_HEADER : 1;
}

// Not put_le32: NimBLE's os/endian.h defines that name.
static void frame_put_u32(uint8_t *p, uint32_t v) { p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24; }

static void send_frame(uint8_t type, const uint8_t *payload, size_t len) {
    if (s_conn_handle == BLE_HS_CONN_HANDLE_NONE || !s_notify_enabled || s_tx_val_handle == 0) return;
    uint8_t frame[FR_HEADER + 256];
    if (len > sizeof(frame) - FR_HEADER) len = sizeof(frame) - FR_HEADER;
    memset(frame, 0, FR_HEADER);
    frame[0] = FR_MAGIC_0; frame[1] = FR_MAGIC_1; frame[2] = FR_VERSION; frame[3] = type;
    frame_put_u32(frame + 6, s_reply_id);
    frame[10] = len & 0xff; frame[11] = (len >> 8) & 0xff;
    if (len) memcpy(frame + FR_HEADER, payload, len);
    struct os_mbuf *om = ble_hs_mbuf_from_flat(frame, (uint16_t)(FR_HEADER + len));
    if (om) (void)ble_gatts_notify_custom(s_conn_handle, s_tx_val_handle, om);
}

static void send_line(const char *fmt, ...) {
    char line[256];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(line, sizeof(line) - 1, fmt, ap);
    va_end(ap);
    if (n <= 0) return;
    if (n > (int)sizeof(line) - 2) n = (int)sizeof(line) - 2;
    line[n++] = '\n';
    size_t step = max_payload_per_notify();
    for (size_t off = 0; off < (size_t)n; off += step) {
        size_t chunk = ((size_t)n - off < step) ? (size_t)n - off : step;
        send_frame(FR_DATA, (const uint8_t *)line + off, chunk);
    }
}

struct auth_name { wifi_auth_mode_t mode; const char *token; };
static const struct auth_name AUTH_NAMES[] = {
    { WIFI_AUTH_OPEN,            "OPEN" },
    { WIFI_AUTH_WEP,             "WEP" },
    { WIFI_AUTH_WPA_PSK,         "WPA" },
    { WIFI_AUTH_WPA2_PSK,        "WPA2" },
    { WIFI_AUTH_WPA_WPA2_PSK,    "WPA2" },
    { WIFI_AUTH_WPA2_ENTERPRISE, "WPA2" },
    { WIFI_AUTH_WPA3_PSK,        "WPA3" },
    { WIFI_AUTH_WPA2_WPA3_PSK,   "WPA2_WPA3" },
};

static const char *auth_name(wifi_auth_mode_t mode) {
    for (size_t i = 0; i < sizeof(AUTH_NAMES) / sizeof(AUTH_NAMES[0]); i++)
        if (AUTH_NAMES[i].mode == mode) return AUTH_NAMES[i].token;
    return "UNKNOWN";
}

static char lower_hex_digit(uint8_t v) { return (char)(v < 10 ? '0' + v : 'a' + (v - 10)); }

static void send_ap_line(const wifi_ap_record_t *ap) {
    size_t ssid_len = 0;
    while (ssid_len < sizeof(ap->ssid) && ap->ssid[ssid_len]) ssid_len++;
    char ssid_hex[2 * sizeof(ap->ssid) + 1];
    for (size_t i = 0; i < ssid_len; i++) {
        ssid_hex[2 * i]     = lower_hex_digit(ap->ssid[i] >> 4);
        ssid_hex[2 * i + 1] = lower_hex_digit(ap->ssid[i] & 0x0F);
    }
    ssid_hex[2 * ssid_len] = '\0';
    const uint8_t *b = ap->bssid;
    send_line("WD:AP ts=%lu bssid=%02X:%02X:%02X:%02X:%02X:%02X ssid_hex=%s rssi=%d ch=%u auth=%s hidden=%u",
              (unsigned long)(esp_timer_get_time() / 1000), b[0], b[1], b[2], b[3], b[4], b[5],
              ssid_hex, ap->rssi, (unsigned)ap->primary, auth_name(ap->authmode), ssid_len ? 0u : 1u);
    s_ap_count++;
}

static void send_caps_line(void) {
    char buf[200];
    int len = snprintf(buf, sizeof(buf), "WD:CAPS fw=%s chip=%s bands=%s ota=1 bt=1 chans=", FW_VERSION,
                       CONFIG_IDF_TARGET, s_has_5g ? "2g,5g" : "2g");
    format_channel_list(buf, len, sizeof(buf), s_supported, s_supported_n);
    send_line("%s", buf);
}

static void send_plan_line(void) {
    uint8_t plan[MAX_CHANNELS];
    size_t n = plan_copy(plan);
    char buf[160];
    int len = snprintf(buf, sizeof(buf), "WD:PLAN chans=");
    format_channel_list(buf, len, sizeof(buf), plan, n);
    send_line("%s", buf);
}

// ─── Bluetooth role (PROTOCOL.md "Bluetooth") ─────────────────────────────
// Discovery runs in BT_WINDOW_MS windows with duplicate filtering, so each device is reported about once per
// window. Reports are queued from the host task and sent from bt_task.
static const char *bt_addr_type_name(uint8_t t) {
    return (t == BLE_ADDR_PUBLIC || t == BLE_ADDR_PUBLIC_ID) ? "public" : "random";
}

static void send_bt_line(const bt_rec_t *r) {
    char name_hex[2 * sizeof(r->name) + 1];
    for (size_t i = 0; i < r->name_len; i++) {
        name_hex[2 * i]     = lower_hex_digit((uint8_t)r->name[i] >> 4);
        name_hex[2 * i + 1] = lower_hex_digit((uint8_t)r->name[i] & 0x0F);
    }
    name_hex[2 * r->name_len] = '\0';
    char mfg[8] = "";
    if (r->has_company) snprintf(mfg, sizeof(mfg), "%04X", (unsigned)r->company);
    const uint8_t *m = r->mac;
    send_line("WD:BT ts=%lu mac=%02X:%02X:%02X:%02X:%02X:%02X type=%s rssi=%d name_hex=%s mfg=%s conn=%u",
              (unsigned long)(esp_timer_get_time() / 1000), m[0], m[1], m[2], m[3], m[4], m[5],
              bt_addr_type_name(r->addr_type), r->rssi, name_hex, mfg, (unsigned)r->conn);
    s_bt_count++;
}

static int on_disc_event(struct ble_gap_event *event, void *arg) {
    (void)arg;
    if (event->type == BLE_GAP_EVENT_DISC) {
        const struct ble_gap_disc_desc *d = &event->disc;
        bt_rec_t r = {0};
        for (int i = 0; i < 6; i++) r.mac[i] = d->addr.val[5 - i];
        r.addr_type = d->addr.type;
        r.rssi = d->rssi;
        r.conn = (d->event_type == BLE_HCI_ADV_RPT_EVTYPE_ADV_IND || d->event_type == BLE_HCI_ADV_RPT_EVTYPE_DIR_IND);
        struct ble_hs_adv_fields f;
        if (ble_hs_adv_parse_fields(&f, d->data, d->length_data) == 0) {
            if (f.name && f.name_len) {
                r.name_len = f.name_len > sizeof(r.name) ? sizeof(r.name) : f.name_len;
                memcpy(r.name, f.name, r.name_len);
            }
            if (f.mfg_data && f.mfg_data_len >= 2) {
                r.company = (uint16_t)(f.mfg_data[0] | (f.mfg_data[1] << 8));
                r.has_company = 1;
            }
        }
        if (!s_bt_queue || xQueueSend(s_bt_queue, &r, 0) != pdTRUE) s_bt_dropped++;
    } else if (event->type == BLE_GAP_EVENT_DISC_COMPLETE) {
        s_bt_window_done = true;
    }
    return 0;
}

static int bt_disc_start(void) {
    struct ble_gap_disc_params p = {
        .itvl = 0x50, .window = 0x30,   // 50 ms interval, 30 ms window: leaves room for the phone link
        .filter_policy = 0, .limited = 0, .passive = 0, .filter_duplicates = 1,
    };
    s_bt_window_done = false;
    return ble_gap_disc(s_own_addr_type, BT_WINDOW_MS, &p, on_disc_event, NULL);
}

static void bt_task(void *arg) {
    (void)arg;
    send_line("WD:MODE mode=bt");
    send_line("WD:BEGIN type=bt interval=0 channel=auto");
    s_bt_windows = 0;
    s_bt_count = 0;
    s_bt_dropped = 0;
    int fails = 0;
    int rc = bt_disc_start();
    bool scanning = (rc == 0);
    if (!scanning) { send_line("WD:ERR reason=bt_scan_failed rc=%d", rc); fails = 1; }
    bt_rec_t r;
    while (s_bt_running && s_conn_handle != BLE_HS_CONN_HANDLE_NONE) {
        if (xQueueReceive(s_bt_queue, &r, pdMS_TO_TICKS(100)) == pdTRUE) { send_bt_line(&r); continue; }
        if (scanning && !s_bt_window_done) continue;
        if (scanning) {
            s_bt_windows++;
            s_bt_last = s_bt_count;
            send_line("WD:STATUS bt=%lu scans=%lu dropped=%lu", (unsigned long)s_bt_count,
                      (unsigned long)s_bt_windows, (unsigned long)s_bt_dropped);
            s_bt_count = 0;
            s_bt_dropped = 0;
        }
        rc = bt_disc_start();
        scanning = (rc == 0);
        if (scanning) { fails = 0; continue; }
        send_line("WD:ERR reason=bt_scan_failed rc=%d", rc);
        if (++fails >= 5) break;
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
    if (ble_gap_disc_active()) ble_gap_disc_cancel();
    xQueueReset(s_bt_queue);
    send_line("WD:END reason=stop");
    s_bt_running = false;
    s_bt_task = NULL;
    if (s_switch_pending) { s_switch_pending = false; stream_start(); }
    else if (s_conn_handle != BLE_HS_CONN_HANDLE_NONE) status_led_set(STATUS_LED_ADVERTISING);
    vTaskDelete(NULL);
}

static void bt_start(void) {
    if (s_bt_running || s_bt_task || s_ota_active || s_conn_handle == BLE_HS_CONN_HANDLE_NONE) return;
    if (!s_bt_queue) s_bt_queue = xQueueCreate(BT_QUEUE_LEN, sizeof(bt_rec_t));
    if (!s_bt_queue) { send_line("WD:ERR reason=no_memory"); return; }
    s_bt_running = true;
    if (xTaskCreate(bt_task, "wd_bt", 4096, NULL, 5, &s_bt_task) != pdPASS) {
        s_bt_running = false;
        s_bt_task = NULL;
        send_line("WD:ERR reason=no_task");
        return;
    }
    status_led_set(STATUS_LED_STREAMING);
    ESP_LOGI(TAG, "bluetooth scan started");
}

static void scan_one_channel(uint8_t ch) {
    wifi_scan_config_t cfg = { .channel = ch, .show_hidden = true };
    if (is_5ghz(ch)) {
        cfg.scan_type = WIFI_SCAN_TYPE_PASSIVE;
        cfg.scan_time.passive = PASSIVE_DWELL_MS;
    } else {
        cfg.scan_type = WIFI_SCAN_TYPE_ACTIVE;   // default dwell; coex rejects custom active times
    }
    if (esp_wifi_scan_start(&cfg, true) != ESP_OK) return;
    uint16_t found = 0;
    if (esp_wifi_scan_get_ap_num(&found) != ESP_OK || found == 0) return;
    if (found > MAX_AP_PER_SCAN) found = MAX_AP_PER_SCAN;
    wifi_ap_record_t *aps = calloc(found, sizeof(*aps));
    if (!aps) return;
    if (esp_wifi_scan_get_ap_records(&found, aps) == ESP_OK)
        for (uint16_t i = 0; i < found && s_streaming; i++) send_ap_line(&aps[i]);
    free(aps);
}

static char s_boot_line[220];   // built at boot by boot_diag_begin()

static void scan_task(void *arg) {
    (void)arg;
    send_caps_line();
    if (s_boot_line[0]) send_line("%s", s_boot_line);
    send_line("WD:MODE mode=wifi");
    send_line("WD:BEGIN type=wifi interval=0 channel=auto");
    send_plan_line();
    s_sweeps = 0;
    uint8_t plan[MAX_CHANNELS];
    while (s_streaming && s_conn_handle != BLE_HS_CONN_HANDLE_NONE) {
        size_t n = plan_copy(plan);
        s_ap_count = 0;   // APs heard this sweep (one record per AP per channel scan)
        for (size_t i = 0; i < n && s_streaming; i++) {
            scan_one_channel(plan[i]);
            vTaskDelay(pdMS_TO_TICKS(5));
        }
        if (n == 0) vTaskDelay(pdMS_TO_TICKS(200));
        s_sweeps++;
        s_last_aps = s_ap_count;
        send_line("WD:STATUS aps=%lu scans=%lu", (unsigned long)s_ap_count, (unsigned long)s_sweeps);
    }
    send_line("WD:END reason=stop");
    s_streaming = false;
    s_scan_task = NULL;
    if (s_switch_pending) { s_switch_pending = false; stream_start(); }
    vTaskDelete(NULL);
}

static void wifi_start(void) {
    if (s_streaming || s_scan_task || s_ota_active || s_conn_handle == BLE_HS_CONN_HANDLE_NONE) return;
    s_streaming = true;
    if (xTaskCreate(scan_task, "wd_scan", 6144, NULL, 5, &s_scan_task) != pdPASS) {
        s_streaming = false;
        s_scan_task = NULL;
        ESP_LOGE(TAG, "scan task create failed");
        return;
    }
    status_led_set(STATUS_LED_STREAMING);
    ESP_LOGI(TAG, "stream started");
}

/// Starts scanning in this board's current role.
static void stream_start(void) {
    if (s_bt_mode) bt_start();
    else wifi_start();
}

static void stream_stop(void) {
    s_streaming = false;
    s_bt_running = false;
    (void)esp_wifi_scan_stop();
    if (s_conn_handle != BLE_HS_CONN_HANDLE_NONE) status_led_set(STATUS_LED_ADVERTISING);
}

/// Switches the board between Wi-Fi and Bluetooth scanning. A running scan finishes first; the task that
/// ends then starts the new role.
static void set_bt_mode(bool bt) {
    if (bt == s_bt_mode) {
        send_line("WD:MODE mode=%s", bt ? "bt" : "wifi");
        if (!s_streaming && !s_bt_running && !s_scan_task && !s_bt_task) stream_start();
        return;
    }
    s_bt_mode = bt;
    send_line("WD:MODE mode=%s", bt ? "bt" : "wifi");
    if (s_scan_task || s_bt_task) {
        s_switch_pending = true;
        stream_stop();
    } else {
        stream_start();
    }
}

// ─── Firmware update over BLE (PROTOCOL.md "Firmware update") ──────────────
// Image bytes arrive on the OTA characteristic and are queued; this task writes them to the spare app slot
// (sequential writes erase sector by sector, so nothing blocks the BLE host for long) and acks progress.
// The receive buffer is created once and only reset, never freed, so a late BLE write can't land in freed memory.
static void ota_cleanup(void) {
    s_ota_active = false;
    s_ota_end_req = false;
    s_ota_abort_req = false;
    s_ota_task = NULL;
}

static void ota_task(void *arg) {
    (void)arg;
    static uint8_t chunk[1024];
    uint32_t written = 0, next_ack = OTA_ACK_STEP;
    const char *err = "unknown";
    bool ended = false;
    for (;;) {
        if (s_ota_abort_req) { err = "aborted"; break; }
        size_t n = xStreamBufferReceive(s_ota_buf, chunk, sizeof(chunk), pdMS_TO_TICKS(100));
        if (n > 0) {
            if (written + n > s_ota_size) { err = "too_much_data"; break; }
            if (esp_ota_write(s_ota_handle, chunk, n) != ESP_OK) { err = "write_failed"; break; }
            written += n;
            if (written >= next_ack || written == s_ota_size) {
                send_line("WD:OTA ack=%lu", (unsigned long)written);
                next_ack = written + OTA_ACK_STEP;
            }
        }
        if (s_ota_end_req && xStreamBufferIsEmpty(s_ota_buf)) {
            if (written != s_ota_size) { err = "short_image"; break; }
            ended = true;   // esp_ota_end releases the handle whatever it returns
            if (esp_ota_end(s_ota_handle) != ESP_OK) { err = "invalid_image"; break; }
            if (esp_ota_set_boot_partition(s_ota_part) != ESP_OK) { err = "set_boot_failed"; break; }
            send_line("WD:OTA done");
            ESP_LOGI(TAG, "update written (%lu bytes) — restarting", (unsigned long)written);
            vTaskDelay(pdMS_TO_TICKS(800));
            esp_restart();
        }
    }
    if (!ended) esp_ota_abort(s_ota_handle);
    send_line("WD:OTA error=%s", err);
    ESP_LOGW(TAG, "update failed: %s", err);
    ota_cleanup();
    vTaskDelete(NULL);
}

static void ota_begin(const char *args) {
    if (s_ota_active) { send_line("WD:OTA error=busy"); return; }
    unsigned long size = strtoul(args, NULL, 10);
    s_ota_part = esp_ota_get_next_update_partition(NULL);
    if (!s_ota_part) { send_line("WD:OTA error=no_update_slot"); return; }
    if (size == 0 || size > s_ota_part->size) { send_line("WD:OTA error=bad_size"); return; }
    stream_stop();
    if (esp_ota_begin(s_ota_part, OTA_WITH_SEQUENTIAL_WRITES, &s_ota_handle) != ESP_OK) {
        send_line("WD:OTA error=begin_failed"); return;
    }
    if (!s_ota_buf) s_ota_buf = xStreamBufferCreate(OTA_BUF_BYTES, 1);
    else xStreamBufferReset(s_ota_buf);
    if (!s_ota_buf) { esp_ota_abort(s_ota_handle); send_line("WD:OTA error=no_memory"); return; }
    s_ota_size = (uint32_t)size;
    s_ota_end_req = false;
    s_ota_abort_req = false;
    s_ota_active = true;
    if (xTaskCreate(ota_task, "ota", 4096, NULL, 4, &s_ota_task) != pdPASS) {
        esp_ota_abort(s_ota_handle);
        ota_cleanup();
        send_line("WD:OTA error=no_task");
        return;
    }
    ESP_LOGI(TAG, "update started: %lu bytes → %s", size, s_ota_part->label);
    send_line("WD:OTA ready window=%u", (unsigned)OTA_WINDOW);
}

static int on_ota_write(uint16_t conn, uint16_t attr, struct ble_gatt_access_ctxt *ctxt, void *arg) {
    (void)conn; (void)attr; (void)arg;
    if (ctxt->op != BLE_GATT_ACCESS_OP_WRITE_CHR) return BLE_ATT_ERR_UNLIKELY;
    if (!s_ota_active || !s_ota_buf) return BLE_ATT_ERR_WRITE_NOT_PERMITTED;
    uint8_t buf[512];
    uint16_t got = 0;
    if (ble_hs_mbuf_to_flat(ctxt->om, buf, sizeof(buf), &got) != 0) return BLE_ATT_ERR_UNLIKELY;
    if (xStreamBufferSend(s_ota_buf, buf, got, 0) != got) s_ota_abort_req = true;   // phone ignored the window
    return 0;
}

static void ota_mark_valid_if_pending(void) {
    esp_ota_img_states_t st;
    const esp_partition_t *run = esp_ota_get_running_partition();
    if (run && esp_ota_get_state_partition(run, &st) == ESP_OK && st == ESP_OTA_IMG_PENDING_VERIFY) {
        esp_ota_mark_app_valid_cancel_rollback();
        ESP_LOGI(TAG, "new firmware confirmed");
    }
}

// ─── Boot diagnostics ──────────────────────────────────────────────────────
// Each boot saves how far it got (NVS, shared by both app slots), so after a hang, crash or rollback the next
// boot can report it. Freshly updated firmware that isn't up within BOOT_WATCHDOG_S restarts itself, and the
// bootloader then rolls back to the previous slot.
enum { STAGE_NONE = 0, STAGE_STORAGE, STAGE_LED, STAGE_WIFI, STAGE_BLUETOOTH, STAGE_READY, STAGE_WATCHDOG };
#define BOOT_WATCHDOG_S 30

static esp_timer_handle_t s_boot_wd;

static const char *reset_reason_key(esp_reset_reason_t r) {
    switch (r) {
    case ESP_RST_POWERON:   return "power_on";
    case ESP_RST_EXT:       return "reset_pin";
    case ESP_RST_SW:        return "software";
    case ESP_RST_PANIC:     return "crash";
    case ESP_RST_INT_WDT:
    case ESP_RST_TASK_WDT:
    case ESP_RST_WDT:       return "watchdog";
    case ESP_RST_BROWNOUT:  return "brownout";
    case ESP_RST_DEEPSLEEP: return "deep_sleep";
    default:                return "other";
    }
}

static const char *stage_name(uint8_t s) {
    switch (s) {
    case STAGE_STORAGE:   return "storage";
    case STAGE_LED:       return "led";
    case STAGE_WIFI:      return "wifi";
    case STAGE_BLUETOOTH: return "bluetooth";
    case STAGE_READY:     return "ready";
    case STAGE_WATCHDOG:  return "boot_watchdog";
    default:              return "none";
    }
}

static const char *image_state_name(esp_ota_img_states_t s) {
    switch (s) {
    case ESP_OTA_IMG_NEW:            return "new";
    case ESP_OTA_IMG_PENDING_VERIFY: return "trial";
    case ESP_OTA_IMG_VALID:          return "confirmed";
    case ESP_OTA_IMG_INVALID:        return "invalid";
    case ESP_OTA_IMG_ABORTED:        return "aborted";
    default:                         return "undefined";
    }
}

static void boot_stage(uint8_t stage) {
    nvs_handle_t h;
    if (nvs_open("iosesp", NVS_READWRITE, &h) != ESP_OK) return;
    nvs_set_u8(h, "stage", stage);
    nvs_set_str(h, "stfw", FW_VERSION);
    nvs_commit(h);
    nvs_close(h);
}

static void boot_watchdog_fire(void *arg) {
    (void)arg;
    esp_ota_img_states_t st;
    const esp_partition_t *run = esp_ota_get_running_partition();
    if (run && esp_ota_get_state_partition(run, &st) == ESP_OK && st == ESP_OTA_IMG_PENDING_VERIFY) {
        boot_stage(STAGE_WATCHDOG);
        esp_restart();   // still on trial → the bootloader rolls back to the previous firmware
    }
}

/// Call right after NVS is up: reads the previous boot's progress, counts this boot, builds the WD:BOOT line,
/// and arms the boot watchdog when this firmware is on trial after an update.
static void boot_diag_begin(void) {
    uint8_t prev_stage = STAGE_NONE;
    char prev_fw[16] = "?";
    uint32_t boots = 0;
    nvs_handle_t h;
    if (nvs_open("iosesp", NVS_READWRITE, &h) == ESP_OK) {
        size_t len = sizeof(prev_fw);
        nvs_get_u8(h, "stage", &prev_stage);
        if (nvs_get_str(h, "stfw", prev_fw, &len) != ESP_OK) strcpy(prev_fw, "?");
        nvs_get_u32(h, "boots", &boots);
        boots++;
        nvs_set_u32(h, "boots", boots);
        nvs_commit(h);
        nvs_close(h);
    }
    const esp_partition_t *run = esp_ota_get_running_partition();
    esp_ota_img_states_t st = ESP_OTA_IMG_UNDEFINED;
    if (run) esp_ota_get_state_partition(run, &st);
    const esp_partition_t *bad = esp_ota_get_last_invalid_partition();
    snprintf(s_boot_line, sizeof(s_boot_line),
             "WD:BOOT fw=%s slot=%s image=%s reset=%s boots=%lu prev_fw=%s prev_stage=%s rolled_back=%s",
             FW_VERSION, run ? run->label : "?", image_state_name(st),
             reset_reason_key(esp_reset_reason()), (unsigned long)boots, prev_fw, stage_name(prev_stage),
             bad ? bad->label : "none");
    ESP_LOGI(TAG, "%s", s_boot_line);
    boot_stage(STAGE_STORAGE);
    if (st == ESP_OTA_IMG_PENDING_VERIFY) {
        const esp_timer_create_args_t args = { .callback = boot_watchdog_fire, .name = "boot_wd" };
        if (esp_timer_create(&args, &s_boot_wd) == ESP_OK)
            esp_timer_start_once(s_boot_wd, (uint64_t)BOOT_WATCHDOG_S * 1000000ULL);
    }
}

// ─── Terminal commands (PROTOCOL.md "Commands") ────────────────────────────
static bool apply_channel_list(const char *list) {
    uint8_t chans[MAX_CHANNELS];
    size_t count = parse_channel_list(list, chans);
    if (count == 0) return false;
    portENTER_CRITICAL(&s_plan_lock);
    memcpy(s_plan, chans, count);
    s_plan_n = count;
    portEXIT_CRITICAL(&s_plan_lock);
    if (s_streaming) send_plan_line();
    return true;
}

static void led_pref_save(bool on) {
    nvs_handle_t h;
    if (nvs_open("iosesp", NVS_READWRITE, &h) != ESP_OK) return;
    nvs_set_u8(h, "led", on ? 1 : 0);
    nvs_commit(h);
    nvs_close(h);
}

static bool led_pref_load(void) {
    nvs_handle_t h;
    uint8_t v = 1;
    if (nvs_open("iosesp", NVS_READONLY, &h) == ESP_OK) { nvs_get_u8(h, "led", &v); nvs_close(h); }
    return v != 0;
}

static const char *reset_reason_name(esp_reset_reason_t r) {
    switch (r) {
    case ESP_RST_POWERON:  return "power-on";
    case ESP_RST_EXT:      return "reset pin";
    case ESP_RST_SW:       return "software restart";
    case ESP_RST_PANIC:    return "crash";
    case ESP_RST_INT_WDT:
    case ESP_RST_TASK_WDT:
    case ESP_RST_WDT:      return "watchdog";
    case ESP_RST_BROWNOUT: return "brownout (low power)";
    case ESP_RST_DEEPSLEEP:return "deep sleep";
    default:               return "other";
    }
}

static void cmd_help(void) {
    send_line("iosESP %s commands:", FW_VERSION);
    send_line("  info          firmware, chip, memory, uptime");
    send_line("  status        scanning, sweeps, channels");
    send_line("  ch            show channels  ·  ch 1,6,11  ·  ch all");
    send_line("  start | stop  resume or pause scanning");
    send_line("  bt on|off     scan Bluetooth instead of Wi-Fi");
    send_line("  led on|off    status LED (saved)");
    send_line("  reboot        restart the board");
}

static void cmd_info(void) {
    esp_chip_info_t ci;
    esp_chip_info(&ci);
    uint32_t flash = 0;
    esp_flash_get_size(NULL, &flash);
    uint8_t mac[6] = {0};
    esp_read_mac(mac, ESP_MAC_WIFI_STA);
    const esp_partition_t *run = esp_ota_get_running_partition();
    unsigned long up = (unsigned long)(esp_timer_get_time() / 1000000);
    send_line("iosESP %s  ·  %s rev %d.%d  ·  %s", FW_VERSION, CONFIG_IDF_TARGET,
              ci.revision / 100, ci.revision % 100, s_name);
    send_line("Wi-Fi MAC %02x:%02x:%02x:%02x:%02x:%02x", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    send_line("uptime %luh %02lum %02lus  ·  last reset: %s", up / 3600, (up / 60) % 60, up % 60,
              reset_reason_name(esp_reset_reason()));
    send_line("memory %lu KB free (low %lu KB)  ·  flash %lu MB",
              (unsigned long)(esp_get_free_heap_size() / 1024),
              (unsigned long)(esp_get_minimum_free_heap_size() / 1024),
              (unsigned long)(flash / (1024 * 1024)));
    send_line("slot %s  ·  %s  ·  %u channels", run ? run->label : "?",
              s_has_5g ? "2.4 + 5 GHz" : "2.4 GHz", (unsigned)s_supported_n);
    send_line("%s", s_boot_line);
}

static void cmd_status(void) {
    uint8_t plan[MAX_CHANNELS];
    size_t n = plan_copy(plan);
    char chans[160] = "";
    format_channel_list(chans, 0, sizeof(chans), plan, n);
    uint16_t mtu = s_conn_handle != BLE_HS_CONN_HANDLE_NONE ? ble_att_mtu(s_conn_handle) : 0;
    if (s_bt_mode) {
        send_line("mode Bluetooth  ·  scanning %s  ·  %lu windows  ·  %lu devices last window",
                  s_bt_running ? "on" : (s_ota_active ? "paused (updating)" : "off"),
                  (unsigned long)s_bt_windows, (unsigned long)s_bt_last);
    } else {
        send_line("mode Wi-Fi  ·  scanning %s  ·  %lu sweeps  ·  %lu APs last sweep",
                  s_streaming ? "on" : (s_ota_active ? "paused (updating)" : "off"),
                  (unsigned long)s_sweeps, (unsigned long)s_last_aps);
        send_line("channels %s", n ? chans : "none");
    }
    send_line("BLE MTU %u  ·  LED %s", (unsigned)mtu, status_led_enabled() ? "on" : "off");
}

static void cmd_channels(const char *arg) {
    if (!*arg) {
        char sup[160] = "", cur[160] = "";
        uint8_t plan[MAX_CHANNELS];
        size_t n = plan_copy(plan);
        format_channel_list(sup, 0, sizeof(sup), s_supported, s_supported_n);
        format_channel_list(cur, 0, sizeof(cur), plan, n);
        send_line("supported %s", sup);
        send_line("scanning  %s", n ? cur : "none");
        return;
    }
    if (!strcmp(arg, "all")) {
        plan_reset_to_all();
        if (s_streaming) send_plan_line();
        send_line("scanning all %u channels", (unsigned)s_supported_n);
        return;
    }
    if (!apply_channel_list(arg)) { send_line("none of those channels are supported"); cmd_channels(""); return; }
    send_line("ok — the app re-splits channels when a board links or drops");
}

static void cmd_led(const char *arg) {
    if (!strcmp(arg, "on") || !strcmp(arg, "off")) {
        bool on = !strcmp(arg, "on");
        status_led_enable(on);
        led_pref_save(on);
    }
    send_line("LED %s", status_led_enabled() ? "on" : "off");
}

static void reboot_task(void *arg) {
    (void)arg;
    vTaskDelay(pdMS_TO_TICKS(400));
    esp_restart();
}

static void cmd_reboot(void) {
    send_line("rebooting");
    xTaskCreate(reboot_task, "reboot", 2048, NULL, 5, NULL);
}

static void handle_command(const uint8_t *data, uint16_t len) {
    const uint8_t *text = data;
    uint16_t text_len = len;
    if (len >= FR_HEADER && data[0] == FR_MAGIC_0 && data[1] == FR_MAGIC_1) {
        uint16_t plen = (uint16_t)(data[10] | (data[11] << 8));
        if (FR_HEADER + (size_t)plen <= len) {
            s_reply_id = (uint32_t)data[6] | ((uint32_t)data[7] << 8) | ((uint32_t)data[8] << 16) | ((uint32_t)data[9] << 24);
            if (data[3] == FR_CMD) {
                text = data + FR_HEADER;
                text_len = plen;
                send_frame(FR_ACK, NULL, 0);
            }
        }
    }
    char cmd[CMD_MAX + 1];
    size_t n = text_len < CMD_MAX ? text_len : CMD_MAX;
    memcpy(cmd, text, n);
    cmd[n] = '\0';
    ESP_LOGI(TAG, "cmd: '%s'", cmd);

    char *p = cmd;
    while (*p == ' ') p++;
    size_t plen = strlen(p);
    while (plen && (p[plen - 1] == ' ' || p[plen - 1] == '\r' || p[plen - 1] == '\n')) p[--plen] = '\0';
    if (!*p) return;
    char word[16];
    size_t wlen = strcspn(p, " ");
    if (wlen >= sizeof(word)) wlen = sizeof(word) - 1;
    memcpy(word, p, wlen);
    word[wlen] = '\0';
    const char *rest = p + strcspn(p, " ");
    while (*rest == ' ') rest++;

    if (!strcmp(word, "ota")) {
        if (!strncmp(rest, "begin ", 6)) ota_begin(rest + 6);
        else if (!strcmp(rest, "end")) { if (s_ota_active) s_ota_end_req = true; }
        else if (!strcmp(rest, "abort")) { if (s_ota_active) s_ota_abort_req = true; }
    }
    else if (!strcmp(word, "help"))     cmd_help();
    else if (!strcmp(word, "info"))     cmd_info();
    else if (!strcmp(word, "status"))   cmd_status();
    else if (!strcmp(word, "caps"))     send_caps_line();
    else if (!strcmp(word, "ch"))       cmd_channels(rest);
    else if (!strcmp(word, "led"))      cmd_led(rest);
    else if (!strcmp(word, "reboot"))   cmd_reboot();
    else if (!strcmp(word, "stop"))     stream_stop();
    else if (!strcmp(word, "start"))    stream_start();
    else if (!strcmp(word, "bt")) {
        if (!strcmp(rest, "on"))       set_bt_mode(true);
        else if (!strcmp(rest, "off")) set_bt_mode(false);
        else send_line("mode %s  ·  bt on | bt off", s_bt_mode ? "Bluetooth" : "Wi-Fi");
    }
    else if (!strcmp(word, "wdstream")) {
        if (strstr(rest, "stop")) { stream_stop(); return; }
        const char *ch_arg = strstr(rest, "-ch ");
        if (ch_arg && !apply_channel_list(ch_arg + 4)) send_line("WD:ERR reason=no_supported_channels");
        stream_start();
    }
    else { send_line("unknown command '%s'", word); cmd_help(); }
}

static int on_command_write(uint16_t conn, uint16_t attr, struct ble_gatt_access_ctxt *ctxt, void *arg) {
    (void)conn; (void)attr; (void)arg;
    if (ctxt->op != BLE_GATT_ACCESS_OP_WRITE_CHR) return BLE_ATT_ERR_UNLIKELY;
    uint8_t buf[256];
    uint16_t got = 0;
    if (ble_hs_mbuf_to_flat(ctxt->om, buf, sizeof(buf), &got) != 0) return BLE_ATT_ERR_UNLIKELY;
    handle_command(buf, got);
    return 0;
}

static int on_tx_access(uint16_t conn, uint16_t attr, struct ble_gatt_access_ctxt *ctxt, void *arg) {
    (void)conn; (void)attr; (void)ctxt; (void)arg;
    return 0;
}

static const struct ble_gatt_chr_def CHARACTERISTICS[] = {
    { .uuid = &RX_UUID.u,   .access_cb = on_command_write, .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP },
    { .uuid = &TX_UUID.u,   .access_cb = on_tx_access,     .flags = BLE_GATT_CHR_F_NOTIFY, .val_handle = &s_tx_val_handle },
    { .uuid = &CTRL_UUID.u, .access_cb = on_command_write, .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP },
    { .uuid = &OTA_UUID.u,  .access_cb = on_ota_write,     .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP },
    { 0 },
};
static const struct ble_gatt_svc_def SERVICES[] = {
    { .type = BLE_GATT_SVC_TYPE_PRIMARY, .uuid = &SVC_UUID.u, .characteristics = CHARACTERISTICS },
    { 0 },
};

static void start_advertising(void) {
    struct ble_hs_adv_fields adv = {0};
    adv.flags = BLE_HS_ADV_F_DISC_GEN | BLE_HS_ADV_F_BREDR_UNSUP;
    adv.uuids128 = (ble_uuid128_t *)&SVC_UUID;
    adv.num_uuids128 = 1;
    adv.uuids128_is_complete = 1;
    if (ble_gap_adv_set_fields(&adv) != 0) { ESP_LOGE(TAG, "adv fields rejected"); return; }

    struct ble_hs_adv_fields scan_rsp = {0};
    scan_rsp.name = (const uint8_t *)s_name;
    scan_rsp.name_len = strlen(s_name);
    scan_rsp.name_is_complete = 1;
    (void)ble_gap_adv_rsp_set_fields(&scan_rsp);

    struct ble_gap_adv_params params = { .conn_mode = BLE_GAP_CONN_MODE_UND, .disc_mode = BLE_GAP_DISC_MODE_GEN };
    if (ble_gap_adv_start(s_own_addr_type, NULL, BLE_HS_FOREVER, &params, on_gap_event, NULL) != 0) {
        ESP_LOGE(TAG, "advertising failed to start");
        return;
    }
    status_led_set(STATUS_LED_ADVERTISING);
    ESP_LOGI(TAG, "advertising as '%s'", s_name);
}

static int on_gap_event(struct ble_gap_event *event, void *arg) {
    (void)arg;
    switch (event->type) {
    case BLE_GAP_EVENT_CONNECT:
        if (event->connect.status != 0) { start_advertising(); return 0; }
        s_conn_handle = event->connect.conn_handle;
        s_notify_enabled = false;
        s_bt_mode = false;
        s_switch_pending = false;
        plan_reset_to_all();
        ESP_LOGI(TAG, "phone connected");
        return 0;

    case BLE_GAP_EVENT_DISCONNECT:
        ESP_LOGI(TAG, "phone disconnected (reason %d)", event->disconnect.reason);
        s_conn_handle = BLE_HS_CONN_HANDLE_NONE;
        s_notify_enabled = false;
        if (s_ota_active) s_ota_abort_req = true;
        s_switch_pending = false;
        stream_stop();
        s_bt_mode = false;
        plan_reset_to_all();
        start_advertising();
        return 0;

    case BLE_GAP_EVENT_SUBSCRIBE:
        if (event->subscribe.attr_handle != s_tx_val_handle) return 0;
        s_notify_enabled = event->subscribe.cur_notify;
        ESP_LOGI(TAG, "notifications %s", s_notify_enabled ? "on" : "off");
        if (s_notify_enabled) stream_start();
        else stream_stop();
        return 0;

    case BLE_GAP_EVENT_MTU:
        ESP_LOGI(TAG, "MTU %u", event->mtu.value);
        return 0;

    default:
        return 0;
    }
}

static void on_ble_sync(void) {
    if (ble_hs_util_ensure_addr(0) != 0) { ESP_LOGE(TAG, "no BLE address"); return; }
    if (ble_hs_id_infer_auto(0, &s_own_addr_type) != 0) s_own_addr_type = BLE_OWN_ADDR_PUBLIC;
    uint8_t addr[6] = {0};
    if (ble_hs_id_copy_addr(s_own_addr_type, addr, NULL) == 0)
        snprintf(s_name, sizeof(s_name), NAME_PREFIX "-%02X%02X", addr[1], addr[0]);
    (void)ble_svc_gap_device_name_set(s_name);
    start_advertising();
    ota_mark_valid_if_pending();   // Wi-Fi + BLE came up: keep this firmware (otherwise the next boot rolls back)
    if (s_boot_wd) esp_timer_stop(s_boot_wd);
    boot_stage(STAGE_READY);
}

static void on_ble_reset(int reason) { ESP_LOGW(TAG, "BLE host reset: %d", reason); }

static void ble_host_task(void *param) {
    (void)param;
    nimble_port_run();
    nimble_port_freertos_deinit();
}

static void wifi_bring_up(void) {
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_wifi_set_storage(WIFI_STORAGE_RAM));
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_start());
#if SOC_WIFI_SUPPORT_5G
    esp_err_t err = esp_wifi_set_band_mode(WIFI_BAND_MODE_AUTO);
    s_has_5g = (err == ESP_OK);
    if (!s_has_5g) ESP_LOGW(TAG, "dual-band mode unavailable (%s), 2.4 GHz only", esp_err_to_name(err));
#endif
    build_supported_channels();
    plan_reset_to_all();
    ESP_LOGI(TAG, "%s: %u channels (%s)", CONFIG_IDF_TARGET, (unsigned)s_supported_n, s_has_5g ? "2.4 + 5 GHz" : "2.4 GHz");
}

void app_main(void) {
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }
    boot_diag_begin();
    status_led_init();
    status_led_enable(led_pref_load());
    boot_stage(STAGE_LED);
    wifi_bring_up();
    boot_stage(STAGE_WIFI);

    ESP_ERROR_CHECK(nimble_port_init());
    ble_svc_gap_init();
    ble_svc_gatt_init();
    ESP_ERROR_CHECK(ble_gatts_count_cfg(SERVICES));
    ESP_ERROR_CHECK(ble_gatts_add_svcs(SERVICES));
    ESP_ERROR_CHECK(ble_svc_gap_device_name_set(s_name));

    ble_hs_cfg.sync_cb = on_ble_sync;
    ble_hs_cfg.reset_cb = on_ble_reset;
    nimble_port_freertos_init(ble_host_task);
    boot_stage(STAGE_BLUETOOTH);
    ESP_LOGI(TAG, "iosESP %s ready", FW_VERSION);
}
