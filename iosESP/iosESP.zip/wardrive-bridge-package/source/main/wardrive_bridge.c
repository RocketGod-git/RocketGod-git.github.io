// iosESP — Wi-Fi scanner for Wardrive Go over BLE. Protocol: PROTOCOL.md
// SPDX-License-Identifier: MIT

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include "sdkconfig.h"
#include "soc/soc_caps.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_log.h"
#include "esp_timer.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "nvs_flash.h"

#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "host/ble_att.h"
#include "host/util/util.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"

#include "status_led.h"

static const char *TAG = "iosESP";

#define FW_VERSION     "1.1"
#define NAME_PREFIX    "iosESP"

enum {
    FR_MAGIC_0 = 0x47, FR_MAGIC_1 = 0x42, FR_VERSION = 0x01, FR_HEADER = 12,
    FR_CMD = 1, FR_ACK = 2, FR_DATA = 3, FR_END = 4, FR_ERR = 5,
};

// UUIDs are least-significant byte first.
static const ble_uuid128_t SVC_UUID  = BLE_UUID128_INIT(
    0x76,0x53,0x65,0x67,0x64,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47);
static const ble_uuid128_t RX_UUID   = BLE_UUID128_INIT(
    0x52,0x58,0x67,0x64,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x01);
static const ble_uuid128_t TX_UUID   = BLE_UUID128_INIT(
    0x54,0x58,0x67,0x64,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x02);
static const ble_uuid128_t CTRL_UUID = BLE_UUID128_INIT(
    0x43,0x54,0x52,0x4C,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x03);

static const uint8_t CH_ORDER[] = { 1, 6, 11, 36, 40, 44, 48, 149, 153, 157, 161,
                                    2, 3, 4, 5, 7, 8, 9, 10, 12, 13 };
#define CH_ORDER_N       (sizeof(CH_ORDER) / sizeof(CH_ORDER[0]))
#define MAX_CHANNELS     CH_ORDER_N
#define PASSIVE_DWELL_MS 120
#define MAX_AP_PER_SCAN  60
#define CMD_MAX          240

static uint8_t  s_supported[MAX_CHANNELS];
static size_t   s_supported_n = 0;
static bool     s_has_5g = false;

static uint8_t  s_plan[MAX_CHANNELS];
static size_t   s_plan_n = 0;
static portMUX_TYPE s_plan_lock = portMUX_INITIALIZER_UNLOCKED;

static char     s_name[16] = NAME_PREFIX;
static uint8_t  s_own_addr_type;
static uint16_t s_conn_handle   = BLE_HS_CONN_HANDLE_NONE;
static uint16_t s_tx_val_handle = 0;
static volatile bool s_notify_enabled = false;
static volatile bool s_streaming      = false;
static TaskHandle_t  s_scan_task      = NULL;
static volatile uint32_t s_reply_id   = 1;
static volatile uint32_t s_ap_count   = 0;

static int  on_gap_event(struct ble_gap_event *event, void *arg);
static void start_advertising(void);

static bool is_5ghz(uint8_t ch) { return ch > 14; }

static bool channel_supported(uint8_t ch) {
    for (size_t i = 0; i < s_supported_n; i++) if (s_supported[i] == ch) return true;
    return false;
}

#if SOC_WIFI_SUPPORT_5G
// Bit index in wifi_country_t.wifi_5g_channel_mask.
static int ch5_mask_bit(uint8_t ch) {
    if (ch >= 36 && ch <= 64 && ch % 4 == 0)   return 1 + (ch - 36) / 4;
    if (ch >= 100 && ch <= 144 && ch % 4 == 0) return 9 + (ch - 100) / 4;
    if (ch >= 149 && ch <= 177 && ch % 4 == 1) return 21 + (ch - 149) / 4;
    return -1;
}
#endif

static void build_supported_channels(void) {
    uint32_t mask5 = 0;   // 0 = all channels allowed
#if SOC_WIFI_SUPPORT_5G
    wifi_country_t country = {0};
    if (esp_wifi_get_country(&country) == ESP_OK) mask5 = country.wifi_5g_channel_mask;
#endif
    s_supported_n = 0;
    for (size_t i = 0; i < CH_ORDER_N; i++) {
        uint8_t ch = CH_ORDER[i];
        if (is_5ghz(ch)) {
            if (!s_has_5g) continue;
#if SOC_WIFI_SUPPORT_5G
            int bit = ch5_mask_bit(ch);
            if (mask5 != 0 && (bit < 0 || !(mask5 & (1u << bit)))) continue;
#endif
        }
        s_supported[s_supported_n++] = ch;
    }
    (void)mask5;
}

static void plan_reset_to_all(void) {
    portENTER_CRITICAL(&s_plan_lock);
    memcpy(s_plan, s_supported, s_supported_n);
    s_plan_n = s_supported_n;
    portEXIT_CRITICAL(&s_plan_lock);
}

static size_t plan_copy(uint8_t *out) {
    portENTER_CRITICAL(&s_plan_lock);
    size_t n = s_plan_n;
    memcpy(out, s_plan, n);
    portEXIT_CRITICAL(&s_plan_lock);
    return n;
}

static size_t parse_channel_list(const char *s, uint8_t *out) {
    size_t n = 0;
    while (*s && n < MAX_CHANNELS) {
        while (*s == ',' || *s == ' ') s++;
        if (*s < '0' || *s > '9') break;
        long v = strtol(s, (char **)&s, 10);
        if (v <= 0 || v > 255 || !channel_supported((uint8_t)v)) continue;
        bool dup = false;
        for (size_t i = 0; i < n; i++) if (out[i] == (uint8_t)v) dup = true;
        if (!dup) out[n++] = (uint8_t)v;
    }
    return n;
}

static int format_channel_list(char *buf, int len, int cap, const uint8_t *ch, size_t n) {
    for (size_t i = 0; i < n && len < cap - 5; i++)
        len += snprintf(buf + len, cap - len, i ? ",%u" : "%u", (unsigned)ch[i]);
    return len;
}

static size_t max_payload_per_notify(void) {
    uint16_t mtu = (s_conn_handle != BLE_HS_CONN_HANDLE_NONE) ? ble_att_mtu(s_conn_handle) : 23;
    if (mtu < 23) mtu = 23;
    size_t room = (size_t)mtu - 3;
    return room > FR_HEADER ? room - FR_HEADER : 1;
}

// Not put_le32: NimBLE's os/endian.h defines that name.
static void frame_put_u32(uint8_t *p, uint32_t v) { p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24; }

static void send_frame(uint8_t type, const uint8_t *payload, size_t len) {
    if (s_conn_handle == BLE_HS_CONN_HANDLE_NONE || !s_notify_enabled || s_tx_val_handle == 0) return;
    uint8_t frame[FR_HEADER + 256];
    if (len > sizeof(frame) - FR_HEADER) len = sizeof(frame) - FR_HEADER;
    memset(frame, 0, FR_HEADER);
    frame[0] = FR_MAGIC_0; frame[1] = FR_MAGIC_1; frame[2] = FR_VERSION; frame[3] = type;
    frame_put_u32(frame + 6, s_reply_id);
    frame[10] = len & 0xff; frame[11] = (len >> 8) & 0xff;
    if (len) memcpy(frame + FR_HEADER, payload, len);
    struct os_mbuf *om = ble_hs_mbuf_from_flat(frame, (uint16_t)(FR_HEADER + len));
    if (om) (void)ble_gatts_notify_custom(s_conn_handle, s_tx_val_handle, om);
}

static void send_line(const char *fmt, ...) {
    char line[256];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(line, sizeof(line) - 1, fmt, ap);
    va_end(ap);
    if (n <= 0) return;
    if (n > (int)sizeof(line) - 2) n = (int)sizeof(line) - 2;
    line[n++] = '\n';
    size_t step = max_payload_per_notify();
    for (size_t off = 0; off < (size_t)n; off += step) {
        size_t chunk = ((size_t)n - off < step) ? (size_t)n - off : step;
        send_frame(FR_DATA, (const uint8_t *)line + off, chunk);
    }
}

struct auth_name { wifi_auth_mode_t mode; const char *token; };
static const struct auth_name AUTH_NAMES[] = {
    { WIFI_AUTH_OPEN,            "OPEN" },
    { WIFI_AUTH_WEP,             "WEP" },
    { WIFI_AUTH_WPA_PSK,         "WPA" },
    { WIFI_AUTH_WPA2_PSK,        "WPA2" },
    { WIFI_AUTH_WPA_WPA2_PSK,    "WPA2" },
    { WIFI_AUTH_WPA2_ENTERPRISE, "WPA2" },
    { WIFI_AUTH_WPA3_PSK,        "WPA3" },
    { WIFI_AUTH_WPA2_WPA3_PSK,   "WPA2_WPA3" },
};

static const char *auth_name(wifi_auth_mode_t mode) {
    for (size_t i = 0; i < sizeof(AUTH_NAMES) / sizeof(AUTH_NAMES[0]); i++)
        if (AUTH_NAMES[i].mode == mode) return AUTH_NAMES[i].token;
    return "UNKNOWN";
}

static char lower_hex_digit(uint8_t v) { return (char)(v < 10 ? '0' + v : 'a' + (v - 10)); }

static void send_ap_line(const wifi_ap_record_t *ap) {
    size_t ssid_len = 0;
    while (ssid_len < sizeof(ap->ssid) && ap->ssid[ssid_len]) ssid_len++;
    char ssid_hex[2 * sizeof(ap->ssid) + 1];
    for (size_t i = 0; i < ssid_len; i++) {
        ssid_hex[2 * i]     = lower_hex_digit(ap->ssid[i] >> 4);
        ssid_hex[2 * i + 1] = lower_hex_digit(ap->ssid[i] & 0x0F);
    }
    ssid_hex[2 * ssid_len] = '\0';
    const uint8_t *b = ap->bssid;
    send_line("WD:AP ts=%lu bssid=%02X:%02X:%02X:%02X:%02X:%02X ssid_hex=%s rssi=%d ch=%u auth=%s hidden=%u",
              (unsigned long)(esp_timer_get_time() / 1000), b[0], b[1], b[2], b[3], b[4], b[5],
              ssid_hex, ap->rssi, (unsigned)ap->primary, auth_name(ap->authmode), ssid_len ? 0u : 1u);
    s_ap_count++;
}

static void send_caps_line(void) {
    char buf[200];
    int len = snprintf(buf, sizeof(buf), "WD:CAPS fw=%s chip=%s bands=%s chans=", FW_VERSION,
                       CONFIG_IDF_TARGET, s_has_5g ? "2g,5g" : "2g");
    format_channel_list(buf, len, sizeof(buf), s_supported, s_supported_n);
    send_line("%s", buf);
}

static void send_plan_line(void) {
    uint8_t plan[MAX_CHANNELS];
    size_t n = plan_copy(plan);
    char buf[160];
    int len = snprintf(buf, sizeof(buf), "WD:PLAN chans=");
    format_channel_list(buf, len, sizeof(buf), plan, n);
    send_line("%s", buf);
}

static void scan_one_channel(uint8_t ch) {
    wifi_scan_config_t cfg = { .channel = ch, .show_hidden = true };
    if (is_5ghz(ch)) {
        cfg.scan_type = WIFI_SCAN_TYPE_PASSIVE;
        cfg.scan_time.passive = PASSIVE_DWELL_MS;
    } else {
        cfg.scan_type = WIFI_SCAN_TYPE_ACTIVE;   // default dwell; coex rejects custom active times
    }
    if (esp_wifi_scan_start(&cfg, true) != ESP_OK) return;
    uint16_t found = 0;
    if (esp_wifi_scan_get_ap_num(&found) != ESP_OK || found == 0) return;
    if (found > MAX_AP_PER_SCAN) found = MAX_AP_PER_SCAN;
    wifi_ap_record_t *aps = calloc(found, sizeof(*aps));
    if (!aps) return;
    if (esp_wifi_scan_get_ap_records(&found, aps) == ESP_OK)
        for (uint16_t i = 0; i < found && s_streaming; i++) send_ap_line(&aps[i]);
    free(aps);
}

static void scan_task(void *arg) {
    (void)arg;
    s_ap_count = 0;
    send_caps_line();
    send_line("WD:BEGIN type=wifi interval=0 channel=auto");
    send_plan_line();
    uint32_t sweeps = 0;
    uint8_t plan[MAX_CHANNELS];
    while (s_streaming && s_conn_handle != BLE_HS_CONN_HANDLE_NONE) {
        size_t n = plan_copy(plan);
        for (size_t i = 0; i < n && s_streaming; i++) {
            scan_one_channel(plan[i]);
            vTaskDelay(pdMS_TO_TICKS(5));
        }
        if (n == 0) vTaskDelay(pdMS_TO_TICKS(200));
        sweeps++;
        send_line("WD:STATUS aps=%lu scans=%lu", (unsigned long)s_ap_count, (unsigned long)sweeps);
    }
    send_line("WD:END reason=stop");
    s_streaming = false;
    s_scan_task = NULL;
    vTaskDelete(NULL);
}

static void stream_start(void) {
    if (s_streaming || s_conn_handle == BLE_HS_CONN_HANDLE_NONE) return;
    s_streaming = true;
    if (xTaskCreate(scan_task, "wd_scan", 6144, NULL, 5, &s_scan_task) != pdPASS) {
        s_streaming = false;
        s_scan_task = NULL;
        ESP_LOGE(TAG, "scan task create failed");
        return;
    }
    status_led_set(STATUS_LED_STREAMING);
    ESP_LOGI(TAG, "stream started");
}

static void stream_stop(void) {
    s_streaming = false;
    (void)esp_wifi_scan_stop();
    if (s_conn_handle != BLE_HS_CONN_HANDLE_NONE) status_led_set(STATUS_LED_ADVERTISING);
}

static void handle_command(const uint8_t *data, uint16_t len) {
    const uint8_t *text = data;
    uint16_t text_len = len;
    if (len >= FR_HEADER && data[0] == FR_MAGIC_0 && data[1] == FR_MAGIC_1) {
        uint16_t plen = (uint16_t)(data[10] | (data[11] << 8));
        if (FR_HEADER + (size_t)plen <= len) {
            s_reply_id = (uint32_t)data[6] | ((uint32_t)data[7] << 8) | ((uint32_t)data[8] << 16) | ((uint32_t)data[9] << 24);
            if (data[3] == FR_CMD) {
                text = data + FR_HEADER;
                text_len = plen;
                send_frame(FR_ACK, NULL, 0);
            }
        }
    }
    char cmd[CMD_MAX + 1];
    size_t n = text_len < CMD_MAX ? text_len : CMD_MAX;
    memcpy(cmd, text, n);
    cmd[n] = '\0';
    ESP_LOGI(TAG, "cmd: '%s'", cmd);

    if (strstr(cmd, "stop")) { stream_stop(); return; }
    if (strstr(cmd, "caps")) { send_caps_line(); return; }

    const char *ch_arg = strstr(cmd, "-ch ");
    if (ch_arg) {
        uint8_t chans[MAX_CHANNELS];
        size_t count = parse_channel_list(ch_arg + 4, chans);
        if (count > 0) {
            portENTER_CRITICAL(&s_plan_lock);
            memcpy(s_plan, chans, count);
            s_plan_n = count;
            portEXIT_CRITICAL(&s_plan_lock);
            if (s_streaming) send_plan_line();
        } else {
            send_line("WD:ERR reason=no_supported_channels");
        }
    }
    stream_start();
}

static int on_command_write(uint16_t conn, uint16_t attr, struct ble_gatt_access_ctxt *ctxt, void *arg) {
    (void)conn; (void)attr; (void)arg;
    if (ctxt->op != BLE_GATT_ACCESS_OP_WRITE_CHR) return BLE_ATT_ERR_UNLIKELY;
    uint8_t buf[256];
    uint16_t got = 0;
    if (ble_hs_mbuf_to_flat(ctxt->om, buf, sizeof(buf), &got) != 0) return BLE_ATT_ERR_UNLIKELY;
    handle_command(buf, got);
    return 0;
}

static int on_tx_access(uint16_t conn, uint16_t attr, struct ble_gatt_access_ctxt *ctxt, void *arg) {
    (void)conn; (void)attr; (void)ctxt; (void)arg;
    return 0;
}

static const struct ble_gatt_chr_def CHARACTERISTICS[] = {
    { .uuid = &RX_UUID.u,   .access_cb = on_command_write, .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP },
    { .uuid = &TX_UUID.u,   .access_cb = on_tx_access,     .flags = BLE_GATT_CHR_F_NOTIFY, .val_handle = &s_tx_val_handle },
    { .uuid = &CTRL_UUID.u, .access_cb = on_command_write, .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP },
    { 0 },
};
static const struct ble_gatt_svc_def SERVICES[] = {
    { .type = BLE_GATT_SVC_TYPE_PRIMARY, .uuid = &SVC_UUID.u, .characteristics = CHARACTERISTICS },
    { 0 },
};

static void start_advertising(void) {
    struct ble_hs_adv_fields adv = {0};
    adv.flags = BLE_HS_ADV_F_DISC_GEN | BLE_HS_ADV_F_BREDR_UNSUP;
    adv.uuids128 = (ble_uuid128_t *)&SVC_UUID;
    adv.num_uuids128 = 1;
    adv.uuids128_is_complete = 1;
    if (ble_gap_adv_set_fields(&adv) != 0) { ESP_LOGE(TAG, "adv fields rejected"); return; }

    struct ble_hs_adv_fields scan_rsp = {0};
    scan_rsp.name = (const uint8_t *)s_name;
    scan_rsp.name_len = strlen(s_name);
    scan_rsp.name_is_complete = 1;
    (void)ble_gap_adv_rsp_set_fields(&scan_rsp);

    struct ble_gap_adv_params params = { .conn_mode = BLE_GAP_CONN_MODE_UND, .disc_mode = BLE_GAP_DISC_MODE_GEN };
    if (ble_gap_adv_start(s_own_addr_type, NULL, BLE_HS_FOREVER, &params, on_gap_event, NULL) != 0) {
        ESP_LOGE(TAG, "advertising failed to start");
        return;
    }
    status_led_set(STATUS_LED_ADVERTISING);
    ESP_LOGI(TAG, "advertising as '%s'", s_name);
}

static int on_gap_event(struct ble_gap_event *event, void *arg) {
    (void)arg;
    switch (event->type) {
    case BLE_GAP_EVENT_CONNECT:
        if (event->connect.status != 0) { start_advertising(); return 0; }
        s_conn_handle = event->connect.conn_handle;
        s_notify_enabled = false;
        plan_reset_to_all();
        ESP_LOGI(TAG, "phone connected");
        return 0;

    case BLE_GAP_EVENT_DISCONNECT:
        ESP_LOGI(TAG, "phone disconnected (reason %d)", event->disconnect.reason);
        s_conn_handle = BLE_HS_CONN_HANDLE_NONE;
        s_notify_enabled = false;
        stream_stop();
        plan_reset_to_all();
        start_advertising();
        return 0;

    case BLE_GAP_EVENT_SUBSCRIBE:
        if (event->subscribe.attr_handle != s_tx_val_handle) return 0;
        s_notify_enabled = event->subscribe.cur_notify;
        ESP_LOGI(TAG, "notifications %s", s_notify_enabled ? "on" : "off");
        if (s_notify_enabled) stream_start();
        else stream_stop();
        return 0;

    case BLE_GAP_EVENT_MTU:
        ESP_LOGI(TAG, "MTU %u", event->mtu.value);
        return 0;

    default:
        return 0;
    }
}

static void on_ble_sync(void) {
    if (ble_hs_util_ensure_addr(0) != 0) { ESP_LOGE(TAG, "no BLE address"); return; }
    if (ble_hs_id_infer_auto(0, &s_own_addr_type) != 0) s_own_addr_type = BLE_OWN_ADDR_PUBLIC;
    uint8_t addr[6] = {0};
    if (ble_hs_id_copy_addr(s_own_addr_type, addr, NULL) == 0)
        snprintf(s_name, sizeof(s_name), NAME_PREFIX "-%02X%02X", addr[1], addr[0]);
    (void)ble_svc_gap_device_name_set(s_name);
    start_advertising();
}

static void on_ble_reset(int reason) { ESP_LOGW(TAG, "BLE host reset: %d", reason); }

static void ble_host_task(void *param) {
    (void)param;
    nimble_port_run();
    nimble_port_freertos_deinit();
}

static void wifi_bring_up(void) {
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_wifi_set_storage(WIFI_STORAGE_RAM));
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_start());
#if SOC_WIFI_SUPPORT_5G
    esp_err_t err = esp_wifi_set_band_mode(WIFI_BAND_MODE_AUTO);
    s_has_5g = (err == ESP_OK);
    if (!s_has_5g) ESP_LOGW(TAG, "dual-band mode unavailable (%s), 2.4 GHz only", esp_err_to_name(err));
#endif
    build_supported_channels();
    plan_reset_to_all();
    ESP_LOGI(TAG, "%s: %u channels (%s)", CONFIG_IDF_TARGET, (unsigned)s_supported_n, s_has_5g ? "2.4 + 5 GHz" : "2.4 GHz");
}

void app_main(void) {
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }
    status_led_init();
    wifi_bring_up();

    ESP_ERROR_CHECK(nimble_port_init());
    ble_svc_gap_init();
    ble_svc_gatt_init();
    ESP_ERROR_CHECK(ble_gatts_count_cfg(SERVICES));
    ESP_ERROR_CHECK(ble_gatts_add_svcs(SERVICES));
    ESP_ERROR_CHECK(ble_svc_gap_device_name_set(s_name));

    ble_hs_cfg.sync_cb = on_ble_sync;
    ble_hs_cfg.reset_cb = on_ble_reset;
    nimble_port_freertos_init(ble_host_task);
    ESP_LOGI(TAG, "iosESP %s ready", FW_VERSION);
}
