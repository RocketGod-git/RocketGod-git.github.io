// WardriveESP — Wi-Fi and Bluetooth scanner for Wardrive Go over BLE and USB. Protocol: PROTOCOL.md
// SPDX-License-Identifier: MIT

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>

#include "sdkconfig.h"
#include "soc/soc_caps.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/stream_buffer.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "esp_ota_ops.h"
#include "esp_system.h"

#include "esp_log.h"
#include "esp_timer.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "nvs_flash.h"
#include "esp_chip_info.h"
#include "esp_flash.h"
#include "esp_mac.h"
#include "esp_attr.h"
#include "esp_heap_caps.h"
#include "esp_private/panic_internal.h"

#include "driver/uart.h"
#include "driver/uart_vfs.h"
#if SOC_USB_SERIAL_JTAG_SUPPORTED
#include "driver/usb_serial_jtag.h"
#include "driver/usb_serial_jtag_vfs.h"
#endif

#include "nimble/nimble_port.h"
#include "esp_bt.h"
#include "soc/soc_caps.h"
#if SOC_TEMP_SENSOR_SUPPORTED
#include "driver/temperature_sensor.h"
#endif
#include "driver/gpio.h"
#include "esp_private/esp_gpio_reserve.h"
#include "soc/uart_pins.h"
#if CONFIG_IDF_TARGET_ESP32C5 || CONFIG_IDF_TARGET_ESP32C6
#include "driver/i2c_master.h"
#include "driver/rmt_tx.h"
#include "esp_random.h"
#endif
#include "esp_rom_sys.h"
#include "display.h"
#if SOC_MODEM_CLOCK_SUPPORTED
#include "esp_private/esp_modem_clock.h"
#include "hal/modem_syscon_ll.h"
#endif
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "host/ble_att.h"
#include "host/util/util.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"


static const char *TAG = "WardriveESP";

#define FW_VERSION     "1.6.7"
// Shown by `info` and the boot log only. Never part of FW_VERSION: the apps compare versions number by number, so
// "1.6.6-dev" would read as 1.6.0 and get offered the published firmware as an "update".
#define FW_TAG         ""
#define NAME_PREFIX    "WardriveESP"

// USB transports (PROTOCOL.md "USB"): USB-Serial-JTAG on chips with native USB, UART0 for USB-UART bridge boards.
#define USB_JTAG_LINK  SOC_USB_SERIAL_JTAG_SUPPORTED
#if CONFIG_ESP_CONSOLE_UART && CONFIG_ESP_CONSOLE_UART_NUM == 0 && \
    !(defined(CONFIG_WARDRIVEESP_GPS_UART_NUM) && CONFIG_WARDRIVEESP_GPS_UART_NUM == 0)
#define UART_LINK      1
#define LINK_UART      UART_NUM_0
#else
#define UART_LINK      0
#endif

enum {
    FR_MAGIC_0 = 0x47, FR_MAGIC_1 = 0x42, FR_VERSION = 0x01, FR_HEADER = 12,
    FR_CMD = 1, FR_ACK = 2, FR_DATA = 3, FR_END = 4, FR_ERR = 5,
};

// What the board was doing, kept current in the hot paths and saved by the panic handler so the next boot can
// report it in WD:CRASH.
enum { CR_IDLE = 0, CR_SCAN, CR_RESULTS, CR_SEND_AP, CR_BT, CR_CAP, CR_OTA, CR_CMD, CR_GPS };
static volatile uint8_t  s_crumb = CR_IDLE;
static volatile uint8_t  s_crumb_ch = 0;
static volatile uint32_t s_heap_min_seen = 0;

#define CRASH_MAGIC 0x10E5C0DEu
typedef struct {
    uint32_t magic;
    uint32_t up_ms;
    uint32_t pc;
    uint32_t heap_min;
    uint8_t  crumb, ch, kind, core;
    char     task[16];
    char     reason[56];
} crash_rec_t;
enum { CK_PANIC = 1, CK_STACK = 2 };
static RTC_NOINIT_ATTR crash_rec_t s_crash;

static void IRAM_ATTR crash_copy(char *dst, size_t cap, const char *src) {
    size_t i = 0;
    if (src) for (; i + 1 < cap && src[i]; i++) dst[i] = src[i];
    dst[i] = '\0';
}

static void IRAM_ATTR crash_fill(uint8_t kind, const char *task, const char *reason, uint32_t pc, int core) {
    if (s_crash.magic == CRASH_MAGIC && s_crash.kind == CK_STACK) return;   // keep the more specific record
    s_crash.up_ms = (uint32_t)(esp_timer_get_time() / 1000);
    s_crash.pc = pc;
    s_crash.heap_min = s_heap_min_seen;
    s_crash.crumb = s_crumb;
    s_crash.ch = s_crumb_ch;
    s_crash.kind = kind;
    s_crash.core = (uint8_t)core;
    crash_copy(s_crash.task, sizeof(s_crash.task), task);
    crash_copy(s_crash.reason, sizeof(s_crash.reason), reason);
    s_crash.magic = CRASH_MAGIC;
}

void vApplicationStackOverflowHook(TaskHandle_t task, char *name) {
    (void)task;
    crash_fill(CK_STACK, name, "stack overflow", 0, 0);
    static char msg[48] = "Stack overflow in task ";   // static: this stack is already exhausted
    crash_copy(msg + 23, sizeof(msg) - 23, name ? name : "?");
    esp_system_abort(msg);
}

extern void __real_esp_panic_handler(panic_info_t *info);
void IRAM_ATTR __wrap_esp_panic_handler(panic_info_t *info) {
    TaskHandle_t cur = xTaskGetCurrentTaskHandle();
    crash_fill(CK_PANIC, cur ? pcTaskGetName(cur) : "?", info ? info->reason : NULL,
               info ? (uint32_t)(uintptr_t)info->addr : 0, info ? info->core : 0);
    __real_esp_panic_handler(info);
}

// UUIDs are least-significant byte first.
static const ble_uuid128_t SVC_UUID  = BLE_UUID128_INIT(
    0x76,0x53,0x65,0x67,0x64,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47);
static const ble_uuid128_t RX_UUID   = BLE_UUID128_INIT(
    0x52,0x58,0x67,0x64,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x01);
static const ble_uuid128_t TX_UUID   = BLE_UUID128_INIT(
    0x54,0x58,0x67,0x64,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x02);
static const ble_uuid128_t CTRL_UUID = BLE_UUID128_INIT(
    0x43,0x54,0x52,0x4C,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x03);
static const ble_uuid128_t OTA_UUID  = BLE_UUID128_INIT(
    0x44,0x41,0x54,0x4F,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x04);
static const ble_uuid128_t STATUS_UUID = BLE_UUID128_INIT(   // 0547686F-7374-4553-5042-726964675354 (1.6.5+)
    0x54,0x53,0x67,0x64,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x05);

#define OTA_WINDOW_MAX  (12 * 1024)   // max bytes the phone sends ahead of the last ack
#define OTA_ACK_STEP    (4 * 1024)
#define OTA_BUF_SLACK   (2 * 1024)

// Receive buffer sizes tried in order; a long-running board's heap may not have the largest block free.
static const size_t OTA_BUF_SIZES[] = { 24 * 1024, 16 * 1024, 10 * 1024, 6 * 1024 };

static StreamBufferHandle_t s_ota_buf;
static size_t s_ota_buf_bytes;
static uint32_t s_ota_window;
static uint32_t s_ota_ack_step;
static TaskHandle_t s_ota_task;
static esp_ota_handle_t s_ota_handle;
static const esp_partition_t *s_ota_part;
static volatile bool s_ota_active = false;
static volatile bool s_ota_end_req = false;
static volatile bool s_ota_abort_req = false;
static volatile uint32_t s_ota_size = 0;

// Output sinks: the BLE phone and one session per USB port. Every line goes to every linked host.
enum { SINK_BLE = 1, SINK_USB = 2, SINK_UART = 4, SINK_ALL = 7 };
static volatile uint8_t s_usb_sessions = 0;      // SINK_USB / SINK_UART ports with an open session
static volatile uint8_t s_ota_src = SINK_BLE;    // host running the update; gets the WD:OTA lines
static volatile uint8_t s_cmd_src = SINK_BLE;    // host whose command is running (under s_cmd_lock)

// Every channel the radio can tune. 5 GHz is always a passive scan / promiscuous RX here.
static const uint8_t CH_ORDER[] = { 1, 6, 11, 36, 40, 44, 48, 149, 153, 157, 161,
                                    52, 56, 60, 64, 100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144,
                                    165, 169, 173, 177,
                                    2, 3, 4, 5, 7, 8, 9, 10, 12, 13, 14 };
#define CH_ORDER_N       (sizeof(CH_ORDER) / sizeof(CH_ORDER[0]))
#define MAX_CHANNELS     CH_ORDER_N
#define PASSIVE_DWELL_MS 120
#define MAX_AP_PER_SCAN  60
#define CMD_MAX          240

static uint8_t  s_supported[MAX_CHANNELS];
static size_t   s_supported_n = 0;
static bool     s_has_5g = false;

static uint8_t  s_plan[MAX_CHANNELS];
static size_t   s_plan_n = 0;
static portMUX_TYPE s_plan_lock = portMUX_INITIALIZER_UNLOCKED;

static char     s_name[24] = NAME_PREFIX;
static uint8_t  s_own_addr_type;
static uint8_t  s_addr_tail[2];   // the two address bytes in the name ("WardriveESP-%02X%02X")
// Status beacon state (1.6.5, see start_beacon).
#define BEACON_FIXED 9
#define HOLDER_MAX   18
static char s_holder[HOLDER_MAX + 1];      // the linked app's nickname ("iam a|i <nickname>"), "" = didn't say
static bool s_holder_ios = false;
static struct ble_npl_callout s_beacon_tick;
static struct ble_npl_callout s_link_switch;   // USB session opened/closed: hand the Bluetooth side over (usb_link_switch)
static bool s_link_ready = false;              // both callouts exist (on_ble_sync)
static uint16_t s_conn_handle   = BLE_HS_CONN_HANDLE_NONE;
static uint16_t s_tx_val_handle = 0;
static volatile bool s_notify_enabled = false;
static volatile bool s_streaming      = false;
static TaskHandle_t  s_scan_task      = NULL;
static volatile uint32_t s_reply_id   = 1;
static volatile uint32_t s_ap_count   = 0;
static volatile uint32_t s_sweeps     = 0;
static volatile uint32_t s_last_aps   = 0;

static bool host_linked(void) { return s_conn_handle != BLE_HS_CONN_HANDLE_NONE || s_usb_sessions; }
static volatile bool s_bt_up = true;        // Bluetooth controller + host running (1.6.6: off while USB holds the board)
static volatile bool s_ble_synced = false;  // the host is synced with the controller, so GAP calls work
#if CONFIG_WARDRIVEESP_BENCH_TOOLS
static bool s_bench_keep_bt;   // `benchbt on`: keep Bluetooth up during USB sessions, to compare
#else
#define s_bench_keep_bt false
#endif

#if CONFIG_WARDRIVEESP_BENCH_TOOLS
// Bench builds: walk every heap at key points and log the first one that finds it corrupt, to pin down who corrupts it.
static volatile const char *s_heap_bad_at;
static void heap_check(const char *where) {
    if (s_heap_bad_at || xPortInIsrContext()) return;
    if (!heap_caps_check_integrity_all(true)) {
        s_heap_bad_at = where;
        esp_rom_printf("HEAPCHK FAIL first at %s (up %lu ms)\n", where, (unsigned long)(esp_timer_get_time() / 1000));
    }
}
#else
#define heap_check(where) ((void)0)
#endif

// Scan role: the board does exactly one of these at a time. A role switch lets any running task finish first,
// then the task that ends starts the new role (see set_role / stream_start). Reset to Wi-Fi when a host connects
// or disconnects with no other host linked. ROLE_CAP (1.5+) is passive 802.11 promiscuous capture — handshakes, PMKIDs, client sightings.
typedef enum { ROLE_WIFI = 0, ROLE_BT, ROLE_CAP } scan_role_t;
static volatile scan_role_t s_role = ROLE_WIFI;

// Bluetooth role: the board scans BLE instead of Wi-Fi.
#define BT_WINDOW_MS  10000
#define BT_QUEUE_LEN  48

typedef struct {
    uint8_t  mac[6];      // most significant byte first
    uint8_t  addr_type;
    int8_t   rssi;
    uint8_t  conn;
    uint8_t  name_len;
    char     name[29];
    uint8_t  has_company;
    uint16_t company;
} bt_rec_t;

static QueueHandle_t s_bt_queue;
static TaskHandle_t  s_bt_task          = NULL;
static volatile bool s_bt_running       = false;
static volatile bool s_bt_window_done   = false;
static volatile bool s_switch_pending   = false;
static volatile uint32_t s_bt_count     = 0;
static volatile uint32_t s_bt_windows   = 0;
static volatile uint32_t s_bt_last      = 0;
static volatile uint32_t s_bt_dropped   = 0;

// GPS role (PROTOCOL.md "GPS", firmware 1.4+): an optional UART NMEA receiver. The task runs continuously and
// emits WD:GPS whenever it parses a valid fix; the phone uses it as a location source when its own fix is stale
// or absent. `s_gps_present` is set only once a valid fix is parsed (runtime presence-detection, like s_has_5g),
// so a board without a GPS wired up never claims the capability. It's read by WD:CAPS whether or not GPS is
// compiled in (always 0 then), so it lives outside the build guard; the fix fields only exist when GPS is on.
static volatile bool s_gps_present = false;
static TaskHandle_t s_gps_task = NULL;

static int  on_gap_event(struct ble_gap_event *event, void *arg);
static void start_advertising(void);
static void stream_start(void);
static void bt_power_kick(void);

static bool is_5ghz(uint8_t ch) { return ch > 14; }
static bool is_dfs(uint8_t ch) { return (ch >= 52 && ch <= 64) || (ch >= 100 && ch <= 144); }

static bool channel_supported(uint8_t ch) {
    for (size_t i = 0; i < s_supported_n; i++) if (s_supported[i] == ch) return true;
    return false;
}

// Open the radio to every channel it can tune (2.4 GHz 1-14, all 5 GHz) so the scan list isn't trimmed.
static void open_all_channels(void) {
    wifi_country_t all = {
        .cc = "01",
        .schan = 1,
        .nchan = 14,
        .policy = WIFI_COUNTRY_POLICY_MANUAL,
    };
#if SOC_WIFI_SUPPORT_5G
    all.wifi_5g_channel_mask = 0xFFFFFFFFu;
#endif
    esp_err_t err = esp_wifi_set_country(&all);
    if (err != ESP_OK) ESP_LOGW(TAG, "set_country: %s", esp_err_to_name(err));
}

static void build_supported_channels(void) {
    s_supported_n = 0;
    for (size_t i = 0; i < CH_ORDER_N; i++) {
        uint8_t ch = CH_ORDER[i];
        if (is_5ghz(ch) && !s_has_5g) continue;
        s_supported[s_supported_n++] = ch;
    }
}

static void plan_reset_to_all(void) {
    portENTER_CRITICAL(&s_plan_lock);
    memcpy(s_plan, s_supported, s_supported_n);
    s_plan_n = s_supported_n;
    portEXIT_CRITICAL(&s_plan_lock);
}

static size_t plan_copy(uint8_t *out) {
    portENTER_CRITICAL(&s_plan_lock);
    size_t n = s_plan_n;
    memcpy(out, s_plan, n);
    portEXIT_CRITICAL(&s_plan_lock);
    return n;
}

static size_t parse_channel_list(const char *s, uint8_t *out) {
    size_t n = 0;
    while (*s && n < MAX_CHANNELS) {
        while (*s == ',' || *s == ' ') s++;
        if (*s < '0' || *s > '9') break;
        long v = strtol(s, (char **)&s, 10);
        if (v <= 0 || v > 255 || !channel_supported((uint8_t)v)) continue;
        bool dup = false;
        for (size_t i = 0; i < n; i++) if (out[i] == (uint8_t)v) dup = true;
        if (!dup) out[n++] = (uint8_t)v;
    }
    return n;
}

static int format_channel_list(char *buf, int len, int cap, const uint8_t *ch, size_t n) {
    for (size_t i = 0; i < n && len < cap - 5; i++)
        len += snprintf(buf + len, cap - len, i ? ",%u" : "%u", (unsigned)ch[i]);
    return len;
}

static size_t max_payload_per_notify(void) {
    uint16_t mtu = (s_bt_up && s_conn_handle != BLE_HS_CONN_HANDLE_NONE) ? ble_att_mtu(s_conn_handle) : 23;
    if (mtu < 23) mtu = 23;
    size_t room = (size_t)mtu - 3;
    return room > FR_HEADER ? room - FR_HEADER : 1;
}

// Serializes each line to every host, so one line's BLE frames and USB bytes are never interleaved with another's
// (scan, GPS, health and command tasks all send).
static SemaphoreHandle_t s_send_lock;

// Not put_le32: NimBLE's os/endian.h defines that name.
static void frame_put_u32(uint8_t *p, uint32_t v) { p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24; }

// Buffers shared by every sender; only touched while s_send_lock is held. Kept off the task stacks.
static uint8_t s_frame[FR_HEADER + 256];
static char    s_line[384];   // WD:CAPS with every board key and 42 channels runs past 256

static void send_frame(uint8_t type, const uint8_t *payload, size_t len) {
    if (!s_bt_up || s_conn_handle == BLE_HS_CONN_HANDLE_NONE || !s_notify_enabled || s_tx_val_handle == 0) return;
    uint8_t *frame = s_frame;
    if (len > sizeof(s_frame) - FR_HEADER) len = sizeof(s_frame) - FR_HEADER;
    memset(frame, 0, FR_HEADER);
    frame[0] = FR_MAGIC_0; frame[1] = FR_MAGIC_1; frame[2] = FR_VERSION; frame[3] = type;
    frame_put_u32(frame + 6, s_reply_id);
    frame[10] = len & 0xff; frame[11] = (len >> 8) & 0xff;
    if (len) memcpy(frame + FR_HEADER, payload, len);
    struct os_mbuf *om = ble_hs_mbuf_from_flat(frame, (uint16_t)(FR_HEADER + len));
    if (om) (void)ble_gatts_notify_custom(s_conn_handle, s_tx_val_handle, om);
}

static void send_ack(void) {
    if (!s_bt_up || s_conn_handle == BLE_HS_CONN_HANDLE_NONE || !s_notify_enabled || s_tx_val_handle == 0) return;
    uint8_t frame[FR_HEADER] = { FR_MAGIC_0, FR_MAGIC_1, FR_VERSION, FR_ACK };
    frame_put_u32(frame + 6, s_reply_id);
    struct os_mbuf *om = ble_hs_mbuf_from_flat(frame, FR_HEADER);
    if (om) (void)ble_gatts_notify_custom(s_conn_handle, s_tx_val_handle, om);
}

static void send_chunks_locked(const char *buf, size_t n) {
    size_t step = max_payload_per_notify();
    for (size_t off = 0; off < n; off += step) {
        size_t chunk = (n - off < step) ? n - off : step;
        send_frame(FR_DATA, (const uint8_t *)buf + off, chunk);
    }
}

static void usb_emit_locked(uint8_t sinks, const char *buf, size_t n);

// The one output path: a built line (newline included) to the selected hosts. BLE gets MTU-sized DATA frames,
// USB sessions get the raw line.
static void emit_locked(uint8_t sinks, const char *buf, size_t n) {
    if (sinks & SINK_BLE) send_chunks_locked(buf, n);
    if (sinks & s_usb_sessions) usb_emit_locked(sinks, buf, n);
}

// For lines longer than s_line (the capture role's WD:HS).
static void send_chunks(const char *buf, size_t n) {
    if (!s_send_lock) return;
    xSemaphoreTake(s_send_lock, portMAX_DELAY);
    emit_locked(SINK_ALL, buf, n);
    xSemaphoreGive(s_send_lock);
}

static void send_vline(uint8_t sinks, const char *fmt, va_list ap) {
    if (!s_send_lock) return;
    xSemaphoreTake(s_send_lock, portMAX_DELAY);
    int n = vsnprintf(s_line, sizeof(s_line) - 1, fmt, ap);
    if (n > 0) {
        if (n > (int)sizeof(s_line) - 2) n = (int)sizeof(s_line) - 2;
        s_line[n++] = '\n';
        emit_locked(sinks, s_line, (size_t)n);
    }
    xSemaphoreGive(s_send_lock);
}

static void send_line_to(uint8_t sinks, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    send_vline(sinks, fmt, ap);
    va_end(ap);
}

static void send_line(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    send_vline(SINK_ALL, fmt, ap);
    va_end(ap);
}

struct auth_name { wifi_auth_mode_t mode; const char *token; };
static const struct auth_name AUTH_NAMES[] = {
    { WIFI_AUTH_OPEN,            "OPEN" },
    { WIFI_AUTH_WEP,             "WEP" },
    { WIFI_AUTH_WPA_PSK,         "WPA" },
    { WIFI_AUTH_WPA2_PSK,        "WPA2" },
    { WIFI_AUTH_WPA_WPA2_PSK,    "WPA2" },
    { WIFI_AUTH_WPA2_ENTERPRISE, "WPA2" },
    { WIFI_AUTH_WPA3_PSK,        "WPA3" },
    { WIFI_AUTH_WPA2_WPA3_PSK,   "WPA2_WPA3" },
};

static const char *auth_name(wifi_auth_mode_t mode) {
    for (size_t i = 0; i < sizeof(AUTH_NAMES) / sizeof(AUTH_NAMES[0]); i++)
        if (AUTH_NAMES[i].mode == mode) return AUTH_NAMES[i].token;
    return "UNKNOWN";
}

static char lower_hex_digit(uint8_t v) { return (char)(v < 10 ? '0' + v : 'a' + (v - 10)); }

static void send_ap_line(const wifi_ap_record_t *ap) {
    size_t ssid_len = 0;
    while (ssid_len < sizeof(ap->ssid) && ap->ssid[ssid_len]) ssid_len++;
    char ssid_hex[2 * sizeof(ap->ssid) + 1];
    for (size_t i = 0; i < ssid_len; i++) {
        ssid_hex[2 * i]     = lower_hex_digit(ap->ssid[i] >> 4);
        ssid_hex[2 * i + 1] = lower_hex_digit(ap->ssid[i] & 0x0F);
    }
    ssid_hex[2 * ssid_len] = '\0';
    const uint8_t *b = ap->bssid;
    send_line("WD:AP ts=%lu bssid=%02X:%02X:%02X:%02X:%02X:%02X ssid_hex=%s rssi=%d ch=%u auth=%s hidden=%u",
              (unsigned long)(esp_timer_get_time() / 1000), b[0], b[1], b[2], b[3], b[4], b[5],
              ssid_hex, ap->rssi, (unsigned)ap->primary, auth_name(ap->authmode), ssid_len ? 0u : 1u);
    s_ap_count++;
    display_note_ap(ap->bssid, ap->primary);
}

static const char *sink_name(uint8_t sink) { return sink == SINK_USB ? "usb" : sink == SINK_UART ? "uart" : "ble"; }

static int  s_led_n;      // WS2812 pixels this board drives, 0 = none (see "Board identity" below)
static char s_board_caps[64];   // "board=<id> board_name=<Name_With_Underscores> " once a board is identified
static bool s_has_batt;   // a battery gauge answered (on this chip's I2C, or through a co-processor)

// One WD:CAPS per host, each naming the transport it is sent on. A board with a ring adds led=ring<N>, one with a
// battery gauge batt=1.
static void send_caps_to(uint8_t sinks) {
    static const uint8_t EACH[] = { SINK_BLE, SINK_USB, SINK_UART };
    char buf[384];
    for (size_t i = 0; i < sizeof(EACH); i++) {
        if (!(sinks & EACH[i]) || (EACH[i] != SINK_BLE && !(s_usb_sessions & EACH[i]))) continue;
        char extra[128] = "";
        strlcpy(extra, s_board_caps, sizeof(extra));
        if (s_led_n) snprintf(extra + strlen(extra), sizeof(extra) - strlen(extra), "led=ring%d ", s_led_n);
        if (s_has_batt) strlcat(extra, "batt=1 ", sizeof(extra));
        if (display_running()) strlcat(extra, "disp=128x32 ", sizeof(extra));
        int len = snprintf(buf, sizeof(buf), "WD:CAPS fw=%s chip=%s bands=%s ota=1 bt=1 gps=%d cap=1 usb=1 %slink=%s chans=",
                           FW_VERSION, CONFIG_IDF_TARGET, s_has_5g ? "2g,5g" : "2g", s_gps_present ? 1 : 0,
                           extra, sink_name(EACH[i]));
        format_channel_list(buf, len, sizeof(buf), s_supported, s_supported_n);
        send_line_to(EACH[i], "%s", buf);
    }
}

static void send_caps_line(void) { send_caps_to(SINK_ALL); }

static void send_plan_to(uint8_t sinks) {
    uint8_t plan[MAX_CHANNELS];
    size_t n = plan_copy(plan);
    char buf[200];
    int len = snprintf(buf, sizeof(buf), "WD:PLAN chans=");
    format_channel_list(buf, len, sizeof(buf), plan, n);
    send_line_to(sinks, "%s", buf);
}

static void send_plan_line(void) { send_plan_to(SINK_ALL); }

// ─── Bluetooth role (PROTOCOL.md "Bluetooth") ─────────────────────────────
// Discovery runs in BT_WINDOW_MS windows with duplicate filtering, so each device is reported about once per
// window. Reports are queued from the host task and sent from bt_task.
static const char *bt_addr_type_name(uint8_t t) {
    return (t == BLE_ADDR_PUBLIC || t == BLE_ADDR_PUBLIC_ID) ? "public" : "random";
}

static void send_bt_line(const bt_rec_t *r) {
    char name_hex[2 * sizeof(r->name) + 1];
    for (size_t i = 0; i < r->name_len; i++) {
        name_hex[2 * i]     = lower_hex_digit((uint8_t)r->name[i] >> 4);
        name_hex[2 * i + 1] = lower_hex_digit((uint8_t)r->name[i] & 0x0F);
    }
    name_hex[2 * r->name_len] = '\0';
    char mfg[8] = "";
    if (r->has_company) snprintf(mfg, sizeof(mfg), "%04X", (unsigned)r->company);
    const uint8_t *m = r->mac;
    send_line("WD:BT ts=%lu mac=%02X:%02X:%02X:%02X:%02X:%02X type=%s rssi=%d name_hex=%s mfg=%s conn=%u",
              (unsigned long)(esp_timer_get_time() / 1000), m[0], m[1], m[2], m[3], m[4], m[5],
              bt_addr_type_name(r->addr_type), r->rssi, name_hex, mfg, (unsigned)r->conn);
    s_bt_count++;
}

static int on_disc_event(struct ble_gap_event *event, void *arg) {
    (void)arg;
    if (event->type == BLE_GAP_EVENT_DISC) {
        const struct ble_gap_disc_desc *d = &event->disc;
        bt_rec_t r = {0};
        for (int i = 0; i < 6; i++) r.mac[i] = d->addr.val[5 - i];
        r.addr_type = d->addr.type;
        r.rssi = d->rssi;
        r.conn = (d->event_type == BLE_HCI_ADV_RPT_EVTYPE_ADV_IND || d->event_type == BLE_HCI_ADV_RPT_EVTYPE_DIR_IND);
        struct ble_hs_adv_fields f;
        if (ble_hs_adv_parse_fields(&f, d->data, d->length_data) == 0) {
            if (f.name && f.name_len) {
                r.name_len = f.name_len > sizeof(r.name) ? sizeof(r.name) : f.name_len;
                memcpy(r.name, f.name, r.name_len);
            }
            if (f.mfg_data && f.mfg_data_len >= 2) {
                r.company = (uint16_t)(f.mfg_data[0] | (f.mfg_data[1] << 8));
                r.has_company = 1;
            }
        }
        if (!s_bt_queue || xQueueSend(s_bt_queue, &r, 0) != pdTRUE) s_bt_dropped++;
    } else if (event->type == BLE_GAP_EVENT_DISC_COMPLETE) {
        s_bt_window_done = true;
    }
    return 0;
}

static int bt_disc_start(void) {
    struct ble_gap_disc_params p = {
        .itvl = 0x50, .window = 0x30,   // 50 ms interval, 30 ms window: leaves room for the phone link
        .filter_policy = 0, .limited = 0, .passive = 0, .filter_duplicates = 1,
    };
    s_bt_window_done = false;
    return ble_gap_disc(s_own_addr_type, BT_WINDOW_MS, &p, on_disc_event, NULL);
}

static void bt_task(void *arg) {
    (void)arg;
    s_crumb = CR_BT;
    send_line("WD:MODE mode=bt");
    send_line("WD:BEGIN type=bt interval=0 channel=auto");
    s_bt_windows = 0;
    s_bt_count = 0;
    s_bt_dropped = 0;
    for (int t = 0; !s_ble_synced && t < 250 && s_bt_running; t++) vTaskDelay(pdMS_TO_TICKS(20));   // Bluetooth starting
    int fails = 0;
    int rc = bt_disc_start();
    bool scanning = (rc == 0);
    if (!scanning) { send_line("WD:ERR reason=bt_scan_failed rc=%d", rc); fails = 1; }
    bt_rec_t r;
    while (s_bt_running && host_linked()) {
        if (xQueueReceive(s_bt_queue, &r, pdMS_TO_TICKS(100)) == pdTRUE) { send_bt_line(&r); continue; }
        if (scanning && !s_bt_window_done) continue;
        if (scanning) {
            s_bt_windows++;
            s_bt_last = s_bt_count;
            send_line("WD:STATUS bt=%lu scans=%lu dropped=%lu", (unsigned long)s_bt_count,
                      (unsigned long)s_bt_windows, (unsigned long)s_bt_dropped);
            s_bt_count = 0;
            s_bt_dropped = 0;
        }
        rc = bt_disc_start();
        scanning = (rc == 0);
        if (scanning) { fails = 0; continue; }
        send_line("WD:ERR reason=bt_scan_failed rc=%d", rc);
        if (++fails >= 5) break;
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
    if (ble_gap_disc_active()) ble_gap_disc_cancel();
    for (int i = 1; xQueueReceive(s_bt_queue, &r, 0) == pdTRUE; i++) {   // send what was queued before the stop
        send_bt_line(&r);
        if (i % 4 == 0) vTaskDelay(1);
    }
    send_line("WD:END reason=stop");
    s_bt_running = false;
    s_bt_task = NULL;
    bt_power_kick();
    if (s_switch_pending) { s_switch_pending = false; stream_start(); }
    vTaskDelete(NULL);
}

static void bt_start(void) {
    if (s_bt_running || s_bt_task || s_ota_active || !host_linked()) return;
    if (!s_bt_queue) s_bt_queue = xQueueCreate(BT_QUEUE_LEN, sizeof(bt_rec_t));
    if (!s_bt_queue) { send_line("WD:ERR reason=no_memory"); return; }
    s_bt_running = true;
    if (xTaskCreate(bt_task, "wd_bt", 6144, NULL, 5, &s_bt_task) != pdPASS) {
        s_bt_running = false;
        s_bt_task = NULL;
        send_line("WD:ERR reason=no_task");
        return;
    }
    ESP_LOGI(TAG, "bluetooth scan started");
}

// ─── GPS role (PROTOCOL.md "GPS", firmware 1.4+) ──────────────────────────
#if CONFIG_WARDRIVEESP_GPS_ENABLE
static volatile double s_gps_lat = 0, s_gps_lon = 0, s_gps_alt = 0;
static volatile bool   s_gps_has_alt = false;
static volatile int    s_gps_sats = 0;
static volatile bool   s_gps_dirty = false;   // a new valid fix parsed since the last WD:GPS emit

// Fixed-point format a signed double into `buf` with `dec` fractional digits (scale = 10^dec), using only
// integer printf conversions — the firmware may be built with newlib's nano formatting, which drops %f, so
// WD:GPS coordinates must not go through %f. lat/lon/alt all fit comfortably in a 32-bit long after scaling.
static void fmt_fixed(char *buf, size_t cap, double v, long scale, int dec) {
    bool neg = v < 0; if (neg) v = -v;
    long scaled = (long)(v * (double)scale + 0.5);
    snprintf(buf, cap, "%s%ld.%0*ld", neg ? "-" : "", scaled / scale, dec, scaled % scale);
}

// NMEA ddmm.mmmm (lat) / dddmm.mmmm (lon) → signed decimal degrees. Hemisphere 'S'/'W' negates.
static double nmea_coord(const char *v, const char *hemi) {
    if (!v || !*v) return 0;
    double raw = atof(v);
    double deg = (double)((int)(raw / 100.0));
    double val = deg + (raw - deg * 100.0) / 60.0;
    if (hemi && (*hemi == 'S' || *hemi == 's' || *hemi == 'W' || *hemi == 'w')) val = -val;
    return val;
}

// Parse one NMEA sentence (NUL-terminated, no trailing CR/LF). We read $??GGA (lat/lon/alt/fix/sats) and
// $??RMC (lat/lon/fix) — any talker id (GP/GN/GA/GL/GB). A fix updates the shared state and flags an emit.
static void handle_nmea(char *line) {
    if (line[0] != '$' || strlen(line) < 7) return;
    const char *type = line + 3;                 // skip '$' + 2-char talker id
    bool gga = (strncmp(type, "GGA", 3) == 0);
    bool rmc = (strncmp(type, "RMC", 3) == 0);
    if (!gga && !rmc) return;
    char *star = strchr(line, '*'); if (star) *star = '\0';   // drop the *CS checksum
    // Split on commas, preserving empty fields (strtok would collapse them — NMEA has many).
    char *f[20]; int nf = 0; f[nf++] = line;
    for (char *p = line; *p && nf < 20; p++) if (*p == ',') { *p = '\0'; f[nf++] = p + 1; }

    double lat, lon;
    if (gga) {
        if (nf < 10 || atoi(f[6]) <= 0) return;  // fix quality 0 = no fix
        lat = nmea_coord(f[2], f[3]); lon = nmea_coord(f[4], f[5]);
        if (lat == 0 && lon == 0) return;
        s_gps_lat = lat; s_gps_lon = lon;
        s_gps_sats = atoi(f[7]);
        if (f[9][0]) { s_gps_alt = atof(f[9]); s_gps_has_alt = true; }
    } else {                                     // RMC — no altitude/sats; keep the last GGA's
        if (nf < 7 || f[2][0] != 'A') return;    // status V = void (no fix)
        lat = nmea_coord(f[3], f[4]); lon = nmea_coord(f[5], f[6]);
        if (lat == 0 && lon == 0) return;
        s_gps_lat = lat; s_gps_lon = lon;
    }
    s_gps_present = true;                         // runtime presence-detect: now WD:CAPS can advertise gps=1
    s_gps_dirty = true;
}

static bool board_pin_busy(int gpio);

// GPS pins to listen on, first answer wins: the configured pin (read exactly as before), then on an ESP32-C6 GPIO 2 @
// 9600, where some boards (the Rabbit Labs Ghost Board) have a module built in. Input only, so a pin with nothing
// wired to it costs nothing.
static const struct { int rx, baud; } GPS_TRY[] = {
    { CONFIG_WARDRIVEESP_GPS_RX_GPIO, CONFIG_WARDRIVEESP_GPS_BAUD },
#if CONFIG_IDF_TARGET_ESP32C6
    { 2, 9600 },
#endif
};

/// A GPS module streams NMEA ("$G…") from power-up, fix or not.
static bool gps_listen(uart_port_t port, int rx, int baud, uint32_t ms) {
    uart_set_baudrate(port, (uint32_t)baud);
    uart_set_pin(port, UART_PIN_NO_CHANGE, rx, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    uart_flush_input(port);
    uint8_t buf[128];
    char prev = 0;
    uint32_t t0 = (uint32_t)(esp_timer_get_time() / 1000);
    while ((uint32_t)(esp_timer_get_time() / 1000) - t0 < ms) {
        int n = uart_read_bytes(port, buf, sizeof(buf), pdMS_TO_TICKS(100));
        for (int i = 0; i < n; i++) { if (prev == '$' && buf[i] == 'G') return true; prev = (char)buf[i]; }
    }
    return false;
}

static void gps_task(void *arg) {
    (void)arg;
    const uart_port_t port = CONFIG_WARDRIVEESP_GPS_UART_NUM;
    uart_config_t cfg = {
        .baud_rate = CONFIG_WARDRIVEESP_GPS_BAUD,
        .data_bits = UART_DATA_8_BITS,
        .parity    = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    if (uart_driver_install(port, 1024, 0, 0, NULL, 0) != ESP_OK) { vTaskDelete(NULL); return; }
    uart_param_config(port, &cfg);
    int tx = CONFIG_WARDRIVEESP_GPS_TX_GPIO, rx = -1, baud = CONFIG_WARDRIVEESP_GPS_BAUD;
    for (size_t i = 0; i < sizeof(GPS_TRY) / sizeof(GPS_TRY[0]) && rx < 0; i++) {
        if (board_pin_busy(GPS_TRY[i].rx)) continue;
        if (gps_listen(port, GPS_TRY[i].rx, GPS_TRY[i].baud, 2500)) { rx = GPS_TRY[i].rx; baud = GPS_TRY[i].baud; }
        else if (GPS_TRY[i].rx != CONFIG_WARDRIVEESP_GPS_RX_GPIO) gpio_reset_pin(GPS_TRY[i].rx);
    }
    if (rx >= 0) {
        ESP_LOGI(TAG, "GPS: NMEA on GPIO %d @ %d baud", rx, baud);   // gps=1 in WD:CAPS once it has a fix, as always
    } else if (board_pin_busy(CONFIG_WARDRIVEESP_GPS_RX_GPIO)) {
        ESP_LOGI(TAG, "GPS: GPIO %d belongs to this board's battery gauge, GPS off", CONFIG_WARDRIVEESP_GPS_RX_GPIO);
        uart_driver_delete(port);
        s_gps_task = NULL;
        vTaskDelete(NULL);
        return;
    } else {
        rx = CONFIG_WARDRIVEESP_GPS_RX_GPIO;   // nothing yet: keep listening where a module is configured
        ESP_LOGI(TAG, "GPS: no NMEA heard, listening on GPIO %d @ %d baud", rx, baud);
    }
    uart_set_baudrate(port, (uint32_t)baud);
    uart_set_pin(port, tx >= 0 ? tx : UART_PIN_NO_CHANGE, rx, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    char line[128]; int li = 0;
    uint8_t buf[128];
    uint32_t last_emit = 0;
    for (;;) {
        int n = uart_read_bytes(port, buf, sizeof(buf), pdMS_TO_TICKS(200));
        for (int i = 0; i < n; i++) {
            char c = (char)buf[i];
            if (c == '\n' || c == '\r') { if (li > 0) { line[li] = '\0'; handle_nmea(line); li = 0; } }
            else if (li < (int)sizeof(line) - 1) line[li++] = c;
            else li = 0;                           // oversized/garbled line — drop it
        }
        // Emit at most once a second, only while connected (send_line no-ops when there's no link).
        uint32_t now = (uint32_t)(esp_timer_get_time() / 1000);
        if (s_gps_dirty && now - last_emit >= 1000) {
            s_gps_dirty = false; last_emit = now;
            char latb[20], lonb[20], altb[16];
            fmt_fixed(latb, sizeof(latb), s_gps_lat, 1000000, 6);
            fmt_fixed(lonb, sizeof(lonb), s_gps_lon, 1000000, 6);
            if (s_gps_has_alt) {
                fmt_fixed(altb, sizeof(altb), s_gps_alt, 10, 1);
                send_line("WD:GPS ts=%lu lat=%s lon=%s alt=%s fix=1 sats=%d",
                          (unsigned long)now, latb, lonb, altb, s_gps_sats);
            } else {
                send_line("WD:GPS ts=%lu lat=%s lon=%s fix=1 sats=%d",
                          (unsigned long)now, latb, lonb, s_gps_sats);
            }
        }
    }
}
#endif  // CONFIG_WARDRIVEESP_GPS_ENABLE

static void scan_one_channel(uint8_t ch) {
    wifi_scan_config_t cfg = { .channel = ch, .show_hidden = true };
    if (is_5ghz(ch) || is_dfs(ch)) {
        cfg.scan_type = WIFI_SCAN_TYPE_PASSIVE;
        cfg.scan_time.passive = PASSIVE_DWELL_MS;
    } else {
        cfg.scan_type = WIFI_SCAN_TYPE_ACTIVE;   // default dwell; coex rejects custom active times
    }
    s_crumb_ch = ch;
    s_crumb = CR_SCAN;
    if (esp_wifi_scan_start(&cfg, true) != ESP_OK) { s_crumb = CR_IDLE; return; }
    s_crumb = CR_RESULTS;
    uint16_t found = 0;
    if (esp_wifi_scan_get_ap_num(&found) != ESP_OK || found == 0) { s_crumb = CR_IDLE; return; }
    if (found > MAX_AP_PER_SCAN) found = MAX_AP_PER_SCAN;
    wifi_ap_record_t *aps = calloc(found, sizeof(*aps));
    if (!aps) return;
    s_crumb = CR_SEND_AP;
    if (esp_wifi_scan_get_ap_records(&found, aps) == ESP_OK)
        for (uint16_t i = 0; i < found; i++) send_ap_line(&aps[i]);
    free(aps);
    s_crumb = CR_IDLE;
}

static char s_boot_line[220];   // built at boot by boot_diag_begin()
static char s_crash_line[200];  // WD:CRASH for the previous run, when it ended in a crash or watchdog reset

static volatile uint32_t s_conns = 0, s_last_disc_reason = 0, s_last_disc_ms = 0;
static volatile uint32_t s_conn_since_ms = 0;   // when the current Bluetooth link came up

static void send_link_line(uint8_t sinks) {
    uint16_t mtu = s_bt_up && s_conn_handle != BLE_HS_CONN_HANDLE_NONE ? ble_att_mtu(s_conn_handle) : 0;
    uint32_t now = (uint32_t)(esp_timer_get_time() / 1000);
    if (s_last_disc_ms)
        send_line_to(sinks, "WD:LINK conns=%lu mtu=%u prev_disc=0x%03lx prev_disc_ago=%lus", (unsigned long)s_conns,
                     (unsigned)mtu, (unsigned long)s_last_disc_reason, (unsigned long)((now - s_last_disc_ms) / 1000));
    else
        send_line_to(sinks, "WD:LINK conns=%lu mtu=%u prev_disc=none", (unsigned long)s_conns, (unsigned)mtu);
}

/// Ask the phone for link timing inside Apple's accessory guidelines. Normal: 30-50 ms interval, no latency, 5 s
/// supervision timeout. A phone holding many boards fits them into its radio schedule more easily, and a board busy on
/// Wi-Fi (radio coexistence) can miss a few connection events without the link dropping. Scan lines need far less than
/// this carries at a 247-byte MTU. A firmware update over BLE asks for 15-30 ms while it runs. The phone may refuse.
static void request_link_params(bool fast) {
    if (s_conn_handle == BLE_HS_CONN_HANDLE_NONE) return;
    struct ble_gap_upd_params p = {
        .itvl_min = fast ? 12 : 24,      // 1.25 ms units: 15 / 30 ms
        .itvl_max = fast ? 24 : 40,      // 30 / 50 ms
        .latency = 0,
        .supervision_timeout = 500,      // 10 ms units: 5 s
        .min_ce_len = 0,
        .max_ce_len = 0,
    };
    int rc = ble_gap_update_params(s_conn_handle, &p);
    if (rc != 0) ESP_LOGW(TAG, "link timing request failed: %d", rc);
}

/// The link timing in use after the phone answered a request (or changed it on its own).
static void send_conn_line(int status) {
    struct ble_gap_conn_desc d;
    if (s_conn_handle == BLE_HS_CONN_HANDLE_NONE || ble_gap_conn_find(s_conn_handle, &d) != 0) return;
    ESP_LOGI(TAG, "link timing: status %d, interval %u x 1.25 ms, latency %u, timeout %u x 10 ms", status,
             (unsigned)d.conn_itvl, (unsigned)d.conn_latency, (unsigned)d.supervision_timeout);
    send_line_to(SINK_BLE, "WD:CONN itvl_ms=%u latency=%u timeout_ms=%u status=%d", (unsigned)(d.conn_itvl * 5 / 4),
                 (unsigned)d.conn_latency, (unsigned)d.supervision_timeout * 10, status);
}

static void send_header(uint8_t sinks) {
    send_caps_to(sinks);
    if (s_boot_line[0]) send_line_to(sinks, "%s", s_boot_line);
    if (s_crash_line[0]) send_line_to(sinks, "%s", s_crash_line);
    send_link_line(sinks);
}

static void scan_task(void *arg) {
    (void)arg;
    send_header(SINK_ALL);
    send_line("WD:MODE mode=wifi");
    send_line("WD:BEGIN type=wifi interval=0 channel=auto");
    send_plan_line();
    s_sweeps = 0;
    uint8_t plan[MAX_CHANNELS];
    while (s_streaming && host_linked()) {
        size_t n = plan_copy(plan);
        s_ap_count = 0;   // APs heard this sweep (one record per AP per channel scan)
        for (size_t i = 0; i < n && s_streaming; i++) {
            scan_one_channel(plan[i]);
            vTaskDelay(pdMS_TO_TICKS(5));
        }
        if (n == 0) vTaskDelay(pdMS_TO_TICKS(200));
        s_sweeps++;
        heap_check("wifi sweep");
        s_last_aps = s_ap_count;
        send_line("WD:STATUS aps=%lu scans=%lu", (unsigned long)s_ap_count, (unsigned long)s_sweeps);
    }
    send_line("WD:END reason=stop");
    s_streaming = false;
    s_scan_task = NULL;
    if (s_switch_pending) { s_switch_pending = false; stream_start(); }
    vTaskDelete(NULL);
}

static void wifi_start(void) {
    if (s_streaming || s_scan_task || s_ota_active || !host_linked()) return;
    s_streaming = true;
    if (xTaskCreate(scan_task, "wd_scan", 10240, NULL, 5, &s_scan_task) != pdPASS) {
        s_streaming = false;
        s_scan_task = NULL;
        ESP_LOGE(TAG, "scan task create failed");
        return;
    }
    ESP_LOGI(TAG, "stream started");
}

// ─── Capture role (PROTOCOL.md "Capture", firmware 1.5+) ──────────────────────
// PASSIVE 802.11 promiscuous capture: WPA 4-way handshakes (WD:HS, hashcat-22000), RSN PMKIDs (WD:PMKID) and
// station sightings (WD:CLIENT). RX ONLY — the board never transmits, deauths or injects; a crackable artifact
// only appears when a client associates on its own. A C port of the Android PmkidCapture (EAPOL M1..M4, ANonce/M2
// replay pairing, MIC-zeroed hashcat line, PMKID KDE) plus MonitorCapture's client/BSSID derivation. The
// promiscuous rx callback runs in the Wi-Fi task and must not block, so it copies each frame (truncated) into a
// queue; cap_task drains it and does all the parsing.
#define CAP_SNAP        256   // bytes copied per frame — EAPOL key frames are ~155 B, SSID sits near a beacon's front
#define CAP_QUEUE_LEN   32
#define CAP_DWELL_MS    300   // longer than a scan dwell: a handshake only happens if a client associates while we camp
#define CAP_M1_CACHE    16    // M1 ANonces awaiting their M2
#define CAP_AP_CACHE    160   // BSSID→SSID/best-RSSI table: feeds WD:AP so capture is a superset of a Wi-Fi scan
#define CAP_SEEN_CAP    512   // session dedup fingerprints (handshake MIC / PMKID / client) before it rolls over

typedef struct {
    uint16_t len;
    int8_t   rssi;
    uint8_t  channel;
    uint8_t  data[CAP_SNAP];
} cap_rec_t;

static QueueHandle_t s_cap_queue;
static TaskHandle_t  s_cap_task        = NULL;
static volatile bool s_cap_running     = false;
static volatile uint32_t s_cap_hs      = 0;
static volatile uint32_t s_cap_pmkid   = 0;
static volatile uint32_t s_cap_clients = 0;
static volatile uint32_t s_cap_aps     = 0;
static volatile uint32_t s_cap_data    = 0;
static volatile uint32_t s_cap_dropped = 0;

typedef struct {   // M1 ANonce cache (raw bytes), keyed AP+STA, paired with the matching M2 by replay counter
    bool     used;
    uint8_t  ap[6], sta[6], anonce[32], replay[8];
    uint32_t time;
} cap_m1_t;
static cap_m1_t s_cap_m1[CAP_M1_CACHE];

typedef struct { bool used; uint8_t bssid[6], ssid[32], ssid_len; int8_t best_rssi; uint32_t last_emit; } cap_ap_t;
static cap_ap_t s_cap_aps_tbl[CAP_AP_CACHE];
#define CAP_AP_REEMIT_MS 20000   // re-report a still-heard AP at least this often so the phone's "in range" count stays live

static uint32_t s_cap_seen[CAP_SEEN_CAP];   // open set of 32-bit artifact fingerprints; cleared when full
static size_t   s_cap_seen_n = 0;

static uint32_t cap_fnv(const uint8_t *p, size_t n, uint32_t seed) {
    uint32_t h = seed ? seed : 2166136261u;
    for (size_t i = 0; i < n; i++) { h ^= p[i]; h *= 16777619u; }
    return h;
}
static bool cap_seen_add(uint32_t fp) {
    for (size_t i = 0; i < s_cap_seen_n; i++) if (s_cap_seen[i] == fp) return false;
    if (s_cap_seen_n >= CAP_SEEN_CAP) s_cap_seen_n = 0;   // roll over; the phone dedups by pmkid/mic too
    s_cap_seen[s_cap_seen_n++] = fp;
    return true;
}
static void cap_reset_session(void) {
    memset(s_cap_m1, 0, sizeof(s_cap_m1));
    memset(s_cap_aps_tbl, 0, sizeof(s_cap_aps_tbl));
    s_cap_seen_n = 0;
    s_cap_hs = s_cap_pmkid = s_cap_clients = s_cap_aps = s_cap_data = s_cap_dropped = 0;
}

static int cap_hex(char *out, const uint8_t *p, size_t n) {
    for (size_t i = 0; i < n; i++) { out[2 * i] = lower_hex_digit(p[i] >> 4); out[2 * i + 1] = lower_hex_digit(p[i] & 0x0F); }
    out[2 * n] = '\0';
    return (int)(2 * n);
}

// Upsert a beacon/probe-response's BSSID into the AP table (SSID + best RSSI). Returns true when the phone should
// get a WD:AP for it — the first time it's seen, or when a later sighting is notably stronger — so capture mode
// reports APs like a Wi-Fi scan without flooding the link with one line per beacon. Evicts the weakest when full.
static bool cap_ap_touch(const uint8_t *bssid, const uint8_t *ssid, int ssid_len, int rssi) {
    int slot = -1, freeslot = -1, weakest = 0; int8_t weakest_rssi = 127;
    for (int i = 0; i < CAP_AP_CACHE; i++) {
        if (s_cap_aps_tbl[i].used && memcmp(s_cap_aps_tbl[i].bssid, bssid, 6) == 0) { slot = i; break; }
        if (!s_cap_aps_tbl[i].used && freeslot < 0) freeslot = i;
        if (s_cap_aps_tbl[i].used && s_cap_aps_tbl[i].best_rssi < weakest_rssi) { weakest_rssi = s_cap_aps_tbl[i].best_rssi; weakest = i; }
    }
    bool fresh = (slot < 0);
    if (fresh) {
        slot = (freeslot >= 0) ? freeslot : weakest;
        s_cap_aps_tbl[slot].used = true;
        memcpy(s_cap_aps_tbl[slot].bssid, bssid, 6);
        s_cap_aps_tbl[slot].ssid_len = 0;
        s_cap_aps_tbl[slot].best_rssi = -128;
    }
    cap_ap_t *a = &s_cap_aps_tbl[slot];
    if (ssid_len > 0 && ssid_len <= 32) { memcpy(a->ssid, ssid, ssid_len); a->ssid_len = (uint8_t)ssid_len; }
    uint32_t now = (uint32_t)(esp_timer_get_time() / 1000);
    // Emit on first sight, a notably stronger RSSI, or if it's been a while — so the phone keeps counting it "in range".
    if (fresh || rssi > (int)a->best_rssi + 4 || now - a->last_emit > CAP_AP_REEMIT_MS) {
        if (rssi > (int)a->best_rssi) a->best_rssi = (int8_t)rssi;
        a->last_emit = now;
        return true;
    }
    return false;
}
static const cap_ap_t *cap_find_ssid(const uint8_t *bssid) {
    for (int i = 0; i < CAP_AP_CACHE; i++)
        if (s_cap_aps_tbl[i].used && memcmp(s_cap_aps_tbl[i].bssid, bssid, 6) == 0 && s_cap_aps_tbl[i].ssid_len)
            return &s_cap_aps_tbl[i];
    return NULL;
}

// The WPA/WPA2/WPA3 token for a beacon/probe-response, from its capability + RSN/WPA information elements — the
// same token set a Wi-Fi scan reports (auth_name), so capture-mode WD:AP lines read identically to scan-mode ones.
static const char *cap_beacon_auth(const uint8_t *b, int end) {
    if (end < 36) return "OPEN";
    int capinfo = b[34] | (b[35] << 8);
    if (!(capinfo & 0x10)) return "OPEN";                       // Privacy bit clear → open
    bool rsn = false, wpa = false, sae = false, psk = false;
    for (int i = 36; i + 2 <= end; ) {
        int id = b[i], len = b[i + 1];
        if (i + 2 + len > end) break;
        const uint8_t *p = b + i + 2;
        if (id == 0x30 && len >= 8) {                           // RSN IE
            rsn = true;
            int off = 2 + 4;                                    // skip version + group cipher
            if (off + 2 <= len) {
                int pc = p[off] | (p[off + 1] << 8); off += 2 + 4 * pc;   // skip pairwise ciphers
                if (off + 2 <= len) {
                    int ac = p[off] | (p[off + 1] << 8); off += 2;
                    for (int k = 0; k < ac && off + 4 <= len; k++, off += 4) {
                        if (p[off] == 0x00 && p[off + 1] == 0x0F && p[off + 2] == 0xAC) {
                            uint8_t suite = p[off + 3];
                            if (suite == 8 || suite == 9) sae = true;    // SAE / FT-SAE → WPA3
                            if (suite == 2 || suite == 6) psk = true;    // PSK / FT-PSK
                        }
                    }
                }
            }
        } else if (id == 0xDD && len >= 4 && p[0] == 0x00 && p[1] == 0x50 && p[2] == 0xF2 && p[3] == 0x01) {
            wpa = true;                                         // Microsoft WPA1 vendor IE
        }
        i += 2 + len;
    }
    if (sae) return (rsn && psk) ? "WPA2_WPA3" : "WPA3";
    if (rsn) return "WPA2";
    if (wpa) return "WPA";
    return "WEP";                                               // privacy set but no RSN/WPA IE → WEP
}

// Emit a WD:AP line from a beacon/probe-response, identical in shape to the scan-mode AP line.
static void cap_emit_ap(const uint8_t *b, const uint8_t *ssid, int ssid_len, int rssi, int ch, const char *auth) {
    display_note_ap(b, (uint8_t)ch);
    char ssid_hex[2 * 32 + 1] = "";
    if (ssid_len > 0 && ssid_len <= 32) cap_hex(ssid_hex, ssid, (size_t)ssid_len);
    send_line("WD:AP ts=%lu bssid=%02X:%02X:%02X:%02X:%02X:%02X ssid_hex=%s rssi=%d ch=%d auth=%s hidden=%u",
              (unsigned long)(esp_timer_get_time() / 1000), b[0], b[1], b[2], b[3], b[4], b[5],
              ssid_hex, rssi, ch, auth, ssid_len ? 0u : 1u);
    s_cap_aps++;
}

// A station sighting, deduped once per capture session. Broadcast/multicast/zero MACs are not devices.
static void cap_emit_client(const uint8_t *mac, const uint8_t *bssid, int rssi, int ch) {
    if (mac[0] & 0x01) return;
    bool zero = true; for (int i = 0; i < 6; i++) if (mac[i]) zero = false;
    if (zero) return;
    uint32_t fp = cap_fnv(mac, 6, 0x515ad70bu);
    if (!cap_seen_add(fp)) return;
    char bss[20] = "";
    if (bssid) snprintf(bss, sizeof(bss), "%02X:%02X:%02X:%02X:%02X:%02X",
                        bssid[0], bssid[1], bssid[2], bssid[3], bssid[4], bssid[5]);
    send_line("WD:CLIENT ts=%lu mac=%02X:%02X:%02X:%02X:%02X:%02X bssid=%s rssi=%d ch=%d",
              (unsigned long)(esp_timer_get_time() / 1000), mac[0], mac[1], mac[2], mac[3], mac[4], mac[5],
              bss, rssi, ch);
    s_cap_clients++;
}

// Port of PmkidCapture.scan: locate EAPOL in a data frame, classify M1..M4, pair M1/M2 into a hashcat-22000
// handshake line, and lift the RSN PMKID KDE. `buf` is the 802.11 frame at offset 0; `end` excludes the FCS.
static void cap_parse_eapol(const uint8_t *buf, int end, int ch, int rssi) {
    if (end < 2 || ((buf[0] >> 2) & 3) != 2) return;          // data frames only
    int fromDs = (buf[1] >> 1) & 1;
    int p = -1, hi = end - 8; if (hi > 40) hi = 40;           // scan the header/pad window for AA AA 03 .. .. .. 88 8E
    for (int q = 24; q <= hi; q++)
        if (buf[q] == 0xAA && buf[q + 1] == 0xAA && buf[q + 2] == 0x03 && buf[q + 6] == 0x88 && buf[q + 7] == 0x8E) { p = q; break; }
    if (p < 0) return;
    int eapol = p + 8;
    if (eapol + 7 > end || buf[eapol + 1] != 3) return;       // EAPOL-Key
    int keyInfo = (buf[eapol + 5] << 8) | buf[eapol + 6];
    bool ack = keyInfo & 0x080, hasMic = keyInfo & 0x100, install = keyInfo & 0x040, secure = keyInfo & 0x200;
    int m = (ack && !hasMic) ? 1 : (hasMic && !ack && !secure && !install) ? 2
          : (hasMic && ack && install) ? 3 : (hasMic && secure && !ack) ? 4 : 0;
    const uint8_t *ap  = fromDs ? buf + 10 : buf + 4;         // M1: AP=addr2; M2: AP=addr1
    const uint8_t *sta = fromDs ? buf + 4  : buf + 10;
    uint32_t now = (uint32_t)(esp_timer_get_time() / 1000);

    if (m == 1 && eapol + 49 <= end) {                        // cache the ANonce for M2 pairing
        int slot = -1, freeslot = -1, oldest = 0; uint32_t oldest_t = 0xffffffffu;
        for (int i = 0; i < CAP_M1_CACHE; i++) {
            if (s_cap_m1[i].used && !memcmp(s_cap_m1[i].ap, ap, 6) && !memcmp(s_cap_m1[i].sta, sta, 6)) { slot = i; break; }
            if (!s_cap_m1[i].used && freeslot < 0) freeslot = i;
            if (s_cap_m1[i].time < oldest_t) { oldest_t = s_cap_m1[i].time; oldest = i; }
        }
        if (slot < 0) slot = (freeslot >= 0) ? freeslot : oldest;
        s_cap_m1[slot].used = true;
        memcpy(s_cap_m1[slot].ap, ap, 6); memcpy(s_cap_m1[slot].sta, sta, 6);
        memcpy(s_cap_m1[slot].anonce, buf + eapol + 17, 32);
        memcpy(s_cap_m1[slot].replay, buf + eapol + 9, 8);
        s_cap_m1[slot].time = now;
    }
    if (m == 2 && eapol + 99 <= end) {                        // pair with the cached M1 by replay counter
        int bodyLen = (buf[eapol + 2] << 8) | buf[eapol + 3];
        int frameLen = 4 + bodyLen;
        cap_m1_t *m1 = NULL;
        for (int i = 0; i < CAP_M1_CACHE; i++)
            if (s_cap_m1[i].used && !memcmp(s_cap_m1[i].ap, ap, 6) && !memcmp(s_cap_m1[i].sta, sta, 6)) { m1 = &s_cap_m1[i]; break; }
        if (m1 && !memcmp(m1->replay, buf + eapol + 9, 8) && frameLen >= 99 && eapol + frameLen <= end) {
            const uint8_t *mic = buf + eapol + 81;
            bool mic_zero = true; for (int i = 0; i < 16; i++) if (mic[i]) mic_zero = false;
            if (!mic_zero && cap_seen_add(cap_fnv(mic, 16, 0x48530001u))) {
                if (frameLen > CAP_SNAP) frameLen = CAP_SNAP;
                uint8_t fr[CAP_SNAP];
                memcpy(fr, buf + eapol, frameLen);
                for (int k = 81; k < 97 && k < frameLen; k++) fr[k] = 0;   // zero the MIC field in the EAPOL copy
                char michex[33], anoncehex[65], eapolhex[2 * CAP_SNAP + 1], essidhex[2 * 32 + 1] = "";
                cap_hex(michex, mic, 16);
                cap_hex(anoncehex, m1->anonce, 32);
                cap_hex(eapolhex, fr, frameLen);
                const cap_ap_t *ss = cap_find_ssid(ap);
                if (ss) cap_hex(essidhex, ss->ssid, ss->ssid_len);
                // Worst case (256-byte EAPOL → 512 hex, 64-byte ESSID, 64 ANonce) reaches ~880 bytes; size for it.
                // send_chunks splits it across MTU-sized DATA frames, so only this build buffer caps the length.
                char line[1100];
                int n = snprintf(line, sizeof(line) - 1,
                    "WD:HS ts=%lu bssid=%02X:%02X:%02X:%02X:%02X:%02X sta=%02X:%02X:%02X:%02X:%02X:%02X ssid_hex=%s ch=%d rssi=%d "
                    "hc22000=WPA*02*%s*%02x%02x%02x%02x%02x%02x*%02x%02x%02x%02x%02x%02x*%s*%s*%s*00",
                    (unsigned long)now, ap[0], ap[1], ap[2], ap[3], ap[4], ap[5],
                    sta[0], sta[1], sta[2], sta[3], sta[4], sta[5], essidhex, ch, rssi,
                    michex, ap[0], ap[1], ap[2], ap[3], ap[4], ap[5],
                    sta[0], sta[1], sta[2], sta[3], sta[4], sta[5], essidhex, anoncehex, eapolhex);
                if (n > 0) {
                    if (n > (int)sizeof(line) - 2) n = (int)sizeof(line) - 2;
                    line[n++] = '\n';
                    send_chunks(line, (size_t)n);
                    s_cap_hs++;
                    m1->used = false;
                }
            }
        }
    }
    for (int i = eapol, limit = end - 22; i <= limit; i++) {  // PMKID KDE: DD 14 00 0F AC 04 <16 bytes>
        if (buf[i] == 0xDD && buf[i + 1] == 0x14 && buf[i + 2] == 0x00 && buf[i + 3] == 0x0F &&
            buf[i + 4] == 0xAC && buf[i + 5] == 0x04) {
            const uint8_t *pm = buf + i + 6;
            bool zero = true; for (int k = 0; k < 16; k++) if (pm[k]) zero = false;
            if (zero) return;
            if (!cap_seen_add(cap_fnv(pm, 16, 0x504d4b31u))) return;
            char pmhex[33], essidhex[2 * 32 + 1] = "";
            cap_hex(pmhex, pm, 16);
            const cap_ap_t *ss = cap_find_ssid(ap);
            if (ss) cap_hex(essidhex, ss->ssid, ss->ssid_len);
            send_line("WD:PMKID ts=%lu bssid=%02X:%02X:%02X:%02X:%02X:%02X sta=%02X:%02X:%02X:%02X:%02X:%02X "
                      "ssid_hex=%s ch=%d rssi=%d pmkid=%s",
                      (unsigned long)now, ap[0], ap[1], ap[2], ap[3], ap[4], ap[5],
                      sta[0], sta[1], sta[2], sta[3], sta[4], sta[5], essidhex, ch, rssi, pmhex);
            s_cap_pmkid++;
            return;
        }
    }
}

static void cap_process(const cap_rec_t *r) {
    const uint8_t *b = r->data;
    int end = r->len;
    if (end < 24) return;                                     // a full MAC header is 24 bytes
    int fc = b[0], ftype = (fc >> 2) & 3, sub = (fc >> 4) & 0xF;
    if (ftype == 0) {                                         // management
        const uint8_t *addr2 = b + 10, *addr3 = b + 16;       // transmitter / BSSID
        if (sub == 8 || sub == 5) {                           // beacon / probe-response → AP (WD:AP) + learn SSID
            const uint8_t *ssid = NULL; int sl = 0;
            int t = 24 + 12;                                  // after 24-byte header + 12 fixed params
            if (t + 2 <= end && b[t] == 0) {                  // element id 0 = SSID
                int l = b[t + 1];
                if (l > 0 && l <= 32 && t + 2 + l <= end) { ssid = b + t + 2; sl = l; }
            }
            if (cap_ap_touch(addr3, ssid, sl, r->rssi))
                cap_emit_ap(addr3, ssid, sl, r->rssi, r->channel, cap_beacon_auth(b, end));
        } else if (sub == 4) {
            cap_emit_client(addr2, NULL, r->rssi, r->channel);          // probe-request — client, BSSID unknown
        } else if (sub <= 3 || sub == 11) {
            cap_emit_client(addr2, addr3, r->rssi, r->channel);         // assoc/reassoc/auth — client + BSSID
        }
    } else if (ftype == 2) {                                  // data
        s_cap_data++;
        cap_parse_eapol(b, end, r->channel, r->rssi);
        int fromDs = (b[1] >> 1) & 1, toDs = b[1] & 1;
        const uint8_t *a1 = b + 4, *a2 = b + 10;
        if (toDs && !fromDs)       cap_emit_client(a2, a1, r->rssi, r->channel);   // client→AP: client=addr2 bssid=addr1
        else if (!toDs && fromDs)  cap_emit_client(a1, a2, r->rssi, r->channel);   // AP→client: client=addr1 bssid=addr2
        else if (!toDs && !fromDs) cap_emit_client(a2, a1, r->rssi, r->channel);   // IBSS
        // WDS (toDs && fromDs): four addresses, no simple client/BSSID — skip
    }
}

static void cap_rx_cb(void *buf, wifi_promiscuous_pkt_type_t type) {
    if (!s_cap_running || (type != WIFI_PKT_MGMT && type != WIFI_PKT_DATA)) return;
    const wifi_promiscuous_pkt_t *pkt = (const wifi_promiscuous_pkt_t *)buf;
    int end = pkt->rx_ctrl.sig_len - 4;                       // drop the trailing FCS
    if (end <= 0) return;
    cap_rec_t r;
    r.len = end > CAP_SNAP ? CAP_SNAP : (uint16_t)end;
    r.rssi = pkt->rx_ctrl.rssi;
    r.channel = pkt->rx_ctrl.channel;
    memcpy(r.data, pkt->payload, r.len);
    QueueHandle_t q = s_cap_queue;
    if (!q || xQueueSend(q, &r, 0) != pdTRUE) s_cap_dropped++;
}

static void cap_task(void *arg) {
    (void)arg;
    s_crumb = CR_CAP;
    cap_reset_session();
    send_caps_line();
    send_line("WD:MODE mode=cap");
    send_line("WD:BEGIN type=cap interval=0 channel=auto");
    send_plan_line();

    (void)esp_wifi_scan_stop();
    wifi_promiscuous_filter_t filt = { .filter_mask = WIFI_PROMIS_FILTER_MASK_MGMT | WIFI_PROMIS_FILTER_MASK_DATA };
    esp_wifi_set_promiscuous_filter(&filt);
    esp_wifi_set_promiscuous_rx_cb(cap_rx_cb);
    if (esp_wifi_set_promiscuous(true) != ESP_OK) send_line("WD:ERR reason=promisc_failed");

    uint8_t plan[MAX_CHANNELS];
    uint32_t sweeps = 0;
    cap_rec_t r;
    while (s_cap_running && host_linked()) {
        size_t n = plan_copy(plan);
        if (n == 0) { vTaskDelay(pdMS_TO_TICKS(200)); continue; }
        for (size_t i = 0; i < n && s_cap_running; i++) {
            esp_wifi_set_channel(plan[i], WIFI_SECOND_CHAN_NONE);
            s_crumb_ch = plan[i];
            uint32_t until = (uint32_t)(esp_timer_get_time() / 1000) + CAP_DWELL_MS;
            while ((uint32_t)(esp_timer_get_time() / 1000) < until && s_cap_running)
                if (xQueueReceive(s_cap_queue, &r, pdMS_TO_TICKS(20)) == pdTRUE) cap_process(&r);
        }
        sweeps++;
        heap_check("cap sweep");
        send_line("WD:STATUS cap=1 aps=%lu hs=%lu pmkid=%lu clients=%lu data=%lu scans=%lu dropped=%lu",
                  (unsigned long)s_cap_aps, (unsigned long)s_cap_hs, (unsigned long)s_cap_pmkid,
                  (unsigned long)s_cap_clients, (unsigned long)s_cap_data, (unsigned long)sweeps,
                  (unsigned long)s_cap_dropped);
    }
    esp_wifi_set_promiscuous(false);
    esp_wifi_set_promiscuous_rx_cb(NULL);
    // Process frames queued before the stop. A handshake still missing its M2 is not reported.
    for (int i = 1; xQueueReceive(s_cap_queue, &r, 0) == pdTRUE; i++) {
        cap_process(&r);
        if (i % 4 == 0) vTaskDelay(1);
    }
    send_line("WD:END reason=stop");
    s_cap_running = false;
    s_cap_task = NULL;
    if (s_switch_pending) { s_switch_pending = false; stream_start(); }
    vTaskDelete(NULL);
}

static void cap_start(void) {
    if (s_cap_running || s_cap_task || s_ota_active || !host_linked()) return;
    if (!s_cap_queue) s_cap_queue = xQueueCreate(CAP_QUEUE_LEN, sizeof(cap_rec_t));
    if (!s_cap_queue) { send_line("WD:ERR reason=no_memory"); return; }
    s_cap_running = true;
    if (xTaskCreate(cap_task, "wd_cap", 10240, NULL, 5, &s_cap_task) != pdPASS) {
        s_cap_running = false;
        s_cap_task = NULL;
        send_line("WD:ERR reason=no_task");
        return;
    }
    ESP_LOGI(TAG, "capture started");
}

static volatile bool s_rebooting = false;

/// Starts scanning in this board's current role.
static void stream_start(void) {
    if (s_rebooting) return;
    switch (s_role) {
    case ROLE_BT:  bt_start();  break;
    case ROLE_CAP: cap_start(); break;
    default:       wifi_start(); break;
    }
}

static void stream_stop(void) {
    s_streaming = false;
    s_bt_running = false;
    s_cap_running = false;
    (void)esp_wifi_scan_stop();
}

/// Waits for the scan, Bluetooth and capture tasks to send what they hold and exit, then for their stacks to be freed.
static void wait_role_tasks(uint32_t max_ms) {
    for (uint32_t t = 0; t < max_ms && (s_scan_task || s_bt_task || s_cap_task); t += 20) vTaskDelay(pdMS_TO_TICKS(20));
    vTaskDelay(pdMS_TO_TICKS(50));
}

/// Switches the board between Wi-Fi, Bluetooth and Capture roles. A running task finishes first; the task that
/// ends then starts the new role.
static const char *role_name(scan_role_t role) { return role == ROLE_BT ? "bt" : role == ROLE_CAP ? "cap" : "wifi"; }

static void set_role(scan_role_t role) {
    const char *name = role_name(role);
    if (role == s_role) {
        send_line("WD:MODE mode=%s", name);
        if (!s_streaming && !s_bt_running && !s_cap_running && !s_scan_task && !s_bt_task && !s_cap_task) stream_start();
        return;
    }
    s_role = role;
    bt_power_kick();
    send_line("WD:MODE mode=%s", name);
    if (s_scan_task || s_bt_task || s_cap_task) {
        s_switch_pending = true;
        stream_stop();
    } else {
        stream_start();
    }
}

/// A host linked (BLE subscribe or USB hello): start scanning, or bring it up to date with the scan already running.
static void host_joined(uint8_t sink) {
    heap_check("host joined");
    if (s_streaming || s_bt_running || s_cap_running) {
        const char *m = role_name(s_role);
        send_header(sink);
        send_line_to(sink, "WD:MODE mode=%s", m);
        send_line_to(sink, "WD:BEGIN type=%s interval=0 channel=auto", m);
        if (s_role != ROLE_BT) send_plan_to(sink);
        return;
    }
    if (s_role != ROLE_WIFI || s_ota_active) send_header(sink);   // only the Wi-Fi scan task sends the header itself
    if (s_scan_task || s_bt_task || s_cap_task) s_switch_pending = true;   // still finishing: it restarts the role
    else stream_start();
}

// ─── Firmware update over BLE and USB (PROTOCOL.md "Firmware update") ──────
// Image bytes arrive on the OTA characteristic and are queued; this task writes them to the spare app slot
// (sequential writes erase sector by sector, so nothing blocks the BLE host for long) and acks progress.
// The receive buffer is created once and only reset, never freed, so a late BLE write can't land in freed memory.
// It is created after the scan tasks have exited, at the largest size the heap allows.
static void usb_arm_raw(uint8_t sink, uint32_t size);

static const char *ota_prepare(void) {
    wait_role_tasks(2000);
    if (s_ota_abort_req) return "aborted";
    if (s_cap_queue && !s_cap_task) {   // recreated by the next capture start
        QueueHandle_t q = s_cap_queue;
        s_cap_queue = NULL;
        vQueueDelete(q);
    }
    if (!s_ota_buf) {
        for (size_t i = 0; i < sizeof(OTA_BUF_SIZES) / sizeof(OTA_BUF_SIZES[0]) && !s_ota_buf; i++) {
            s_ota_buf = xStreamBufferCreate(OTA_BUF_SIZES[i], 1);
            if (s_ota_buf) s_ota_buf_bytes = OTA_BUF_SIZES[i];
        }
        if (!s_ota_buf) return "no_memory";
    } else {
        xStreamBufferReset(s_ota_buf);
    }
    uint32_t w = (uint32_t)(s_ota_buf_bytes - OTA_BUF_SLACK) / OTA_ACK_STEP * OTA_ACK_STEP;
    if (w > OTA_WINDOW_MAX) w = OTA_WINDOW_MAX;
    if (w < OTA_ACK_STEP) w = OTA_ACK_STEP;
    s_ota_window = w;
    s_ota_ack_step = w >= 2 * OTA_ACK_STEP ? OTA_ACK_STEP : w / 2;   // keep an ack due inside every window
    if (esp_ota_begin(s_ota_part, OTA_WITH_SEQUENTIAL_WRITES, &s_ota_handle) != ESP_OK) return "begin_failed";
    return NULL;
}

static void ota_cleanup(void) {
    bool was_ble = s_ota_active && s_ota_src == SINK_BLE;
    s_ota_active = false;
    s_ota_end_req = false;
    s_ota_abort_req = false;
    s_ota_task = NULL;
    if (was_ble) request_link_params(false);   // back to the normal link timing
}

static void ota_task(void *arg) {
    (void)arg;
    static uint8_t chunk[1024];
    const char *err = ota_prepare();
    if (err) {
        send_line_to(s_ota_src, "WD:OTA error=%s", err);
        ESP_LOGW(TAG, "update not started: %s", err);
        ota_cleanup();
        vTaskDelete(NULL);
        return;
    }
    if (s_ota_src != SINK_BLE) usb_arm_raw(s_ota_src, s_ota_size);
    else request_link_params(true);   // faster link timing while the image transfers
    ESP_LOGI(TAG, "update started: %lu bytes → %s, buffer %u", (unsigned long)s_ota_size, s_ota_part->label,
             (unsigned)s_ota_buf_bytes);
    send_line_to(s_ota_src, "WD:OTA ready window=%u size=%u", (unsigned)s_ota_window, (unsigned)s_ota_buf_bytes);

    uint32_t written = 0, next_ack = s_ota_ack_step;
    bool ended = false;
    for (;;) {
        if (s_ota_abort_req) { err = "aborted"; break; }
        size_t n = xStreamBufferReceive(s_ota_buf, chunk, sizeof(chunk), pdMS_TO_TICKS(100));
        if (n > 0) {
            if (written + n > s_ota_size) { err = "too_much_data"; break; }
            s_crumb = CR_OTA;
            if (esp_ota_write(s_ota_handle, chunk, n) != ESP_OK) { err = "write_failed"; break; }
            written += n;
            if (written >= next_ack || written == s_ota_size) {
                send_line_to(s_ota_src, "WD:OTA ack=%lu", (unsigned long)written);
                next_ack = written + s_ota_ack_step;
            }
        }
        if (s_ota_end_req && xStreamBufferIsEmpty(s_ota_buf)) {
            if (written != s_ota_size) { err = "short_image"; break; }
            ended = true;   // esp_ota_end releases the handle whatever it returns
            if (esp_ota_end(s_ota_handle) != ESP_OK) { err = "invalid_image"; break; }
            if (esp_ota_set_boot_partition(s_ota_part) != ESP_OK) { err = "set_boot_failed"; break; }
            send_line_to(s_ota_src, "WD:OTA done");
            ESP_LOGI(TAG, "update written (%lu bytes) — restarting", (unsigned long)written);
            vTaskDelay(pdMS_TO_TICKS(800));
            esp_restart();
        }
    }
    if (!ended) esp_ota_abort(s_ota_handle);
    send_line_to(s_ota_src, "WD:OTA error=%s", err);
    ESP_LOGW(TAG, "update failed: %s", err);
    ota_cleanup();
    vTaskDelete(NULL);
}

// Runs in the command context, so it only validates and stops scanning; ota_task waits for the scan tasks to send
// what they hold, then sets up the update and replies WD:OTA ready.
static void ota_begin(const char *args) {
    const uint8_t src = s_cmd_src;
    if (s_ota_active) { send_line_to(src, "WD:OTA error=busy"); return; }
    unsigned long size = strtoul(args, NULL, 10);
    s_ota_part = esp_ota_get_next_update_partition(NULL);
    if (!s_ota_part) { send_line_to(src, "WD:OTA error=no_update_slot"); return; }
    if (size == 0 || size > s_ota_part->size) { send_line_to(src, "WD:OTA error=bad_size"); return; }
    s_ota_size = (uint32_t)size;
    s_ota_src = src;
    s_ota_end_req = false;
    s_ota_abort_req = false;
    s_ota_active = true;   // keeps the scan roles from restarting
    s_switch_pending = false;
    stream_stop();
    if (xTaskCreate(ota_task, "ota", 6144, NULL, 4, &s_ota_task) != pdPASS) {
        s_ota_active = false;
        s_ota_task = NULL;
        send_line_to(src, "WD:OTA error=no_task");
    }
}

static int on_ota_write(uint16_t conn, uint16_t attr, struct ble_gatt_access_ctxt *ctxt, void *arg) {
    (void)conn; (void)attr; (void)arg;
    if (ctxt->op != BLE_GATT_ACCESS_OP_WRITE_CHR) return BLE_ATT_ERR_UNLIKELY;
    if (!s_ota_active || !s_ota_buf || s_ota_src != SINK_BLE) return BLE_ATT_ERR_WRITE_NOT_PERMITTED;
    uint8_t buf[512];
    uint16_t got = 0;
    if (ble_hs_mbuf_to_flat(ctxt->om, buf, sizeof(buf), &got) != 0) return BLE_ATT_ERR_UNLIKELY;
    if (xStreamBufferSend(s_ota_buf, buf, got, 0) != got) s_ota_abort_req = true;   // phone ignored the window
    return 0;
}

static void ota_mark_valid_if_pending(void) {
    esp_ota_img_states_t st;
    const esp_partition_t *run = esp_ota_get_running_partition();
    if (run && esp_ota_get_state_partition(run, &st) == ESP_OK && st == ESP_OTA_IMG_PENDING_VERIFY) {
        esp_ota_mark_app_valid_cancel_rollback();
        ESP_LOGI(TAG, "new firmware confirmed");
    }
}

// ─── Boot diagnostics ──────────────────────────────────────────────────────
// Each boot saves how far it got (NVS, shared by both app slots), so after a hang, crash or rollback the next
// boot can report it. Freshly updated firmware that isn't up within BOOT_WATCHDOG_S restarts itself, and the
// bootloader then rolls back to the previous slot.
enum { STAGE_NONE = 0, STAGE_STORAGE = 1, STAGE_WIFI = 3, STAGE_BLUETOOTH, STAGE_READY, STAGE_WATCHDOG };   // 2 was the LED
#define BOOT_WATCHDOG_S 30

static esp_timer_handle_t s_boot_wd;

static const char *reset_reason_key(esp_reset_reason_t r) {
    switch (r) {
    case ESP_RST_POWERON:   return "power_on";
    case ESP_RST_EXT:       return "reset_pin";
    case ESP_RST_SW:        return "software";
    case ESP_RST_PANIC:     return "crash";
    case ESP_RST_INT_WDT:
    case ESP_RST_TASK_WDT:
    case ESP_RST_WDT:       return "watchdog";
    case ESP_RST_BROWNOUT:  return "brownout";
    case ESP_RST_DEEPSLEEP: return "deep_sleep";
    default:                return "other";
    }
}

static const char *stage_name(uint8_t s) {
    switch (s) {
    case STAGE_STORAGE:   return "storage";
    case STAGE_WIFI:      return "wifi";
    case STAGE_BLUETOOTH: return "bluetooth";
    case STAGE_READY:     return "ready";
    case STAGE_WATCHDOG:  return "boot_watchdog";
    default:              return "none";
    }
}

static const char *image_state_name(esp_ota_img_states_t s) {
    switch (s) {
    case ESP_OTA_IMG_NEW:            return "new";
    case ESP_OTA_IMG_PENDING_VERIFY: return "trial";
    case ESP_OTA_IMG_VALID:          return "confirmed";
    case ESP_OTA_IMG_INVALID:        return "invalid";
    case ESP_OTA_IMG_ABORTED:        return "aborted";
    default:                         return "undefined";
    }
}

static void boot_stage(uint8_t stage) {
    nvs_handle_t h;
    if (nvs_open("iosesp", NVS_READWRITE, &h) != ESP_OK) return;
    nvs_set_u8(h, "stage", stage);
    nvs_set_str(h, "stfw", FW_VERSION);
    nvs_commit(h);
    nvs_close(h);
}

static void boot_watchdog_fire(void *arg) {
    (void)arg;
    esp_ota_img_states_t st;
    const esp_partition_t *run = esp_ota_get_running_partition();
    if (run && esp_ota_get_state_partition(run, &st) == ESP_OK && st == ESP_OTA_IMG_PENDING_VERIFY) {
        boot_stage(STAGE_WATCHDOG);
        esp_restart();   // still on trial → the bootloader rolls back to the previous firmware
    }
}

static const char *crumb_name(uint8_t c) {
    switch (c) {
    case CR_SCAN:    return "wifi_scan";
    case CR_RESULTS: return "wifi_results";
    case CR_SEND_AP: return "sending_aps";
    case CR_BT:      return "bt_scan";
    case CR_CAP:     return "capture";
    case CR_OTA:     return "ota_write";
    case CR_CMD:     return "command";
    case CR_GPS:     return "gps";
    default:         return "idle";
    }
}

/// WD:CRASH from the record the panic handler left in RTC memory (lost on power loss, kept across a crash reset).
static void crash_report_build(void) {
    esp_reset_reason_t r = esp_reset_reason();
    bool bad = r == ESP_RST_PANIC || r == ESP_RST_INT_WDT || r == ESP_RST_TASK_WDT || r == ESP_RST_WDT;
    if (bad && s_crash.magic == CRASH_MAGIC) {
        char reason[sizeof(s_crash.reason)];
        size_t i = 0;
        for (; i + 1 < sizeof(reason) && s_crash.reason[i]; i++) {
            char c = s_crash.reason[i];
            reason[i] = (c == ' ' || c == '=') ? '_' : (c < 32 || c > 126) ? '?' : c;
        }
        reason[i] = '\0';
        s_crash.task[sizeof(s_crash.task) - 1] = '\0';
        snprintf(s_crash_line, sizeof(s_crash_line),
                 "WD:CRASH kind=%s reason=%s task=%s pc=0x%08lx core=%u up_ms=%lu last=%s ch=%u heap_min=%lu",
                 s_crash.kind == CK_STACK ? "stack_overflow" : "panic", reason[0] ? reason : "?",
                 s_crash.task[0] ? s_crash.task : "?", (unsigned long)s_crash.pc, (unsigned)s_crash.core,
                 (unsigned long)s_crash.up_ms, crumb_name(s_crash.crumb), (unsigned)s_crash.ch,
                 (unsigned long)s_crash.heap_min);
    } else if (bad) {
        snprintf(s_crash_line, sizeof(s_crash_line), "WD:CRASH kind=%s reason=unrecorded",
                 r == ESP_RST_PANIC ? "panic" : "watchdog");
    }
    if (s_crash_line[0]) ESP_LOGW(TAG, "%s", s_crash_line);
    s_crash.magic = 0;
}

/// Call right after NVS is up: reads the previous boot's progress, counts this boot, builds the WD:BOOT line,
/// and arms the boot watchdog when this firmware is on trial after an update.
static void boot_diag_begin(void) {
    uint8_t prev_stage = STAGE_NONE;
    char prev_fw[16] = "?";
    uint32_t boots = 0;
    nvs_handle_t h;
    if (nvs_open("iosesp", NVS_READWRITE, &h) == ESP_OK) {
        size_t len = sizeof(prev_fw);
        nvs_get_u8(h, "stage", &prev_stage);
        if (nvs_get_str(h, "stfw", prev_fw, &len) != ESP_OK) strcpy(prev_fw, "?");
        nvs_get_u32(h, "boots", &boots);
        boots++;
        nvs_set_u32(h, "boots", boots);
        nvs_commit(h);
        nvs_close(h);
    }
    const esp_partition_t *run = esp_ota_get_running_partition();
    esp_ota_img_states_t st = ESP_OTA_IMG_UNDEFINED;
    if (run) esp_ota_get_state_partition(run, &st);
    const esp_partition_t *bad = esp_ota_get_last_invalid_partition();
    snprintf(s_boot_line, sizeof(s_boot_line),
             "WD:BOOT fw=%s slot=%s image=%s reset=%s boots=%lu prev_fw=%s prev_stage=%s rolled_back=%s",
             FW_VERSION, run ? run->label : "?", image_state_name(st),
             reset_reason_key(esp_reset_reason()), (unsigned long)boots, prev_fw, stage_name(prev_stage),
             bad ? bad->label : "none");
    ESP_LOGI(TAG, "%s", s_boot_line);
    crash_report_build();
    boot_stage(STAGE_STORAGE);
    if (st == ESP_OTA_IMG_PENDING_VERIFY) {
        const esp_timer_create_args_t args = { .callback = boot_watchdog_fire, .name = "boot_wd" };
        if (esp_timer_create(&args, &s_boot_wd) == ESP_OK)
            esp_timer_start_once(s_boot_wd, (uint64_t)BOOT_WATCHDOG_S * 1000000ULL);
    }
}

// ─── Terminal commands (PROTOCOL.md "Commands") ────────────────────────────
static bool apply_channel_list(const char *list) {
    uint8_t chans[MAX_CHANNELS];
    size_t count = parse_channel_list(list, chans);
    if (count == 0) return false;
    portENTER_CRITICAL(&s_plan_lock);
    memcpy(s_plan, chans, count);
    s_plan_n = count;
    portEXIT_CRITICAL(&s_plan_lock);
    if (s_streaming) send_plan_line();
    return true;
}

static const char *reset_reason_name(esp_reset_reason_t r) {
    switch (r) {
    case ESP_RST_POWERON:  return "power-on";
    case ESP_RST_EXT:      return "reset pin";
    case ESP_RST_SW:       return "software restart";
    case ESP_RST_PANIC:    return "crash";
    case ESP_RST_INT_WDT:
    case ESP_RST_TASK_WDT:
    case ESP_RST_WDT:      return "watchdog";
    case ESP_RST_BROWNOUT: return "brownout (low power)";
    case ESP_RST_DEEPSLEEP:return "deep sleep";
    default:               return "other";
    }
}

// ─── Board identity: LED rings and battery gauge ──────────────────────────
// WS2812 pixels are write-only, so an LED pin is only ever driven for a board identified by a hardware fingerprint
// (board_detect). Without one, no LED pin is touched. Hardware facts: docs/device-research/README.md.
typedef enum { BOARD_NONE = 0, BOARD_CRUMB, BOARD_GHOSTBOARD, BOARD_POLTERGEIST,
               BOARD_BISCUIT_PRO, BOARD_BISCUIT_ULTRA, BOARD_BISCUIT_DUAL } board_t;
typedef struct { const char *id, *name; int led_gpio, pixels; } board_def_t;
static const board_def_t BOARDS[] = {
    [BOARD_NONE]          = { NULL, "generic", -1, 0 },
    [BOARD_CRUMB]         = { "crumb", "Biscuit Crumb", 23, 6 },
    [BOARD_GHOSTBOARD]    = { "ghostboard", "Rabbit Labs Ghost Board", 10, 3 },
    [BOARD_POLTERGEIST]   = { "poltergeist", "Rabbit Labs Poltergeist", 27, 1 },
    // Two-chip Biscuits, identified by the WardriveESP co-processor on their WROOM (WDCP hello, see coproc_line).
    // Both stock C5 images drive one NeoPixel on GPIO 10; the Pro has it fitted, the bench Ultra shows none, so
    // the Ultra gets no ring. biscuit_dual = the co-processor hasn't been told which model it is.
    [BOARD_BISCUIT_PRO]   = { "biscuit_pro", "Biscuit Pro", 10, 1 },
    [BOARD_BISCUIT_ULTRA] = { "biscuit_ultra", "Biscuit Ultra", 10, 0 },
    [BOARD_BISCUIT_DUAL]  = { "biscuit_dual", "Biscuit Pro or Ultra", 10, 1 },
};
static board_t s_board = BOARD_NONE;
static volatile int s_batt_pct = -1;    // state of charge, -1 = unknown
static volatile int s_batt_mv = 0;

#if CONFIG_IDF_TARGET_ESP32C5 || CONFIG_IDF_TARGET_ESP32C6
#define LED_MAX 6

// ── LED ring: 800 kHz WS2812 (40 MHz ticks: one = 28 high / 20 low, zero = 10 / 38), GRB ──
// One pattern per kind of app alert; the app picks the pattern and passes the banner's category color.
typedef enum { LED_IDLE = 0, LED_POLICE, LED_HEARTBEAT, LED_STROBE, LED_SPIN, LED_PULSE, LED_SPARKLE, LED_STORM, LED_TEST } led_fx_t;
#define LED_FRAME_MS 16   // ~60 fps: smooth enough for the dim end of the idle breath, still a tiny task
static int s_led_gpio = -1;
static rmt_channel_handle_t s_led_chan;
static rmt_encoder_handle_t s_led_enc;
static TaskHandle_t s_led_task;
static volatile led_fx_t s_led_fx = LED_IDLE;
static volatile uint32_t s_led_rgb, s_led_since, s_led_until;   // alert color 0xRRGGBB, start, end (ms)
static volatile uint8_t  s_led_bright = 40;                     // percent
static volatile bool     s_led_stealth = false;                 // ring fully dark
static volatile bool     s_led_paused = false;                  // pinsense has the pin

static uint32_t led_ms(void) { return (uint32_t)(esp_timer_get_time() / 1000); }

static void led_show(uint8_t px[LED_MAX][3]) {
    static uint8_t grb[LED_MAX * 3];   // the RMT driver keeps reading this after rmt_transmit returns: never a stack buffer
    for (int i = 0; i < s_led_n; i++) { grb[i * 3] = px[i][1]; grb[i * 3 + 1] = px[i][0]; grb[i * 3 + 2] = px[i][2]; }
    rmt_transmit_config_t tc = { .loop_count = 0 };
    if (rmt_transmit(s_led_chan, s_led_enc, grb, (size_t)s_led_n * 3, &tc) == ESP_OK) rmt_tx_wait_all_done(s_led_chan, -1);
}

static void led_set(float p[3], uint32_t rgb, float f) {   // 0-255 per channel, before dithering
    p[0] = ((rgb >> 16) & 0xFF) * f; p[1] = ((rgb >> 8) & 0xFF) * f; p[2] = (rgb & 0xFF) * f;
}

// Battery color: red at empty → amber at 35% → green from 70%. Cyan without a gauge (or before it answered).
static uint32_t batt_rgb(void) {
    int p = s_has_batt ? s_batt_pct : -1;
    if (p < 0) return 0x00A0FF;
    if (p >= 70) return 0x00FF00;
    if (p >= 35) { int t = (p - 35) * 255 / 35; return (uint32_t)((255 - t) << 16) | (uint32_t)((160 + 95 * t / 255) << 8); }
    int t = p * 255 / 35;
    return 0xFF0000 | (uint32_t)((160 * t / 255) << 8);
}

static void hue_rgb(float h, float out[3]) {   // h in degrees, full saturation and value
    float x = fmodf(h, 360.0f) / 60.0f, f = x - floorf(x), q = 1.0f - f;
    switch ((int)x) {
    case 0:  out[0] = 1; out[1] = f; out[2] = 0; break;
    case 1:  out[0] = q; out[1] = 1; out[2] = 0; break;
    case 2:  out[0] = 0; out[1] = 1; out[2] = f; break;
    case 3:  out[0] = 0; out[1] = q; out[2] = 1; break;
    case 4:  out[0] = f; out[1] = 0; out[2] = 1; break;
    default: out[0] = 1; out[1] = 0; out[2] = q; break;
    }
}

#define BREATH_MS 4500

static void led_task(void *arg) {
    (void)arg;
    float px[LED_MAX][3], err[LED_MAX][3] = {{0}}, spark[LED_MAX] = {0};
    uint8_t out[LED_MAX][3];
    const int n = s_led_n;
    bool dark = false;
    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(LED_FRAME_MS));
        if (s_led_paused) continue;
        uint32_t now = led_ms();
        if (now < 8000 || now % 2000 < LED_FRAME_MS) heap_check("led frame");
        led_fx_t fx = s_led_fx;
        if (fx != LED_IDLE && (int32_t)(now - s_led_until) >= 0) s_led_fx = fx = LED_IDLE;
        if (s_led_stealth) {
            if (!dark) { memset(out, 0, sizeof(out)); led_show(out); dark = true; }
            continue;
        }
        dark = false;
        uint32_t t = now - s_led_since, rgb = s_led_rgb;
        float scale = s_led_bright / 100.0f;

        // Idle, and the base the storm fades back into: a cosine-eased breath in the battery's color, stepped evenly to
        // the eye (gamma 2.2) and kept in float until dithering.
        float b = 0.5f - 0.5f * cosf(6.2831853f * (float)(now % BREATH_MS) / BREATH_MS);
        float level = powf(0.23f + 0.30f * b, 2.2f) * scale;
        for (int i = 0; i < n; i++) led_set(px[i], batt_rgb(), level);

        switch (fx) {
        case LED_STORM: {    // a phone or USB host just linked: a fast rainbow swirl with sparkle that fades back to idle
            uint32_t dur = s_led_until - s_led_since;
            float env = t < 120 ? t / 120.0f : 1.0f - (float)(t - 120) / (float)(dur > 120 ? dur - 120 : 1);
            if (env < 0) env = 0;
            float surge = scale * 1.6f > 1.0f ? 1.0f : scale * 1.6f;
            for (int i = 0; i < n; i++) {
                float c[3];
                hue_rgb((float)t * 0.9f + i * 360.0f / n, c);   // a full turn of hue every ~400 ms
                spark[i] *= 0.82f;
                if ((esp_random() & 15) == 0) spark[i] = 1.0f;
                for (int j = 0; j < 3; j++) {
                    float v = (c[j] * 0.85f + spark[i] * 0.6f) * 255.0f * surge;
                    px[i][j] = px[i][j] * (1 - env) + (v > 255 ? 255 : v) * env;
                }
            }
            break;
        }
        case LED_POLICE: {   // red/blue strobe: halves chasing around a full ring, the whole ring swapping on a small one
            int off = (int)(t / 110) % n;
            float v = ((t / 55) % 2 ? 1.0f : 0.27f) * scale;
            for (int i = 0; i < n; i++) {
                bool red = n >= 6 ? (i + off) % n < n / 2 : (t / 110) % 2 == 0;
                led_set(px[i], red ? 0xFF0000 : 0x0000FF, v);
            }
            break;
        }
        case LED_SPIN: {     // a comet circling in the color: trackers, Find My, drones, Remote ID
            static const float TAIL[3] = { 1.0f, 0.35f, 0.1f };
            int head = (int)(t / 90) % n;
            memset(px, 0, sizeof(px));
            for (int k = 0; k < 3 && k < n; k++) led_set(px[(head - k + n) % n], rgb, TAIL[k] * scale);
            break;
        }
        case LED_PULSE: {    // the whole ring breathing fast in the color: cameras
            float e = 0.5f - 0.5f * cosf(6.2831853f * (float)(t % 900) / 900.0f);
            for (int i = 0; i < n; i++) led_set(px[i], rgb, (0.12f + 0.88f * e) * scale);
            break;
        }
        case LED_HEARTBEAT: { // lub-dub, then rest: adult toys, health devices
            uint32_t ph = t % 1100;
            float e = ph < 140 ? sinf(3.1415927f * ph / 140.0f) : (ph >= 260 && ph < 400) ? 0.75f * sinf(3.1415927f * (ph - 260) / 140.0f) : 0.0f;
            for (int i = 0; i < n; i++) led_set(px[i], rgb, (0.06f + 0.94f * e) * scale);
            break;
        }
        case LED_STROBE: {   // hard flashes, halves swapping: attack tools, gunshot sensors
            bool on = (t / 45) % 2 == 0;
            int half = (int)(t / 180) % 2;
            memset(px, 0, sizeof(px));
            if (on) for (int i = 0; i < n; i++) if (n < 4 || (i < n / 2) == (half == 0)) led_set(px[i], rgb, scale);
            break;
        }
        case LED_SPARKLE:    // pixels flare and fade in the color: captures (gold), cracked passwords (green)
            for (int i = 0; i < n; i++) {
                spark[i] *= 0.88f;
                if ((esp_random() & 15) == 0) spark[i] = 1.0f;
                led_set(px[i], rgb, spark[i] * scale);
            }
            break;
        case LED_TEST: {     // red, green, blue, white, each filling the ring pixel by pixel
            static const uint32_t C[4] = { 0xFF0000, 0x00FF00, 0x0000FF, 0xFFFFFF };
            int lit = (int)((t % 1000) * n / 1000);
            memset(px, 0, sizeof(px));
            for (int i = 0; i <= lit && i < n; i++) led_set(px[i], C[(t / 1000) % 4], scale);
            break;
        }
        default:
            break;
        }

        // Temporal dithering: each channel carries its leftover fraction into the next frame, so a level between two
        // 8-bit steps averages out at 60 fps instead of stepping visibly at the dim end.
        for (int i = 0; i < n; i++) for (int j = 0; j < 3; j++) {
            float v = px[i][j] + err[i][j];
            int q = (int)v;
            if (q < 0) q = 0; else if (q > 255) q = 255;
            err[i][j] = v - (float)q;
            if (err[i][j] > 1.0f || err[i][j] < -1.0f) err[i][j] = 0;   // clipped: don't let it wind up
            out[i][j] = (uint8_t)q;
        }
        led_show(out);
    }
}

/// A phone or USB host linked: a short rainbow storm, unless an alert holds the ring.
static void led_storm(void) {
    if (!s_led_task || s_led_fx != LED_IDLE) return;
    uint32_t now = led_ms();
    s_led_since = now; s_led_until = now + 1500;
    s_led_fx = LED_STORM;
    display_alert("LINKED", 1500);
}

static void led_save(void) {
    nvs_handle_t h;
    if (nvs_open("iosesp", NVS_READWRITE, &h) != ESP_OK) return;
    nvs_set_u8(h, "ledbright", s_led_bright);
    nvs_set_u8(h, "ledstealth", s_led_stealth ? 1 : 0);
    nvs_commit(h);
    nvs_close(h);
}

static rmt_tx_channel_config_t led_channel_config(int gpio) {
    rmt_tx_channel_config_t cc = { .gpio_num = gpio, .clk_src = RMT_CLK_SRC_DEFAULT, .resolution_hz = 40000000,
                                   .mem_block_symbols = SOC_RMT_MEM_WORDS_PER_CHANNEL, .trans_queue_depth = 2 };
    return cc;
}

static void led_start(int gpio, int pixels) {
    if (s_led_task) return;
    nvs_handle_t h;
    if (nvs_open("iosesp", NVS_READONLY, &h) == ESP_OK) {
        uint8_t v;
        if (nvs_get_u8(h, "ledbright", &v) == ESP_OK && v <= 100) s_led_bright = v;
        if (nvs_get_u8(h, "ledstealth", &v) == ESP_OK) s_led_stealth = v != 0;
        display_set_stealth(s_led_stealth);
        nvs_close(h);
    }
    rmt_tx_channel_config_t cc = led_channel_config(gpio);
    rmt_bytes_encoder_config_t ec = {
        .bit0 = { .level0 = 1, .duration0 = 10, .level1 = 0, .duration1 = 38 },
        .bit1 = { .level0 = 1, .duration0 = 28, .level1 = 0, .duration1 = 20 },
        .flags.msb_first = 1,
    };
    if (rmt_new_tx_channel(&cc, &s_led_chan) != ESP_OK || rmt_new_bytes_encoder(&ec, &s_led_enc) != ESP_OK ||
        rmt_enable(s_led_chan) != ESP_OK) {
        ESP_LOGW(TAG, "LED ring on GPIO %d unavailable", gpio);
        return;
    }
    s_led_gpio = gpio;
    s_led_n = pixels > LED_MAX ? LED_MAX : pixels;
    if (xTaskCreate(led_task, "wd_led", 4096, NULL, 1, &s_led_task) != pdPASS) { s_led_n = 0; ESP_LOGW(TAG, "LED task create failed"); }
}

// `led <event> [rrggbb] [seconds]`, `led bright <0-100>`, `led stealth on|off`, `led` alone for the state.
static void cmd_led(const char *arg) {
    if (!s_led_n) { send_line("no LED ring on this board"); return; }
    char ev[12] = "", a1[16] = "", a2[16] = "", a3[16] = "", a4[16] = "";
    sscanf(arg, "%11s %15s %15s %15s %15s", ev, a1, a2, a3, a4);
    if (!strcmp(ev, "alert")) {   // `led alert <pattern> <rrggbb> [seconds] [label]`: same as `led <pattern> ...`
        memcpy(ev, a1, sizeof(ev) - 1); ev[sizeof(ev) - 1] = '\0';
        memcpy(a1, a2, sizeof(a1)); memcpy(a2, a3, sizeof(a2)); memcpy(a3, a4, sizeof(a3));
    }
    if (!ev[0]) {
        send_line("led ring %d px on GPIO %d  ·  brightness %u%%  ·  stealth %s", s_led_n, s_led_gpio,
                  (unsigned)s_led_bright, s_led_stealth ? "on" : "off");
        return;
    }
    if (!strcmp(ev, "bright")) {
        int v = atoi(a1);
        s_led_bright = (uint8_t)(v < 0 ? 0 : v > 100 ? 100 : v);
        led_save();
        send_line("led brightness %u%%", (unsigned)s_led_bright);
        return;
    }
    if (!strcmp(ev, "stealth")) {
        if (!strcmp(a1, "on") || !strcmp(a1, "off")) { s_led_stealth = !strcmp(a1, "on"); led_save(); }
        display_set_stealth(s_led_stealth);
        send_line("led stealth %s", s_led_stealth ? "on" : "off");
        return;
    }
    if (!strcmp(ev, "off")) { s_led_fx = LED_IDLE; display_alert("", 0); send_line("led idle"); return; }
    static const struct { const char *name; led_fx_t fx; uint32_t rgb, secs; } FX[] = {
        { "police", LED_POLICE, 0, 8 },           { "heartbeat", LED_HEARTBEAT, 0xFF4FA3, 6 },
        { "strobe", LED_STROBE, 0xFF3B30, 6 },    { "spin", LED_SPIN, 0x00C8FF, 6 },
        { "pulse", LED_PULSE, 0xFFC800, 6 },      { "sparkle", LED_SPARKLE, 0xFFAA00, 3 },
        { "rainbow", LED_STORM, 0, 2 },           { "test", LED_TEST, 0, 4 },
        // earlier names
        { "drone", LED_SPIN, 0x00C8FF, 6 },       { "notable", LED_SPIN, 0xFFC800, 6 },
        { "capture", LED_SPARKLE, 0xFFAA00, 2 },  { "storm", LED_STORM, 0, 2 },
    };
    for (size_t i = 0; i < sizeof(FX) / sizeof(FX[0]); i++) {
        if (strcmp(ev, FX[i].name)) continue;
        uint32_t rgb = FX[i].rgb, secs = FX[i].secs;
        const char *next[3] = { a1, a2, a3 };
        int k = 0;
        if (strlen(a1) == 6 && strspn(a1, "0123456789abcdefABCDEF") == 6) { rgb = (uint32_t)strtoul(a1, NULL, 16); k = 1; }
        if (k < 3 && next[k][0] >= '0' && next[k][0] <= '9') {
            long s = atol(next[k++]);
            secs = (uint32_t)(s < 1 ? 1 : s > 60 ? 60 : s);
        }
        uint32_t now = led_ms();
        s_led_rgb = rgb; s_led_since = now; s_led_until = now + secs * 1000;
        s_led_fx = FX[i].fx;
        display_alert(k < 3 && next[k][0] ? next[k] : FX[i].name, secs * 1000);   // the app's label, or the pattern's name
        send_line("led %s %06lx %lus", FX[i].name, (unsigned long)rgb, (unsigned long)secs);
        return;
    }
    send_line("led alert police|heartbeat|strobe|spin|pulse|sparkle|rainbow <rrggbb> [seconds] [label]  ·  led test  ·  led off  ·  led bright 0-100  ·  led stealth on|off");
}
#else
static void led_start(int gpio, int pixels) { (void)gpio; (void)pixels; }
static void led_storm(void) {}
static void cmd_led(const char *arg) { (void)arg; send_line("no LED ring on this board"); }
#endif

#if CONFIG_IDF_TARGET_ESP32C5
// ── MAX17048 battery gauge on I2C SDA 5 / SCL 4 (the Biscuit Crumb's wiring) ──
#define CRUMB_SDA      5
#define CRUMB_SCL      4
#define MAX17048_ADDR  0x36

static i2c_master_bus_handle_t s_i2c_bus;
static i2c_master_dev_handle_t s_gauge;
static bool s_gauge_i2c;   // the Crumb's gauge answered on 5/4 (s_has_batt can also mean a co-processor's gauge)

static bool gauge_read(uint8_t reg, uint16_t *out) {
    uint8_t v[2];
    if (i2c_master_transmit_receive(s_gauge, &reg, 1, v, 2, 50) != ESP_OK) return false;
    *out = (uint16_t)((v[0] << 8) | v[1]);
    return true;
}

static void battery_read(void) {
    uint16_t soc, vcell;
    if (!s_gauge_i2c) return;
    if (gauge_read(0x04, &soc)) s_batt_pct = (soc >> 8) > 100 ? 100 : (soc >> 8);   // whole percent in the high byte
    if (gauge_read(0x02, &vcell)) s_batt_mv = (int)((uint32_t)vcell * 5 / 64);       // 78.125 µV per bit
}

// An I2C bus has both lines pulled up. A board with 4/5 free, or a GPS module on 4, reads low here against the
// internal pull-down, so the probe never clocks a pin it doesn't own.
static bool i2c_pulled_up(int sda, int scl) {
    gpio_config_t io = { .pin_bit_mask = (1ULL << sda) | (1ULL << scl), .mode = GPIO_MODE_INPUT,
                         .pull_down_en = GPIO_PULLDOWN_ENABLE };
    gpio_config(&io);
    esp_rom_delay_us(50);
    bool up = gpio_get_level(sda) && gpio_get_level(scl);
    gpio_reset_pin(sda);
    gpio_reset_pin(scl);
    return up;
}

// Every address that answers, once, in the boot log: future boards get fingerprinted from it.
static void i2c_scan_log(int sda, int scl) {
    char found[120] = "";
    int len = 0;
    for (uint16_t a = 0x08; a < 0x78; a++)
        if (len < (int)sizeof(found) - 6 && i2c_master_probe(s_i2c_bus, a, 10) == ESP_OK)
            len += snprintf(found + len, sizeof(found) - len, " 0x%02x", a);
    ESP_LOGI(TAG, "I2C on SDA %d / SCL %d:%s", sda, scl, len ? found : " nothing answered");
}

#if CONFIG_WARDRIVEESP_BENCH_TOOLS
// Bench builds: log what answers on another candidate pair (0/1: the Rabbit Labs Poltergeist's display bus), only
// when both lines read pulled up.
static void i2c_pair_scan(int sda, int scl) {
    if (!i2c_pulled_up(sda, scl)) { ESP_LOGI(TAG, "I2C on SDA %d / SCL %d: no pull-ups, not probed", sda, scl); return; }
    i2c_master_bus_handle_t keep = s_i2c_bus;
    i2c_master_bus_config_t bc = { .i2c_port = -1, .sda_io_num = sda, .scl_io_num = scl,
                                   .clk_source = I2C_CLK_SRC_DEFAULT, .glitch_ignore_cnt = 7 };
    if (i2c_new_master_bus(&bc, &s_i2c_bus) == ESP_OK) {
        i2c_scan_log(sda, scl);
        i2c_del_master_bus(s_i2c_bus);
    }
    s_i2c_bus = keep;
    gpio_reset_pin(sda);
    gpio_reset_pin(scl);
}
#endif

/// True when the battery gauge answers; it stays open for battery_read.
static bool crumb_gauge_probe(void) {
    if (!i2c_pulled_up(CRUMB_SDA, CRUMB_SCL)) return false;
    i2c_master_bus_config_t bc = { .i2c_port = -1, .sda_io_num = CRUMB_SDA, .scl_io_num = CRUMB_SCL,
                                   .clk_source = I2C_CLK_SRC_DEFAULT, .glitch_ignore_cnt = 7 };
    if (i2c_new_master_bus(&bc, &s_i2c_bus) != ESP_OK) return false;
    i2c_scan_log(CRUMB_SDA, CRUMB_SCL);
    i2c_device_config_t dc = { .dev_addr_length = I2C_ADDR_BIT_LEN_7, .device_address = MAX17048_ADDR, .scl_speed_hz = 100000 };
    uint16_t ver = 0;
    if (i2c_master_probe(s_i2c_bus, MAX17048_ADDR, 50) == ESP_OK &&
        i2c_master_bus_add_device(s_i2c_bus, &dc, &s_gauge) == ESP_OK &&
        gauge_read(0x08, &ver) && (ver & 0xFFF0) == 0x0010) {
        s_has_batt = s_gauge_i2c = true;
        battery_read();
        ESP_LOGI(TAG, "battery gauge MAX17048 v%04x: %d%%, %d mV", ver, s_batt_pct, s_batt_mv);
        return true;
    }
    if (s_gauge) { i2c_master_bus_rm_device(s_gauge); s_gauge = NULL; }
    i2c_del_master_bus(s_i2c_bus);
    s_i2c_bus = NULL;
    gpio_reset_pin(CRUMB_SDA);
    gpio_reset_pin(CRUMB_SCL);
    return false;
}
#else
static bool crumb_gauge_probe(void) { return false; }
static void battery_read(void) {}
#endif

/// A pin the board's own hardware uses, so a GPS probe must leave it alone (the Crumb's gauge bus).
static bool board_pin_busy(int gpio) {
#if CONFIG_IDF_TARGET_ESP32C5
    if (s_gauge_i2c && (gpio == CRUMB_SDA || gpio == CRUMB_SCL)) return true;
#endif
    return gpio < 0;
}

#if CONFIG_WARDRIVEESP_BENCH_TOOLS
// `pinsense <gpio>` (bench builds): read a pin with the internal pull-up, then the pull-down, never driving it. A pin
// wired to something that pulls it (a WS2812 input, a pull resistor) reads differently from a floating one.
static bool pin_off_limits(int gpio) {
#if CONFIG_IDF_TARGET_ESP32C5
    static const int8_t NO[] = { 2, 7, 13, 14, 25, 26, 27, 28 };   // strapping, USB D-/D+
#elif CONFIG_IDF_TARGET_ESP32C6
    static const int8_t NO[] = { 4, 5, 8, 9, 12, 13, 15 };
#elif CONFIG_IDF_TARGET_ESP32S3
    static const int8_t NO[] = { 0, 3, 19, 20, 45, 46 };
#else
    static const int8_t NO[] = { 2, 8, 9, 18, 19 };
#endif
    if (!GPIO_IS_VALID_GPIO(gpio)) return true;
#if CONFIG_IDF_TARGET_ESP32C5 || CONFIG_IDF_TARGET_ESP32C6
    if (s_led_task && gpio == s_led_gpio) return false;   // the ring's own pin: reserved by its RMT channel, handed over below
#endif
    if (esp_gpio_is_reserved(BIT64(gpio))) return true;   // flash / PSRAM / a pin a driver holds
    if (gpio == U0TXD_GPIO_NUM || gpio == U0RXD_GPIO_NUM) return true;                 // console / USB-UART link
    for (size_t i = 0; i < sizeof(NO); i++) if (NO[i] == gpio) return true;
#if CONFIG_IDF_TARGET_ESP32C5
    if (s_gauge_i2c && (gpio == 4 || gpio == 5)) return true;                           // the gauge bus
#endif
    return false;
}

static int pin_read(int gpio, bool pull_up) {
    gpio_config_t io = { .pin_bit_mask = 1ULL << gpio, .mode = GPIO_MODE_INPUT,
                         .pull_up_en = pull_up ? GPIO_PULLUP_ENABLE : GPIO_PULLUP_DISABLE,
                         .pull_down_en = pull_up ? GPIO_PULLDOWN_DISABLE : GPIO_PULLDOWN_ENABLE };
    gpio_config(&io);
    esp_rom_delay_us(200);
    int high = 0;
    for (int i = 0; i < 5; i++) { high += gpio_get_level(gpio); esp_rom_delay_us(100); }
    return high;   // of 5 samples
}

static void cmd_pinsense(const char *arg) {
    int gpio = atoi(arg);
    if (!*arg || pin_off_limits(gpio)) { send_line("pinsense: GPIO %s is off limits on %s", *arg ? arg : "?", CONFIG_IDF_TARGET); return; }
#if CONFIG_IDF_TARGET_ESP32C5 || CONFIG_IDF_TARGET_ESP32C6
    bool ring = s_led_task && gpio == s_led_gpio;
    if (ring) {   // hand the pin over: stop the ring's RMT channel, put it back afterwards
        s_led_paused = true;
        vTaskDelay(pdMS_TO_TICKS(80));
        rmt_disable(s_led_chan);
        rmt_del_channel(s_led_chan);
    }
#endif
    int pu = pin_read(gpio, true), pd = pin_read(gpio, false);
    gpio_reset_pin(gpio);
#if CONFIG_IDF_TARGET_ESP32C5 || CONFIG_IDF_TARGET_ESP32C6
    if (ring) {
        rmt_tx_channel_config_t cc = led_channel_config(gpio);
        if (rmt_new_tx_channel(&cc, &s_led_chan) == ESP_OK && rmt_enable(s_led_chan) == ESP_OK) s_led_paused = false;
        else send_line("pinsense: the ring didn't come back, reboot to restore it");
    }
#endif
    send_line("pinsense %d pu=%d pd=%d  (high samples of 5: pull-up %d, pull-down %d)", gpio, pu >= 3, pd >= 3, pu, pd);
}
#endif

// Which board this is, from a hardware fingerprint only: a part that answers and that no other board has, each one
// confirmed on the bench (docs/device-research). Anything not listed is BOARD_NONE.
//   Biscuit Crumb   ESP32-C5 with a MAX17048 battery gauge on SDA 5 / SCL 4 (the Biscuit Ultra's gauge sits on its
//                   other chip, never on its C5)
//   Ghost Board     no fingerprint yet
#if CONFIG_IDF_TARGET_ESP32C5
#define POLT_SDA 0   // the Poltergeist's SSD1306 bus
#define POLT_SCL 1
static bool s_has_disp;
static uint32_t flash_physical_mb(void) {
    uint32_t sz = 0;
    return esp_flash_get_physical_size(NULL, &sz) == ESP_OK ? sz >> 20 : 0;
}
#endif

static board_t board_detect(void) {
#if CONFIG_IDF_TARGET_ESP32C5
    if (s_gauge_i2c) return BOARD_CRUMB;
    if (s_has_disp && flash_physical_mb() == 16) return BOARD_POLTERGEIST;   // SSD1306 on 0/1, 16 MB, no gauge on 5/4
#endif
    return BOARD_NONE;
}

#if CONFIG_IDF_TARGET_ESP32C5
// What the Poltergeist's screen shows, a few times a second.
static void display_fill(display_status_t *st) {
    st->channel = s_crumb_ch;
    const char *m = role_name(s_role);
    for (int i = 0; m[i] && i < (int)sizeof(st->mode) - 1; i++) st->mode[i] = (char)(m[i] - 32 * (m[i] >= 'a' && m[i] <= 'z'));
    st->ble = s_conn_handle != BLE_HS_CONN_HANDLE_NONE;
    st->usb = s_usb_sessions != 0;
    strlcpy(st->holder, s_holder, sizeof(st->holder));
    st->captures = s_cap_hs + s_cap_pmkid;
    st->bt_devices = s_bt_last;
}
#endif

/// CAPS: board=<id> board_name=<name, spaces as '_'>, or nothing for an unidentified board.
static void board_caps_set(const board_def_t *b) {
    char caps[sizeof(s_board_caps)] = "";
    if (b->id) {
        int n = snprintf(caps, sizeof(caps), "board=%s board_name=%s ", b->id, b->name);
        for (int i = (int)strlen(b->id) + 18; i < n - 1; i++) if (caps[i] == ' ') caps[i] = '_';
    }
    strlcpy(s_board_caps, caps, sizeof(s_board_caps));
}

// Boot: the battery gauge (if any), the board's identity, and its LED ring when the identity names one.
static void board_init(void) {
    heap_check("boot: before gauge probe");
    (void)crumb_gauge_probe();   // battery level and the I2C scan, whatever the board turns out to be
    heap_check("boot: after gauge probe");
#if CONFIG_IDF_TARGET_ESP32C5
    s_has_disp = !s_gauge_i2c && display_probe(POLT_SDA, POLT_SCL);
#if CONFIG_WARDRIVEESP_BENCH_TOOLS
    if (!s_has_disp) i2c_pair_scan(0, 1);
#endif
#endif
    s_board = board_detect();
#if CONFIG_IDF_TARGET_ESP32C5
    if (s_has_disp && s_board != BOARD_POLTERGEIST) { display_release(); s_has_disp = false; }   // not ours to drive
#endif
    const board_def_t *b = &BOARDS[s_board];
#if CONFIG_WARDRIVEESP_BENCH_RING
    // Bench builds only: drive the configured ring without an identity, to test the effects on a known board.
    if (!b->pixels) {
        static const board_def_t bench = { NULL, "bench ring", CONFIG_WARDRIVEESP_BENCH_RING_GPIO, CONFIG_WARDRIVEESP_BENCH_RING_PIXELS };
        b = &bench;
    }
#endif
    ESP_LOGI(TAG, "board: %s", b->name);
    board_caps_set(b);
    if (b->pixels) led_start(b->led_gpio, b->pixels);
#if CONFIG_IDF_TARGET_ESP32C5
    if (s_board == BOARD_POLTERGEIST) display_start(b->name, FW_VERSION, display_fill);
#endif
    heap_check("boot: after LED start");
}

static void screen_line(int page, int x, const char *hex) { send_line("WD:SCREEN page=%d x=%d %s", page, x, hex); }
/// `screen`: the panel's current frame, half a page per line (a mirror for the app and for remote checks).
static void cmd_screen(void) {
    if (!display_running()) { send_line("no screen on this board"); return; }
    display_dump(screen_line);
}

static void cmd_help(void) {
    send_line("WardriveESP %s commands:", FW_VERSION);
    send_line("  info          firmware, chip, memory, uptime");
    send_line("  status        scanning, sweeps, channels");
    send_line("  link          what it's connected to (phone address, signal, timing)");
    send_line("  drop          disconnect the phone so another one can link");
    send_line("  ch            show channels  ·  ch 1,6,11  ·  ch all");
    send_line("  start | stop  resume or pause scanning");
    send_line("  bt on|off     scan Bluetooth instead of Wi-Fi");
    send_line("  cap on|off    passive capture (handshakes, PMKIDs, clients)");
    if (s_led_n) {
        send_line("  led           ring state  ·  led alert <pattern> <rrggbb> [seconds]  ·  led test  ·  led off");
        send_line("                patterns: police heartbeat strobe spin pulse sparkle rainbow");
        send_line("  led bright N  ring brightness 0-100  ·  led stealth on|off  keeps the ring dark");
    }
    send_line("  reboot        restart the board");
}

static void cmd_info(void) {
    esp_chip_info_t ci;
    esp_chip_info(&ci);
    uint32_t flash = 0;
    esp_flash_get_size(NULL, &flash);
    uint8_t mac[6] = {0};
    esp_read_mac(mac, ESP_MAC_WIFI_STA);
    const esp_partition_t *run = esp_ota_get_running_partition();
    unsigned long up = (unsigned long)(esp_timer_get_time() / 1000000);
    send_line("WardriveESP %s%s  ·  %s rev %d.%d  ·  %s", FW_VERSION, FW_TAG, CONFIG_IDF_TARGET,
              ci.revision / 100, ci.revision % 100, s_name);
    if (s_has_batt)
        send_line("board %s  ·  LED ring %d px  ·  battery %d%% (%d mV)", BOARDS[s_board].name, s_led_n,
                  s_batt_pct, s_batt_mv);
    else if (s_board || s_led_n)
        send_line("board %s  ·  LED ring %d px%s", BOARDS[s_board].name, s_led_n, display_running() ? "  ·  screen 128x32" : "");
    send_line("Wi-Fi MAC %02x:%02x:%02x:%02x:%02x:%02x", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    send_line("uptime %luh %02lum %02lus  ·  last reset: %s", up / 3600, (up / 60) % 60, up % 60,
              reset_reason_name(esp_reset_reason()));
    send_line("memory %lu KB free (low %lu KB)  ·  flash %lu MB",
              (unsigned long)(esp_get_free_heap_size() / 1024),
              (unsigned long)(esp_get_minimum_free_heap_size() / 1024),
              (unsigned long)(flash / (1024 * 1024)));
    send_line("slot %s  ·  %s  ·  %u channels", run ? run->label : "?",
              s_has_5g ? "2.4 + 5 GHz" : "2.4 GHz", (unsigned)s_supported_n);
    send_line("%s", s_boot_line);
    if (s_crash_line[0]) send_line("%s", s_crash_line);
}

static const char *disc_reason_name(uint32_t r) {
    switch (r & 0xff) {
    case 0x08: return "signal lost (timeout)";
    case 0x13: return "phone disconnected";
    case 0x16: return "board disconnected";
    case 0x3e: return "link setup failed";
    default:   return "other";
    }
}

static void cmd_link(void) {
    uint32_t now = (uint32_t)(esp_timer_get_time() / 1000);
    struct ble_gap_conn_desc d;
    if (!s_ble_synced) {
        send_line("Bluetooth: off while a USB host has the board (or still starting)");
    } else if (s_conn_handle == BLE_HS_CONN_HANDLE_NONE || ble_gap_conn_find(s_conn_handle, &d) != 0) {
        send_line("Bluetooth: not connected  ·  advertising %s as %s", ble_gap_adv_active() ? "yes" : "NO", s_name);
    } else {
        const uint8_t *a = d.peer_id_addr.val;   // little-endian
        int8_t rssi = 0;
        char sig[16] = "?";
        if (ble_gap_conn_rssi(s_conn_handle, &rssi) == 0) snprintf(sig, sizeof(sig), "%d dBm", rssi);
        uint32_t up = (now - s_conn_since_ms) / 1000;
        send_line("Bluetooth: connected to %02X:%02X:%02X:%02X:%02X:%02X  ·  for %luh %02lum %02lus",
                  a[5], a[4], a[3], a[2], a[1], a[0],
                  (unsigned long)(up / 3600), (unsigned long)((up / 60) % 60), (unsigned long)(up % 60));
        send_line("  held by %s%s", s_holder[0] ? s_holder : "an app that didn't say (older version)",
                  s_holder[0] ? (s_holder_ios ? " (iPhone)" : " (Android)") : "");
        send_line("  signal %s  ·  MTU %u  ·  interval %u ms  ·  timeout %u ms  ·  stream %s",
                  sig, (unsigned)ble_att_mtu(s_conn_handle), (unsigned)(d.conn_itvl * 5 / 4),
                  (unsigned)(d.supervision_timeout * 10), s_notify_enabled ? "on" : "off");
    }
    if (s_last_disc_ms)
        send_line("  links since boot %lu  ·  last drop %lus ago: %s (0x%02lx)", (unsigned long)s_conns,
                  (unsigned long)((now - s_last_disc_ms) / 1000), disc_reason_name(s_last_disc_reason),
                  (unsigned long)(s_last_disc_reason & 0xff));
    else
        send_line("  links since boot %lu  ·  no drops", (unsigned long)s_conns);
}

static void cmd_drop(void) {
    if (s_conn_handle == BLE_HS_CONN_HANDLE_NONE) { send_line("no phone connected"); return; }
    send_line("disconnecting the phone · the board advertises again right after");
    (void)ble_gap_terminate(s_conn_handle, BLE_ERR_REM_USER_CONN_TERM);
}

static void cmd_status(void) {
    uint8_t plan[MAX_CHANNELS];
    size_t n = plan_copy(plan);
    char chans[200] = "";
    format_channel_list(chans, 0, sizeof(chans), plan, n);
    uint16_t mtu = s_bt_up && s_conn_handle != BLE_HS_CONN_HANDLE_NONE ? ble_att_mtu(s_conn_handle) : 0;
    if (s_role == ROLE_BT) {
        send_line("mode Bluetooth  ·  scanning %s  ·  %lu windows  ·  %lu devices last window",
                  s_bt_running ? "on" : (s_ota_active ? "paused (updating)" : "off"),
                  (unsigned long)s_bt_windows, (unsigned long)s_bt_last);
    } else if (s_role == ROLE_CAP) {
        send_line("mode Capture  ·  scanning %s  ·  %lu APs  ·  %lu handshakes  ·  %lu pmkid  ·  %lu clients",
                  s_cap_running ? "on" : (s_ota_active ? "paused (updating)" : "off"),
                  (unsigned long)s_cap_aps, (unsigned long)s_cap_hs, (unsigned long)s_cap_pmkid,
                  (unsigned long)s_cap_clients);
        send_line("channels %s", n ? chans : "none");
    } else {
        send_line("mode Wi-Fi  ·  scanning %s  ·  %lu sweeps  ·  %lu APs last sweep",
                  s_streaming ? "on" : (s_ota_active ? "paused (updating)" : "off"),
                  (unsigned long)s_sweeps, (unsigned long)s_last_aps);
        send_line("channels %s", n ? chans : "none");
    }
    uint8_t u = s_usb_sessions;
    send_line("BLE MTU %u  ·  USB %s", (unsigned)mtu,
              (u & SINK_USB) && (u & SINK_UART) ? "usb+uart" : (u & SINK_USB) ? "usb" : (u & SINK_UART) ? "uart" : "off");
}

static void cmd_channels(const char *arg) {
    if (!*arg) {
        char sup[200] = "", cur[200] = "";
        uint8_t plan[MAX_CHANNELS];
        size_t n = plan_copy(plan);
        format_channel_list(sup, 0, sizeof(sup), s_supported, s_supported_n);
        format_channel_list(cur, 0, sizeof(cur), plan, n);
        send_line("supported %s", sup);
        send_line("scanning  %s", n ? cur : "none");
        return;
    }
    if (!strcmp(arg, "all")) {
        plan_reset_to_all();
        if (s_streaming) send_plan_line();
        send_line("scanning all %u channels", (unsigned)s_supported_n);
        return;
    }
    if (!apply_channel_list(arg)) { send_line("none of those channels are supported"); cmd_channels(""); return; }
    send_line("ok — the app re-splits channels when a board links or drops");
}

static void reboot_task(void *arg) {
    (void)arg;
    wait_role_tasks(2000);           // queued records go out first
    vTaskDelay(pdMS_TO_TICKS(400));  // let the last lines go out
    esp_restart();
}

static void cmd_reboot(void) {
    send_line("rebooting");
    s_rebooting = true;
    s_switch_pending = false;
    stream_stop();
    if (xTaskCreate(reboot_task, "reboot", 2048, NULL, 5, NULL) != pdPASS) {
        vTaskDelay(pdMS_TO_TICKS(400));
        esp_restart();
    }
}

static SemaphoreHandle_t s_cmd_lock;   // commands from BLE and USB run one at a time

static void exec_command(char *p) {
    char word[16];
    size_t wlen = strcspn(p, " ");
    if (wlen >= sizeof(word)) wlen = sizeof(word) - 1;
    memcpy(word, p, wlen);
    word[wlen] = '\0';
    const char *rest = p + strcspn(p, " ");
    while (*rest == ' ') rest++;

    if (!strcmp(word, "ota")) {
        if (!strncmp(rest, "begin ", 6)) ota_begin(rest + 6);
        else if (!strcmp(rest, "end")) { if (s_ota_active) s_ota_end_req = true; }
        else if (!strcmp(rest, "abort")) { if (s_ota_active) s_ota_abort_req = true; }
    }
    else if (!strcmp(word, "help"))     cmd_help();
    else if (!strcmp(word, "info"))     cmd_info();
    else if (!strcmp(word, "status"))   cmd_status();
    else if (!strcmp(word, "caps"))     send_caps_line();
    else if (!strcmp(word, "ch"))       cmd_channels(rest);
    else if (!strcmp(word, "reboot"))   cmd_reboot();
    else if (!strcmp(word, "link"))     cmd_link();
    else if (!strcmp(word, "drop"))     cmd_drop();
    else if (!strcmp(word, "hb") || !strcmp(word, "client")) {}   // sent by app builds from 2026-10-22: ignore quietly
    else if (!strcmp(word, "iam")) {   // "iam a|i <nickname>": who holds this link, for the status beacon (silent)
        if ((rest[0] == 'a' || rest[0] == 'i') && rest[1] == ' ') {
            s_holder_ios = rest[0] == 'i';
            size_t h = strlen(rest + 2);
            if (h > HOLDER_MAX) { h = HOLDER_MAX; while (h && ((uint8_t)rest[2 + h] & 0xC0) == 0x80) h--; }   // whole UTF-8 characters only
            memcpy(s_holder, rest + 2, h); s_holder[h] = '\0';
            if (host_linked() && s_link_ready) ble_npl_callout_reset(&s_beacon_tick, 0);
        }
    }
    else if (!strcmp(word, "led"))      cmd_led(rest);
    else if (!strcmp(word, "screen"))   cmd_screen();
#if CONFIG_WARDRIVEESP_BENCH_TOOLS
    else if (!strcmp(word, "pinsense")) cmd_pinsense(rest);
    else if (!strcmp(word, "benchbt")) {
        s_bench_keep_bt = !strcmp(rest, "on");
        bt_power_kick();
        send_line("bench: Bluetooth %s during USB sessions", s_bench_keep_bt ? "kept on" : "off");
    }
#endif
    else if (!strcmp(word, "stop"))     stream_stop();
    else if (!strcmp(word, "start"))    stream_start();
    else if (!strcmp(word, "bt")) {
        if (!strcmp(rest, "on"))       set_role(ROLE_BT);
        else if (!strcmp(rest, "off")) set_role(ROLE_WIFI);
        else send_line("mode %s  ·  bt on | bt off",
                       s_role == ROLE_BT ? "Bluetooth" : s_role == ROLE_CAP ? "Capture" : "Wi-Fi");
    }
    else if (!strcmp(word, "cap")) {
        if (!strcmp(rest, "on"))       set_role(ROLE_CAP);
        else if (!strcmp(rest, "off")) set_role(ROLE_WIFI);
        else send_line("mode %s  ·  cap on | cap off",
                       s_role == ROLE_CAP ? "Capture" : s_role == ROLE_BT ? "Bluetooth" : "Wi-Fi");
    }
    else if (!strcmp(word, "wdstream")) {
        if (strstr(rest, "stop")) { stream_stop(); return; }
        const char *ch_arg = strstr(rest, "-ch ");
        if (ch_arg && !apply_channel_list(ch_arg + 4)) send_line("WD:ERR reason=no_supported_channels");
        if (strstr(rest, "-promisc") || strstr(rest, "-cap")) { set_role(ROLE_CAP); return; }
        if (strstr(rest, "-bt"))   { set_role(ROLE_BT);   return; }
        if (strstr(rest, "-wifi")) { set_role(ROLE_WIFI); return; }
        stream_start();
    }
    else { send_line("unknown command '%s'", word); cmd_help(); }
}

static void run_command(const uint8_t *text, size_t len, uint8_t src) {
    char cmd[CMD_MAX + 1];
    size_t n = len < CMD_MAX ? len : CMD_MAX;
    memcpy(cmd, text, n);
    cmd[n] = '\0';
    ESP_LOGI(TAG, "cmd: '%s'", cmd);

    char *p = cmd;
    while (*p == ' ') p++;
    size_t plen = strlen(p);
    while (plen && (p[plen - 1] == ' ' || p[plen - 1] == '\r' || p[plen - 1] == '\n')) p[--plen] = '\0';
    if (!*p) return;
    xSemaphoreTake(s_cmd_lock, portMAX_DELAY);
    s_cmd_src = src;
    heap_check("before command");
    exec_command(p);
    heap_check("after command");
    xSemaphoreGive(s_cmd_lock);
}

static void handle_command(const uint8_t *data, uint16_t len) {
    const uint8_t *text = data;
    uint16_t text_len = len;
    if (len >= FR_HEADER && data[0] == FR_MAGIC_0 && data[1] == FR_MAGIC_1) {
        uint16_t plen = (uint16_t)(data[10] | (data[11] << 8));
        if (FR_HEADER + (size_t)plen <= len) {
            s_reply_id = (uint32_t)data[6] | ((uint32_t)data[7] << 8) | ((uint32_t)data[8] << 16) | ((uint32_t)data[9] << 24);
            if (data[3] == FR_CMD) {
                text = data + FR_HEADER;
                text_len = plen;
                send_ack();
            }
        }
    }
    run_command(text, text_len, SINK_BLE);
}

// ─── USB transport (PROTOCOL.md "USB") ─────────────────────────────────────
// One task serves both ports. A port shows ESP-IDF logs until `wdusb hello`, then carries only protocol lines
// until `wdusb bye`, 60 s of silence, or (native USB) unplug / a host that stops reading.
#define USB_IDLE_MS      60000
#define USB_STALL_MS     5000
#define USB_LOST_MS      1000
#define USB_RAW_IDLE_MS  10000

typedef struct {
    uint8_t  sink;
    bool     up;               // driver installed
    bool     overflow;         // current line is too long; dropped at its newline
    size_t   len;
    char     line[CMD_MAX + 1];
    uint32_t last_rx_ms;
    uint32_t lost_ms;          // first moment the host looked gone, 0 = present
    uint32_t raw_left;         // firmware image bytes still due after WD:OTA ready
} usb_port_t;

static usb_port_t s_usj  = { .sink = SINK_USB };
static usb_port_t s_uart = { .sink = SINK_UART };
static volatile uint32_t s_usj_fail_ms = 0;   // first failed write of the current stall, 0 = writes go through
static TaskHandle_t s_usb_task = NULL;
static vprintf_like_t s_log_orig = NULL;
static SemaphoreHandle_t s_log_lock;
static char s_log_buf[256];

static uint32_t now_ms(void) { return (uint32_t)(esp_timer_get_time() / 1000); }

// Called under s_send_lock. Never blocks: a line that doesn't fit the TX buffer is dropped.
static void usb_emit_locked(uint8_t sinks, const char *buf, size_t n) {
    uint8_t s = sinks & s_usb_sessions;
    (void)s; (void)buf; (void)n;
#if USB_JTAG_LINK
    if ((s & SINK_USB) && s_usj.up) {
        if (usb_serial_jtag_write_bytes(buf, n, 0) == (int)n) s_usj_fail_ms = 0;
        else if (!s_usj_fail_ms) s_usj_fail_ms = now_ms() | 1;
    }
#endif
#if UART_LINK
    if ((s & SINK_UART) && s_uart.up) {
        size_t room = 0;
        if (uart_get_tx_buffer_free_size(LINK_UART, &room) == ESP_OK && room >= n) uart_write_bytes(LINK_UART, buf, n);
    }
#endif
}

// Log text stays off a port while it carries a session; the other port keeps getting it.
static int log_vprintf(const char *fmt, va_list ap) {
    uint8_t sess = s_usb_sessions;
    if (!sess) return s_log_orig ? s_log_orig(fmt, ap) : vprintf(fmt, ap);
    if (xPortInIsrContext() || xTaskGetSchedulerState() != taskSCHEDULER_RUNNING || !s_log_lock) return 0;
    if (xSemaphoreTake(s_log_lock, pdMS_TO_TICKS(50)) != pdTRUE) return 0;
    int n = vsnprintf(s_log_buf, sizeof(s_log_buf), fmt, ap);
    if (n > (int)sizeof(s_log_buf) - 1) n = (int)sizeof(s_log_buf) - 1;
    if (n > 0) {
#if UART_LINK
        if (!(sess & SINK_UART) && s_uart.up) uart_write_bytes(LINK_UART, s_log_buf, (size_t)n);
#endif
#if USB_JTAG_LINK
        if (!(sess & SINK_USB) && s_usj.up) usb_serial_jtag_write_bytes(s_log_buf, (size_t)n, 0);
#endif
    }
    xSemaphoreGive(s_log_lock);
    return n;
}

static usb_port_t *usb_port(uint8_t sink) { return sink == SINK_USB ? &s_usj : &s_uart; }

// Called from ota_begin (in the USB task) once the board is ready for the image.
static void usb_arm_raw(uint8_t sink, uint32_t size) { usb_port(sink)->raw_left = size; }

// Called under s_cmd_lock.
static void usb_session_end(usb_port_t *p, const char *reason) {
    if (!(s_usb_sessions & p->sink)) return;
    if (reason) send_line_to(p->sink, "WD:USB bye reason=%s", reason);
    s_usb_sessions &= (uint8_t)~p->sink;
    if (p->sink == SINK_USB) s_usj_fail_ms = 0;
    if (s_ota_active && s_ota_src == p->sink) s_ota_abort_req = true;
    p->raw_left = 0;
    if (!host_linked()) {
        s_switch_pending = false;
        stream_stop();
        s_role = ROLE_WIFI;
        plan_reset_to_all();
        s_holder[0] = '\0'; s_holder_ios = false;
    }
    if (s_link_ready) ble_npl_callout_reset(&s_link_switch, 0);   // connectable again once no USB host is left
    bt_power_kick();
    ESP_LOGI(TAG, "%s session closed (%s)", sink_name(p->sink), reason ? reason : "host gone");
}

// Called under s_cmd_lock.
static void usb_hello(usb_port_t *p) {
    if (!(s_usb_sessions & p->sink)) {
        ESP_LOGI(TAG, "%s session open", sink_name(p->sink));
        if (!host_linked()) {
            s_role = ROLE_WIFI;
            s_switch_pending = false;
            plan_reset_to_all();
        }
        if (p->sink == SINK_USB) s_usj_fail_ms = 0;
        p->lost_ms = 0;
        s_usb_sessions |= p->sink;
        if (s_link_ready) ble_npl_callout_reset(&s_link_switch, 0);   // USB-only: Bluetooth steps aside
        bt_power_kick();
        led_storm();
    }
    host_joined(p->sink);
}

// ─── Biscuit co-processor (PROTOCOL.md "Co-processor (WDCP)", 1.6.7) ──────
// On a Biscuit Pro / Ultra the C5's UART0 pins (TX GPIO 11 / RX GPIO 12, the console and UART link above) are wired
// to the board's second chip, an ESP32 WROOM that holds the battery gauge. With the WardriveESP co-processor flashed
// there, the WROOM says `WDCP hello` and then sends the gauge every 30 s. Listening costs nothing (UART0 RX is up on
// every C5 build anyway), and nothing is ever sent to it until a valid hello was heard, so other C5 boards never see
// a WDCP line. A hello is also the board's fingerprint: only a Biscuit two-chip board has a WROOM on these pins.
#if CONFIG_IDF_TARGET_ESP32C5 && UART_LINK
#define COPROC 1
#define COPROC_PING_MS   30000
#define COPROC_STALE_MS  120000
static volatile bool     s_cp_present;
static volatile uint32_t s_cp_last_rx;    // last line from the co-processor
static uint32_t s_cp_last_ping;
static char s_cp_fw[16];

static void coproc_send(const char *what) {
    if (!s_uart.up) return;
    char buf[48];   // leading newline: ends any log line in flight on the shared wire first
    int n = snprintf(buf, sizeof(buf), "\r\nWDCP %s\r\n", what);
    if (n > 0 && n < (int)sizeof(buf)) uart_write_bytes(LINK_UART, buf, (size_t)n);
}

/// The value of `key=` in a line of space-separated key=value pairs, copied into out ("" when absent).
static void coproc_kv(const char *s, const char *key, char *out, size_t cap) {
    size_t kl = strlen(key);
    out[0] = '\0';
    for (const char *p = s; (p = strstr(p, key)) != NULL; p += kl) {
        if ((p != s && p[-1] != ' ') || p[kl] != '=') continue;
        const char *v = p + kl + 1;
        size_t n = strcspn(v, " \r\n");
        if (n >= cap) n = cap - 1;
        memcpy(out, v, n);
        out[n] = '\0';
        return;
    }
}

static void coproc_hello(const char *args) {
    char proto[8], board[24], fw[16], gauge[4];
    coproc_kv(args, "proto", proto, sizeof(proto));
    coproc_kv(args, "board", board, sizeof(board));
    coproc_kv(args, "fw", fw, sizeof(fw));
    coproc_kv(args, "gauge", gauge, sizeof(gauge));
    board_t nb = !strcmp(board, "biscuit_pro") ? BOARD_BISCUIT_PRO : !strcmp(board, "biscuit_ultra") ? BOARD_BISCUIT_ULTRA :
                 !strcmp(board, "biscuit_dual") ? BOARD_BISCUIT_DUAL : BOARD_NONE;
    if (atoi(proto) < 1 || nb == BOARD_NONE || !fw[0]) return;   // not a hello we understand: stay silent
    bool with_gauge = !strcmp(gauge, "1");
    xSemaphoreTake(s_cmd_lock, portMAX_DELAY);
    bool news = !s_cp_present || s_board != nb || (with_gauge && !s_has_batt) || strcmp(fw, s_cp_fw);
    // A board identified some other way (a Crumb's gauge, the Poltergeist's screen) keeps that identity.
    if (news && (s_board == BOARD_NONE || s_board >= BOARD_BISCUIT_PRO)) {
        s_cp_present = true;
        strlcpy(s_cp_fw, fw, sizeof(s_cp_fw));
        s_board = nb;
        board_caps_set(&BOARDS[nb]);
        if (with_gauge) s_has_batt = true;
        if (BOARDS[nb].pixels) led_start(BOARDS[nb].led_gpio, BOARDS[nb].pixels);
        ESP_LOGI(TAG, "co-processor %s on UART0: board %s, battery gauge %s", fw, BOARDS[nb].name, with_gauge ? "yes" : "no");
        send_caps_line();   // linked hosts get the board and batt=1 now, not at their next link
    }
    xSemaphoreGive(s_cmd_lock);
    if (!s_cp_present) return;
    s_cp_last_rx = s_cp_last_ping = now_ms();
    coproc_send("ping");    // answered: the co-processor stops repeating its hello
    coproc_send("batt?");
}

/// A line from UART0: true when it was the co-processor's (consumed), false for anything else.
static bool coproc_line(const char *line) {
    const char *w = strstr(line, "WDCP ");   // our own log text can run into it on the wire
    if (!w) return false;
    const char *c = w + 5;
    while (*c == ' ') c++;
    if (!strncmp(c, "hello ", 6)) { coproc_hello(c + 6); return true; }
    if (!s_cp_present) return true;          // nothing else counts before a valid hello
    s_cp_last_rx = now_ms();
    if (!strncmp(c, "batt ", 5)) {
        int pct = -1, mv = 0;
        if (sscanf(c + 5, "%d %d", &pct, &mv) == 2) {
            s_batt_pct = (pct >= 0 && pct <= 100) ? pct : -1;
            s_batt_mv = pct >= 0 ? mv : 0;
        }
    }
    return true;   // pong, err and later verbs: nothing to do
}

/// From the health task, once a second: keep the co-processor answering, and forget a battery level it stopped sending.
static void coproc_tick(uint32_t now) {
    if (!s_cp_present) return;
    if (now - s_cp_last_ping >= COPROC_PING_MS) { s_cp_last_ping = now; coproc_send("ping"); }
    if (s_batt_pct >= 0 && now - s_cp_last_rx > COPROC_STALE_MS) {
        s_batt_pct = -1;
        ESP_LOGW(TAG, "co-processor silent for %lu s, battery unknown", (unsigned long)(COPROC_STALE_MS / 1000));
    }
}
#else
#define COPROC 0
#endif

static void usb_line(usb_port_t *p) {
    p->line[p->len] = '\0';
    char *s = p->line;
#if COPROC
    if (p->sink == SINK_UART && coproc_line(s)) return;
#endif
    while (*s == ' ') s++;
    if (!strncmp(s, "wdusb", 5) && (s[5] == '\0' || s[5] == ' ')) {
        const char *arg = s + 5;
        while (*arg == ' ') arg++;
        bool in_session = s_usb_sessions & p->sink;
        xSemaphoreTake(s_cmd_lock, portMAX_DELAY);
        if (!strncmp(arg, "hello", 5)) usb_hello(p);
        else if (in_session && !strncmp(arg, "ping", 4)) send_line_to(p->sink, "WD:USB pong");
        else if (in_session && !strncmp(arg, "bye", 3)) usb_session_end(p, "host");
        xSemaphoreGive(s_cmd_lock);
        return;
    }
    if (s_usb_sessions & p->sink) run_command((const uint8_t *)s, strlen(s), p->sink);
}

static void usb_rx(usb_port_t *p, const uint8_t *buf, size_t n) {
    p->last_rx_ms = now_ms();
    for (size_t i = 0; i < n;) {
        if (p->raw_left) {
            size_t take = n - i < p->raw_left ? n - i : p->raw_left;
            if (s_ota_active && s_ota_src == p->sink && s_ota_buf &&
                xStreamBufferSend(s_ota_buf, buf + i, take, pdMS_TO_TICKS(2000)) != take)
                s_ota_abort_req = true;   // host ignored the window
            p->raw_left -= take;
            i += take;
            continue;
        }
        char c = (char)buf[i++];
        if (c == '\n' || c == '\r') {
            if (p->len && !p->overflow) usb_line(p);
            p->len = 0;
            p->overflow = false;
        } else if (p->len < CMD_MAX) {
            p->line[p->len++] = c;
        } else {
            p->overflow = true;
        }
    }
}

static void usb_watch(usb_port_t *p, uint32_t now, bool gone) {
    if (p->raw_left && now - p->last_rx_ms > USB_RAW_IDLE_MS) {
        p->raw_left = 0;
        if (s_ota_active && s_ota_src == p->sink) s_ota_abort_req = true;
    }
    if (!(s_usb_sessions & p->sink)) return;
    if (!gone) p->lost_ms = 0;
    else if (!p->lost_ms) p->lost_ms = now | 1;
    bool lost = p->lost_ms && now - p->lost_ms > USB_LOST_MS;
    bool idle = now - p->last_rx_ms > USB_IDLE_MS;
    if (!lost && !idle) return;
    xSemaphoreTake(s_cmd_lock, portMAX_DELAY);
    usb_session_end(p, lost ? NULL : "idle");
    xSemaphoreGive(s_cmd_lock);
}

static void usb_task(void *arg) {
    (void)arg;
    static uint8_t buf[512];
    for (;;) {
#if USB_JTAG_LINK
        if (s_usj.up) {
            int n = usb_serial_jtag_read_bytes(buf, sizeof(buf), pdMS_TO_TICKS(10));
            if (n > 0) usb_rx(&s_usj, buf, (size_t)n);
        } else {
            vTaskDelay(pdMS_TO_TICKS(10));
        }
#else
        vTaskDelay(pdMS_TO_TICKS(10));
#endif
#if UART_LINK
        size_t avail = 0;
        while (s_uart.up && uart_get_buffered_data_len(LINK_UART, &avail) == ESP_OK && avail) {
            int m = uart_read_bytes(LINK_UART, buf, avail < sizeof(buf) ? avail : sizeof(buf), 0);
            if (m <= 0) break;
            usb_rx(&s_uart, buf, (size_t)m);
        }
#endif
        uint32_t now = now_ms();
#if USB_JTAG_LINK
        uint32_t fail = s_usj_fail_ms;
        usb_watch(&s_usj, now, !usb_serial_jtag_is_connected() || (fail && now - fail > USB_STALL_MS));
#endif
#if UART_LINK
        usb_watch(&s_uart, now, false);
#endif
    }
}

static void usb_link_start(void) {
    s_log_lock = xSemaphoreCreateMutex();
#if USB_JTAG_LINK
    usb_serial_jtag_driver_config_t ucfg = USB_SERIAL_JTAG_DRIVER_CONFIG_DEFAULT();
    ucfg.tx_buffer_size = 4096;
    ucfg.rx_buffer_size = 1024;
    if (usb_serial_jtag_driver_install(&ucfg) == ESP_OK) {
        usb_serial_jtag_vfs_use_driver();
        s_usj.up = true;
    } else {
        ESP_LOGW(TAG, "USB-Serial-JTAG link unavailable");
    }
#endif
#if UART_LINK
    if (uart_driver_install(LINK_UART, 2048, 4096, 0, NULL, 0) == ESP_OK) {
        uart_vfs_dev_use_driver(LINK_UART);
        s_uart.up = true;
    } else {
        ESP_LOGW(TAG, "UART0 link unavailable");
    }
#endif
    if (!s_usj.up && !s_uart.up) return;
    s_log_orig = esp_log_set_vprintf(log_vprintf);
    if (xTaskCreate(usb_task, "wd_usb", 8192, NULL, 4, &s_usb_task) != pdPASS) ESP_LOGE(TAG, "USB task create failed");
}

static int on_command_write(uint16_t conn, uint16_t attr, struct ble_gatt_access_ctxt *ctxt, void *arg) {
    (void)conn; (void)attr; (void)arg;
    if (ctxt->op != BLE_GATT_ACCESS_OP_WRITE_CHR) return BLE_ATT_ERR_UNLIKELY;
    uint8_t buf[256];
    uint16_t got = 0;
    if (ble_hs_mbuf_to_flat(ctxt->om, buf, sizeof(buf), &got) != 0) return BLE_ATT_ERR_UNLIKELY;
    handle_command(buf, got);
    return 0;
}

static int on_tx_access(uint16_t conn, uint16_t attr, struct ble_gatt_access_ctxt *ctxt, void *arg) {
    (void)conn; (void)attr; (void)ctxt; (void)arg;
    return 0;
}

static const struct ble_gatt_chr_def CHARACTERISTICS[] = {
    { .uuid = &RX_UUID.u,   .access_cb = on_command_write, .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP },
    { .uuid = &TX_UUID.u,   .access_cb = on_tx_access,     .flags = BLE_GATT_CHR_F_NOTIFY, .val_handle = &s_tx_val_handle },
    { .uuid = &CTRL_UUID.u, .access_cb = on_command_write, .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP },
    { .uuid = &OTA_UUID.u,  .access_cb = on_ota_write,     .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP },
    { 0 },
};
static const struct ble_gatt_svc_def SERVICES[] = {
    { .type = BLE_GATT_SVC_TYPE_PRIMARY, .uuid = &SVC_UUID.u, .characteristics = CHARACTERISTICS },
    { 0 },
};

// ─── Status beacon (1.6.5) ───────────────────────────────────────────────
// Every phone nearby sees every board and who holds it, so a board busy on another phone is shown as busy instead
// of looking broken. Manufacturer data (company 0xFFFF), little-endian:
//   [0] 'W'   [1] flags: b0 linked, b1 scanning, b2-3 mode (0 Wi-Fi, 1 Bluetooth, 2 capture), b4 USB host,
//                       b5 GPS, b6 updating, b7 holder is an iPhone
//   [2] chip temperature, °C (int8, -128 = unknown)   [3-4] APs last sweep / BT devices last window / capture APs
//   [5] firmware major<<4 | minor   [6] patch   [7-8] the address bytes in the board's name
//   [9..] the holder's nickname, UTF-8, up to 18 bytes (linked boards only)
// A free board: SVC_UUID + name + bytes 0-8 (connectable, as before). A linked board: STATUS_UUID + bytes 0-26
// (non-connectable, once a second).
static volatile int8_t s_temp_c = -128;
static uint8_t s_beacon_last[BEACON_FIXED + HOLDER_MAX];
static size_t s_beacon_last_len = 0;
#if SOC_TEMP_SENSOR_SUPPORTED
static temperature_sensor_handle_t s_tsens;
#endif

static size_t beacon_payload(uint8_t *b, bool with_holder) {
    static int fw_maj = -1, fw_min, fw_pat;
    if (fw_maj < 0 && sscanf(FW_VERSION, "%d.%d.%d", &fw_maj, &fw_min, &fw_pat) != 3) { fw_maj = fw_min = fw_pat = 0; }
    uint32_t n = s_role == ROLE_BT ? s_bt_last : s_role == ROLE_CAP ? s_cap_aps : s_last_aps;
    if (n > 0xFFFF) n = 0xFFFF;
    bool linked = host_linked();   // a Bluetooth phone or a USB host
    b[0] = 'W';
    b[1] = (linked ? 0x01 : 0) | ((s_streaming || s_bt_running || s_cap_running) ? 0x02 : 0) | ((s_role & 3) << 2) |
           (s_usb_sessions ? 0x10 : 0) | (s_gps_present ? 0x20 : 0) | (s_ota_active ? 0x40 : 0) |
           (linked && s_holder_ios ? 0x80 : 0);
    b[2] = (uint8_t)s_temp_c;
    b[3] = n & 0xFF; b[4] = n >> 8;
    b[5] = (uint8_t)(((fw_maj & 0xF) << 4) | (fw_min & 0xF)); b[6] = (uint8_t)fw_pat;
    b[7] = s_addr_tail[0]; b[8] = s_addr_tail[1];
    size_t len = BEACON_FIXED;
    if (with_holder && linked) {
        size_t h = strlen(s_holder);
        memcpy(b + len, s_holder, h);
        len += h;
    }
    return len;
}

static uint8_t s_mfg[2 + BEACON_FIXED + HOLDER_MAX];   // company id + payload, kept alive for the stack

// Free board: connectable, the service UUID up front, name + status in the scan response (exactly 31 bytes).
static void set_free_fields(void) {
    struct ble_hs_adv_fields adv = {0};
    adv.flags = BLE_HS_ADV_F_DISC_GEN | BLE_HS_ADV_F_BREDR_UNSUP;
    adv.uuids128 = (ble_uuid128_t *)&SVC_UUID;
    adv.num_uuids128 = 1;
    adv.uuids128_is_complete = 1;
    if (ble_gap_adv_set_fields(&adv) != 0) ESP_LOGE(TAG, "adv fields rejected");
    struct ble_hs_adv_fields rsp = {0};
    rsp.name = (const uint8_t *)s_name;
    rsp.name_len = strlen(s_name);
    rsp.name_is_complete = 1;
    s_mfg[0] = 0xFF; s_mfg[1] = 0xFF;
    size_t n = beacon_payload(s_mfg + 2, false);
    if (2 + rsp.name_len + 4 + n <= BLE_HS_ADV_MAX_SZ) { rsp.mfg_data = s_mfg; rsp.mfg_data_len = 2 + n; }
    (void)ble_gap_adv_rsp_set_fields(&rsp);
}

// Linked board: the status UUID (apps that predate it ignore it) + status and holder in the scan response.
static void set_busy_fields(void) {
    struct ble_hs_adv_fields adv = {0};
    adv.flags = BLE_HS_ADV_F_DISC_GEN | BLE_HS_ADV_F_BREDR_UNSUP;
    adv.uuids128 = (ble_uuid128_t *)&STATUS_UUID;
    adv.num_uuids128 = 1;
    adv.uuids128_is_complete = 1;
    if (ble_gap_adv_set_fields(&adv) != 0) ESP_LOGE(TAG, "beacon fields rejected");
    struct ble_hs_adv_fields rsp = {0};
    s_mfg[0] = 0xFF; s_mfg[1] = 0xFF;
    rsp.mfg_data = s_mfg;
    rsp.mfg_data_len = 2 + beacon_payload(s_mfg + 2, true);
    (void)ble_gap_adv_rsp_set_fields(&rsp);
}

static void start_advertising(void) {
    if (ble_gap_adv_active()) (void)ble_gap_adv_stop();   // the linked-board beacon, if it was still up
    set_free_fields();
    struct ble_gap_adv_params params = { .conn_mode = BLE_GAP_CONN_MODE_UND, .disc_mode = BLE_GAP_DISC_MODE_GEN };
    if (ble_gap_adv_start(s_own_addr_type, NULL, BLE_HS_FOREVER, &params, on_gap_event, NULL) != 0) {
        ESP_LOGE(TAG, "advertising failed to start");
        return;
    }
    ESP_LOGI(TAG, "advertising as '%s'", s_name);
}

// While a phone or a USB host holds the board: keep telling everyone nearby it's taken, and by whom.
static void start_beacon(void) {
    if (!host_linked()) return;
    if (ble_gap_adv_active()) (void)ble_gap_adv_stop();
    set_busy_fields();
    struct ble_gap_adv_params params = { .conn_mode = BLE_GAP_CONN_MODE_NON, .disc_mode = BLE_GAP_DISC_MODE_GEN,
                                         .itvl_min = 1600, .itvl_max = 1760 };   // 1-1.1 s: barely any airtime
    int rc = ble_gap_adv_start(s_own_addr_type, NULL, BLE_HS_FOREVER, &params, on_gap_event, NULL);
    if (rc != 0) ESP_LOGW(TAG, "status beacon didn't start: %d", rc);
}

// Every 5 s (and right after `iam`): fresh temperature, and new advertising data when anything in it changed.
static void beacon_tick(struct ble_npl_event *ev) {
    (void)ev;
    heap_check("beacon tick");
#if SOC_TEMP_SENSOR_SUPPORTED
    float t;
    if (s_tsens && temperature_sensor_get_celsius(s_tsens, &t) == ESP_OK) s_temp_c = (int8_t)(t < -127 ? -127 : t > 127 ? 127 : t);
#endif
    uint8_t b[BEACON_FIXED + HOLDER_MAX];
    bool linked = host_linked();
    size_t n = beacon_payload(b, linked);
    if (n != s_beacon_last_len || memcmp(b, s_beacon_last, n) != 0) {
        memcpy(s_beacon_last, b, n); s_beacon_last_len = n;
        if (linked) start_beacon();
        else if (ble_gap_adv_active()) set_free_fields();
    } else if (linked && !ble_gap_adv_active()) {
        start_beacon();
    }
    ble_npl_callout_reset(&s_beacon_tick, ble_npl_time_ms_to_ticks32(5000));
}

static int on_gap_event(struct ble_gap_event *event, void *arg) {
    (void)arg;
    switch (event->type) {
    case BLE_GAP_EVENT_CONNECT:
        if (event->connect.status != 0) { start_advertising(); return 0; }
        s_conn_handle = event->connect.conn_handle;
        s_conns++;
        s_holder[0] = '\0'; s_holder_ios = false;
        s_conn_since_ms = (uint32_t)(esp_timer_get_time() / 1000);
        s_notify_enabled = false;
        if (!s_usb_sessions) {
            s_role = ROLE_WIFI;
            s_switch_pending = false;
            plan_reset_to_all();
        }
        ESP_LOGI(TAG, "phone connected");
        heap_check("ble connect");
        led_storm();
        start_beacon();
        request_link_params(false);
        return 0;

    case BLE_GAP_EVENT_DISCONNECT:
        ESP_LOGI(TAG, "phone disconnected (reason %d)", event->disconnect.reason);
        heap_check("ble disconnect");
        s_last_disc_reason = (uint32_t)event->disconnect.reason;
        s_last_disc_ms = (uint32_t)(esp_timer_get_time() / 1000);
        s_conn_handle = BLE_HS_CONN_HANDLE_NONE;
        s_notify_enabled = false;
        if (s_ota_active && s_ota_src == SINK_BLE) s_ota_abort_req = true;
        if (s_usb_sessions) {   // USB holds the board: scanning carries on, the beacon keeps naming the holder
            start_beacon();
            return 0;
        }
        s_holder[0] = '\0'; s_holder_ios = false;
        s_switch_pending = false;
        stream_stop();
        s_role = ROLE_WIFI;
        plan_reset_to_all();
        start_advertising();
        return 0;

    case BLE_GAP_EVENT_SUBSCRIBE:
        if (event->subscribe.attr_handle != s_tx_val_handle) return 0;
        s_notify_enabled = event->subscribe.cur_notify;
        ESP_LOGI(TAG, "notifications %s", s_notify_enabled ? "on" : "off");
        heap_check("subscribe");
        if (s_notify_enabled) host_joined(SINK_BLE);
        else if (!s_usb_sessions) stream_stop();
        return 0;

    case BLE_GAP_EVENT_MTU:
        ESP_LOGI(TAG, "MTU %u", event->mtu.value);
        heap_check("mtu");
        return 0;

    case BLE_GAP_EVENT_CONN_UPDATE:
        send_conn_line(event->conn_update.status);
        return 0;

    default:
        return 0;
    }
}

// A phone that's already waiting can connect the instant the board advertises. A link that lands while the radios are
// still starting up corrupts memory inside the Wi-Fi/Bluetooth stack (bench 2026-10-22: ~1 in 6 boots, crash ~15 s
// later), so the first advertising waits until startup has settled.
#if CONFIG_WARDRIVEESP_BENCH_NO_ADV_SETTLE
#define ADV_SETTLE_MS 1   // bench: 1.6.3 timing, to reproduce the early-link corruption
#else
#define ADV_SETTLE_MS 2000
#endif
static struct ble_npl_callout s_adv_settle;

/// Free board: connectable advertising. Held over USB: the busy beacon, and no phone can link (USB-only, 1.6.6).
static void advertise_for_state(void) {
    if (s_conn_handle != BLE_HS_CONN_HANDLE_NONE) return;
    if (s_usb_sessions) start_beacon(); else start_advertising();
}

static void adv_settle_done(struct ble_npl_event *ev) {
    (void)ev;
    if (s_conn_handle == BLE_HS_CONN_HANDLE_NONE && !ble_gap_adv_active()) advertise_for_state();
}

// A USB session opened or closed (posted by usb_hello / usb_session_end, run on the BLE host task). A board held over
// USB lets its Bluetooth phone go (the disconnect then raises the busy beacon); the last session closing makes it
// connectable again so phones relink by themselves.
static void usb_link_switch(struct ble_npl_event *ev) {
    (void)ev;
    if (s_usb_sessions && s_conn_handle != BLE_HS_CONN_HANDLE_NONE) {
        ESP_LOGI(TAG, "USB host holds the board: letting the Bluetooth phone go");
        (void)ble_gap_terminate(s_conn_handle, BLE_ERR_REM_USER_CONN_TERM);
        return;
    }
    if ((uint32_t)(esp_timer_get_time() / 1000) < ADV_SETTLE_MS) return;   // adv_settle_done advertises
    advertise_for_state();
}

static void on_ble_sync(void) {
    if (ble_hs_util_ensure_addr(0) != 0) { ESP_LOGE(TAG, "no BLE address"); return; }
    if (ble_hs_id_infer_auto(0, &s_own_addr_type) != 0) s_own_addr_type = BLE_OWN_ADDR_PUBLIC;
    uint8_t addr[6] = {0};
    if (ble_hs_id_copy_addr(s_own_addr_type, addr, NULL) == 0)
        snprintf(s_name, sizeof(s_name), NAME_PREFIX "-%02X%02X", addr[1], addr[0]);
    s_addr_tail[0] = addr[1]; s_addr_tail[1] = addr[0];
    (void)ble_svc_gap_device_name_set(s_name);
    if (!s_link_ready) {   // once per Bluetooth start (a host reset can sync twice): they live on the host's event queue
        ble_npl_callout_init(&s_adv_settle, nimble_port_get_dflt_eventq(), adv_settle_done, NULL);
        ble_npl_callout_init(&s_beacon_tick, nimble_port_get_dflt_eventq(), beacon_tick, NULL);
        ble_npl_callout_init(&s_link_switch, nimble_port_get_dflt_eventq(), usb_link_switch, NULL);
        s_link_ready = true;
    }
    s_ble_synced = true;
    uint32_t up = (uint32_t)(esp_timer_get_time() / 1000);
    if (up < ADV_SETTLE_MS) ble_npl_callout_reset(&s_adv_settle, ble_npl_time_ms_to_ticks32(ADV_SETTLE_MS - up));
    else advertise_for_state();   // after a USB session or a host reset long after boot: advertise right away
    ble_npl_callout_reset(&s_beacon_tick, 0);   // first temperature reading now, before the first advertising
    ota_mark_valid_if_pending();   // Wi-Fi + BLE came up: keep this firmware (otherwise the next boot rolls back)
    if (s_boot_wd) esp_timer_stop(s_boot_wd);
    boot_stage(STAGE_READY);
}

static void on_ble_reset(int reason) { s_ble_synced = false; ESP_LOGW(TAG, "BLE host reset: %d", reason); }

static void ble_host_task(void *param) {
    (void)param;
    nimble_port_run();
    nimble_port_freertos_deinit();
}

/// Controller + host up with the service registered (boot, and when Bluetooth comes back after a USB session).
static esp_err_t ble_stack_init(void) {
    esp_err_t err = nimble_port_init();
    if (err != ESP_OK) return err;
    ble_svc_gap_init();
    ble_svc_gatt_init();
    ESP_ERROR_CHECK(ble_gatts_count_cfg(SERVICES));
    ESP_ERROR_CHECK(ble_gatts_add_svcs(SERVICES));
    ESP_ERROR_CHECK(ble_svc_gap_device_name_set(s_name));
    ble_hs_cfg.sync_cb = on_ble_sync;
    ble_hs_cfg.reset_cb = on_ble_reset;
    s_bt_up = true;
    return ESP_OK;
}

// ─── Bluetooth only when it's in use (1.6.6) ──────────────────────────────
// Bluetooth runs while a phone may link (no USB host) or the Bluetooth scan is the chosen mode. A USB host otherwise
// gets the board with the controller off: no Wi-Fi/Bluetooth coexistence, so every channel gets its full dwell. It
// comes back when the last USB session closes. While it's off there is no status beacon.
// Stopping runs here, never on the host task: nimble_port_stop() waits for that task to finish.
static TaskHandle_t s_btpwr_task;

static bool bt_wanted(void) { return !s_usb_sessions || s_role == ROLE_BT || s_bench_keep_bt; }
static void bt_power_kick(void) { if (s_btpwr_task) xTaskNotifyGive(s_btpwr_task); }

static void bt_power_task(void *arg) {
    (void)arg;
    for (;;) {
        ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(1000));
        if (bt_wanted() == s_bt_up || s_ota_active || s_rebooting) continue;
        if (s_bt_up) {
            if (s_bt_task) continue;   // the Bluetooth scan is still sending what it has
            for (int t = 0; s_conn_handle != BLE_HS_CONN_HANDLE_NONE && t < 100; t++) vTaskDelay(pdMS_TO_TICKS(20));
            xSemaphoreTake(s_cmd_lock, portMAX_DELAY);   // no callout reset can race the teardown
            bool off = !bt_wanted(), had_callouts = s_link_ready;
            if (off) { s_link_ready = false; s_ble_synced = false; s_bt_up = false; }
            xSemaphoreGive(s_cmd_lock);
            if (!off) continue;
            xSemaphoreTake(s_send_lock, portMAX_DELAY);   // a notify already in flight finishes; later ones see s_bt_up
            xSemaphoreGive(s_send_lock);
            nimble_port_stop();
            if (had_callouts) {   // our timers fire from esp_timer: one left armed would run into the freed event queue
                struct ble_npl_callout *co[] = { &s_beacon_tick, &s_link_switch, &s_adv_settle };
                for (size_t i = 0; i < sizeof(co) / sizeof(co[0]); i++) { ble_npl_callout_stop(co[i]); ble_npl_callout_deinit(co[i]); }
            }
            nimble_port_deinit();   // also disables and frees the controller
            s_conn_handle = BLE_HS_CONN_HANDLE_NONE;
            s_notify_enabled = false;
            ESP_LOGI(TAG, "Bluetooth off: a USB host has the board (controller %d, heap %lu)",
                     (int)esp_bt_controller_get_status(), (unsigned long)esp_get_free_heap_size());
        } else {
            esp_err_t err = ble_stack_init();
            if (err != ESP_OK) { ESP_LOGE(TAG, "Bluetooth didn't come back: %s", esp_err_to_name(err)); continue; }
            nimble_port_freertos_init(ble_host_task);
            ESP_LOGI(TAG, "Bluetooth on (heap %lu)", (unsigned long)esp_get_free_heap_size());
        }
    }
}

static void wifi_bring_up(void) {
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_wifi_set_storage(WIFI_STORAGE_RAM));
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_start());
    // Crank the radio to its hardware/regulatory ceiling. Wardriving's 2.4 GHz scan is ACTIVE — the board sends
    // probe requests — so a stronger TX makes distant APs hear the probe and reply, catching more of them per
    // sweep. Only 2.4 GHz probes use it: 5 GHz (DFS 52-144 included) is passive and never transmits. The driver
    // clamps the request to what the chip and country setting allow (units of 0.25 dBm; 84 is the API max). RX
    // sensitivity is fixed silicon on these ESP32 parts — there is no external PA/LNA to enable — so this is the
    // one knob that widens coverage. Set after esp_wifi_start(), which resets it to the default.
    if (esp_wifi_set_max_tx_power(84) == ESP_OK) {
        int8_t p = 0;   // 0.25 dBm units; print as whole + quarter dBm without %f (newlib-nano may drop it)
        if (esp_wifi_get_max_tx_power(&p) == ESP_OK)
            ESP_LOGI(TAG, "max TX power %d units (%d.%02d dBm)", p, p / 4, (p % 4) * 25);
    }
#if SOC_WIFI_SUPPORT_5G
    esp_err_t err = esp_wifi_set_band_mode(WIFI_BAND_MODE_AUTO);
    s_has_5g = (err == ESP_OK);
    if (!s_has_5g) ESP_LOGW(TAG, "dual-band mode unavailable (%s), 2.4 GHz only", esp_err_to_name(err));
#endif
    open_all_channels();
    build_supported_channels();
    plan_reset_to_all();
    ESP_LOGI(TAG, "%s: %u channels (%s)", CONFIG_IDF_TARGET, (unsigned)s_supported_n, s_has_5g ? "2.4 + 5 GHz" : "2.4 GHz");
}

// A reset that skips esp_restart() (the USB serial reset that esptool and USB hosts send, a watchdog core reset) leaves
// the Wi-Fi and Bluetooth MACs running from the last boot. When PHY calibration turns the modem clocks back on, the old
// Bluetooth MAC finishes a DMA into buffers the last boot owned, which this boot's heap has handed to someone else: the
// boot-time heap corruption behind the wd_health crash (bench 2026-10-24, heap poisoning: the same block every time,
// written during PHY calibration, before this boot's Bluetooth exists). Pulse every modem reset first, as esp_restart does.
static void modem_reset_stale(void) {
#if SOC_MODEM_CLOCK_SUPPORTED
    modem_clock_module_enable(PERIPH_WIFI_MODULE);
    modem_clock_module_enable(PERIPH_BT_MODULE);
    modem_syscon_ll_reset_all(&MODEM_SYSCON);
    modem_clock_module_disable(PERIPH_BT_MODULE);
    modem_clock_module_disable(PERIPH_WIFI_MODULE);
#endif
}

static long stack_free(TaskHandle_t t) { return t ? (long)uxTaskGetStackHighWaterMark(t) : -1; }

/// WD:HEALTH every 15 s while a host listens: memory, the least stack each task has had left (bytes), the link.
static void health_task(void *arg) {
    (void)arg;
    uint32_t last = 0, last_batt = 0;
    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(1000));
        heap_check("health 1 s");
        s_heap_min_seen = esp_get_minimum_free_heap_size();
        uint32_t now = (uint32_t)(esp_timer_get_time() / 1000);
        if (s_has_batt && now - last_batt >= 30000) { last_batt = now; battery_read(); }   // the I2C gauge only
#if COPROC
        coproc_tick(now);
#endif
        bool listening = (s_conn_handle != BLE_HS_CONN_HANDLE_NONE && s_notify_enabled) || s_usb_sessions;
        if (!listening || now - last < 15000) continue;
        last = now;
        long scan = stack_free(s_scan_task), bt = stack_free(s_bt_task), cap = stack_free(s_cap_task);
        long gps = stack_free(s_gps_task), usb = stack_free(s_usb_task);
        long self = (long)uxTaskGetStackHighWaterMark(NULL);   // NULL = this task
        const char *low = (scan >= 0 && scan < 768) ? "wd_scan" : (bt >= 0 && bt < 768) ? "wd_bt" :
                          (cap >= 0 && cap < 768) ? "wd_cap" : (gps >= 0 && gps < 768) ? "wd_gps" :
                          (usb >= 0 && usb < 768) ? "wd_usb" : "none";
        char batt[32] = "";
        if (s_has_batt && s_batt_pct >= 0) snprintf(batt, sizeof(batt), " batt=%d batt_mv=%d", s_batt_pct, s_batt_mv);   // none while unknown
        send_line("WD:HEALTH up=%lu heap=%lu heap_min=%lu largest=%lu stack_scan=%ld stack_bt=%ld stack_cap=%ld "
                  "stack_gps=%ld stack_usb=%ld stack_health=%ld low_stack=%s mtu=%u last=%s%s",
                  (unsigned long)(now / 1000), (unsigned long)esp_get_free_heap_size(),
                  (unsigned long)s_heap_min_seen,
                  (unsigned long)heap_caps_get_largest_free_block(MALLOC_CAP_8BIT), scan, bt, cap, gps, usb, self, low,
                  (unsigned)(s_bt_up && s_conn_handle != BLE_HS_CONN_HANDLE_NONE ? ble_att_mtu(s_conn_handle) : 0),
                  crumb_name(s_crumb), batt);
    }
}

void app_main(void) {
    modem_reset_stale();   // first, before Wi-Fi and Bluetooth start (see above)
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }
    s_send_lock = xSemaphoreCreateMutex();
    s_cmd_lock = xSemaphoreCreateMutex();
    boot_diag_begin();
    board_init();   // before GPS: a board's own bus (the gauge on 4/5) is off limits to the GPS probe
    wifi_bring_up();
    heap_check("boot: after Wi-Fi start");
    boot_stage(STAGE_WIFI);
#if SOC_TEMP_SENSOR_SUPPORTED
    temperature_sensor_config_t tcfg = TEMPERATURE_SENSOR_CONFIG_DEFAULT(-10, 80);
    if (temperature_sensor_install(&tcfg, &s_tsens) != ESP_OK || temperature_sensor_enable(s_tsens) != ESP_OK) s_tsens = NULL;
#endif

    heap_check("boot: after temperature sensor");
    ESP_ERROR_CHECK(ble_stack_init());
    heap_check("boot: after Bluetooth init");
    boot_stage(STAGE_BLUETOOTH);   // before the host task starts: on_ble_sync can record STAGE_READY right away
    nimble_port_freertos_init(ble_host_task);
    xTaskCreate(bt_power_task, "wd_btpwr", 4096, NULL, 4, &s_btpwr_task);
#if CONFIG_WARDRIVEESP_GPS_ENABLE
    // Optional GPS receiver: runs continuously, emitting WD:GPS when it has a fix. A board with nothing wired to
    // the UART simply never parses a sentence, never advertises gps, and costs only an idle blocked read.
    xTaskCreate(gps_task, "wd_gps", 6144, NULL, 4, &s_gps_task);
#endif
    usb_link_start();
    xTaskCreate(health_task, "wd_health", 6144, NULL, 3, NULL);
    heap_check("boot done");
    ESP_LOGI(TAG, "WardriveESP %s%s ready", FW_VERSION, FW_TAG);
}
