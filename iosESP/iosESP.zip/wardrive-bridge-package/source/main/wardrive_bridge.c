// wardrive_bridge.c — WarBLE Go single-board Wi-Fi wardriving bridge.
//
// A purpose-built, terminal-free firmware: flash it to any BLE-capable ESP32,
// power it on, and it immediately advertises the "iosESP" GATT service
// that WarBLE Go already knows how to drive. When the phone connects it starts
// hopping the 2.4 GHz channels, and every access point it hears is streamed back
// over BLE as a "WD:AP ..." line — exactly the wire format the app parses.
//
// No serial commands, no second board, no UART wiring, no pairing. One chip.
//
// This replaces the two-board GhostLink rig for this one job. It is NOT GhostESP;
// it implements only the slice of GhostESP's BLE-bridge protocol WarBLE Go needs,
// so the app runs against it unmodified.
//
// Build: idf.py set-target esp32c5   (or esp32c6 / esp32s3 / esp32 / esp32c3)
//        idf.py build flash monitor
//
// SPDX-License-Identifier: MIT

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_log.h"
#include "esp_timer.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "nvs_flash.h"

#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "host/ble_att.h"
#include "host/util/util.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"

#include "status_led.h"

static const char *TAG = "wardrive_bridge";

// ─── GhostLink "GB" protocol constants (must match AdControl/GhostLink.swift) ──
#define GB_MAGIC0      0x47  // 'G'
#define GB_MAGIC1      0x42  // 'B'
#define GB_VERSION     0x01
#define GB_HDR_LEN     12
#define GB_TYPE_CMD    1
#define GB_TYPE_ACK    2
#define GB_TYPE_DATA   3
#define GB_TYPE_END    4
#define GB_TYPE_ERR    5

#define BRIDGE_NAME    "iosESP"

// 128-bit UUIDs. NimBLE stores them little-endian (LSB first); the app's
// human-readable form is the byte-reverse of these arrays. They spell, big-endian,
// "GhostESPBridgeSv" (service) and "...XR/XT" / "...CTRL" for the characteristics.
//                           service  47686F73-7445-5350-4272-696467655376
static const ble_uuid128_t SVC_UUID  = BLE_UUID128_INIT(
    0x76,0x53,0x65,0x67,0x64,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47);
//                           RX write 0147686F-7374-4553-5042-726964675852
static const ble_uuid128_t RX_UUID   = BLE_UUID128_INIT(
    0x52,0x58,0x67,0x64,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x01);
//                           TX notify 0247686F-7374-4553-5042-726964675854
static const ble_uuid128_t TX_UUID   = BLE_UUID128_INIT(
    0x54,0x58,0x67,0x64,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x02);
//                           CTRL write 0347686F-7374-4553-5042-72694C525443
static const ble_uuid128_t CTRL_UUID = BLE_UUID128_INIT(
    0x43,0x54,0x52,0x4C,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x03);

// ─── Wardrive scan config ──────────────────────────────────────────────────
// 2.4 GHz channels 1-13 are supported on every ESP32 variant, so the same image
// is "flashable to any board". (5 GHz is intentionally left out — not all targets
// have it, and the phone's own radar already covers BLE.)
static const uint8_t SCAN_CHANNELS[] = {1,2,3,4,5,6,7,8,9,10,11,12,13};
#define SCAN_CHANNEL_COUNT  (sizeof(SCAN_CHANNELS)/sizeof(SCAN_CHANNELS[0]))
#define SCAN_MAX_AP         60      // cap records pulled per channel
#define STATUS_EVERY_CYCLES 1       // emit a WD:STATUS line every N full sweeps

// ─── BLE / stream state ────────────────────────────────────────────────────
static uint8_t  s_own_addr_type;
static uint16_t s_conn_handle   = BLE_HS_CONN_HANDLE_NONE;
static uint16_t s_tx_val_handle = 0;
static volatile bool s_notify_enabled = false;
static volatile bool s_streaming      = false;
static TaskHandle_t  s_scan_task      = NULL;
static volatile uint32_t s_active_cmd_id = 1;
static volatile uint32_t s_ap_count = 0;

static int bridge_gap_event(struct ble_gap_event *event, void *arg);
static void bridge_advertise(void);
static void stream_start(void);
static void stream_stop(void);

// ─── GB framing → BLE notify ───────────────────────────────────────────────
static size_t notify_cap(void) {
    // ATT notification overhead is 3 bytes; leave room for our 12-byte header.
    uint16_t mtu = (s_conn_handle != BLE_HS_CONN_HANDLE_NONE) ? ble_att_mtu(s_conn_handle) : 23;
    if (mtu < 23) mtu = 23;
    size_t cap = (size_t)mtu - 3;
    if (cap <= GB_HDR_LEN) return 1;
    return cap - GB_HDR_LEN;   // max payload bytes per frame
}

static void gb_send_frame(uint8_t type, uint8_t status, uint32_t cmd_id,
                          const uint8_t *payload, size_t plen) {
    if (s_conn_handle == BLE_HS_CONN_HANDLE_NONE || !s_notify_enabled || s_tx_val_handle == 0) {
        return;
    }
    if (plen > 0xffff) plen = 0xffff;
    size_t flen = GB_HDR_LEN + plen;
    uint8_t *frame = malloc(flen);
    if (!frame) return;
    frame[0] = GB_MAGIC0;
    frame[1] = GB_MAGIC1;
    frame[2] = GB_VERSION;
    frame[3] = type;
    frame[4] = status;
    frame[5] = 0;
    frame[6] = (uint8_t)(cmd_id & 0xff);
    frame[7] = (uint8_t)((cmd_id >> 8) & 0xff);
    frame[8] = (uint8_t)((cmd_id >> 16) & 0xff);
    frame[9] = (uint8_t)((cmd_id >> 24) & 0xff);
    frame[10] = (uint8_t)(plen & 0xff);
    frame[11] = (uint8_t)((plen >> 8) & 0xff);
    if (payload && plen) memcpy(frame + GB_HDR_LEN, payload, plen);

    struct os_mbuf *om = ble_hs_mbuf_from_flat(frame, (uint16_t)flen);
    free(frame);
    if (!om) return;
    // ble_gatts_notify_custom takes ownership of om (frees it even on error).
    (void)ble_gatts_notify_custom(s_conn_handle, s_tx_val_handle, om);
}

// Stream a text blob to the phone as one or more GB DATA frames. The app
// concatenates DATA payloads and splits on '\n', so splitting mid-line is safe.
static void gb_send_text(const char *buf, size_t len) {
    size_t cap = notify_cap();
    size_t off = 0;
    while (off < len) {
        size_t chunk = (len - off < cap) ? (len - off) : cap;
        gb_send_frame(GB_TYPE_DATA, 0, s_active_cmd_id, (const uint8_t *)(buf + off), chunk);
        off += chunk;
    }
}

static void wd_emit(const char *fmt, ...) {
    char line[256];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(line, sizeof(line), fmt, ap);
    va_end(ap);
    if (n < 0) return;
    if (n >= (int)sizeof(line)) n = (int)sizeof(line) - 1;
    if (n == 0 || line[n - 1] != '\n') {       // every WD: line is newline-terminated
        if (n < (int)sizeof(line) - 1) { line[n++] = '\n'; line[n] = '\0'; }
    }
    gb_send_text(line, (size_t)n);
}

// ─── WiGLE-style helpers (identical to GhostESP's wdstream) ────────────────
static const char *auth_token(wifi_auth_mode_t a) {
    switch (a) {
        case WIFI_AUTH_OPEN:            return "OPEN";
        case WIFI_AUTH_WEP:             return "WEP";
        case WIFI_AUTH_WPA_PSK:         return "WPA";
        case WIFI_AUTH_WPA2_PSK:
        case WIFI_AUTH_WPA_WPA2_PSK:
        case WIFI_AUTH_WPA2_ENTERPRISE: return "WPA2";
        case WIFI_AUTH_WPA3_PSK:
        case WIFI_AUTH_WPA2_WPA3_PSK:   return (a == WIFI_AUTH_WPA2_WPA3_PSK) ? "WPA2_WPA3" : "WPA3";
        default:                        return "UNKNOWN";
    }
}

static void hex_encode(const uint8_t *data, size_t len, char *out, size_t out_sz) {
    static const char hx[] = "0123456789abcdef";
    size_t max = (out_sz - 1) / 2;
    if (len > max) len = max;
    for (size_t i = 0; i < len; i++) {
        out[i * 2]     = hx[(data[i] >> 4) & 0xF];
        out[i * 2 + 1] = hx[data[i] & 0xF];
    }
    out[len * 2] = '\0';
}

static void emit_ap(const wifi_ap_record_t *ap) {
    size_t ssid_len = strnlen((const char *)ap->ssid, 32);
    char ssid_hex[65];
    hex_encode(ap->ssid, ssid_len, ssid_hex, sizeof(ssid_hex));
    wd_emit("WD:AP ts=%lu bssid=%02X:%02X:%02X:%02X:%02X:%02X ssid_hex=%s rssi=%d ch=%u auth=%s hidden=%u",
            (unsigned long)(esp_timer_get_time() / 1000),
            ap->bssid[0], ap->bssid[1], ap->bssid[2], ap->bssid[3], ap->bssid[4], ap->bssid[5],
            ssid_hex, ap->rssi, (unsigned)ap->primary, auth_token(ap->authmode),
            ssid_len == 0 ? 1u : 0u);
    s_ap_count++;
}

static void scan_channel(uint8_t ch) {
    // Leave scan_time at 0 (= driver default). When Bluetooth/coexistence is
    // enabled, esp_wifi insists on the default active-scan dwell and warns loudly
    // on every scan otherwise; letting the coex arbiter own the timing both
    // silences that and lets it interleave Wi-Fi/BLE cleanly.
    wifi_scan_config_t cfg = {
        .ssid = NULL, .bssid = NULL, .channel = ch, .show_hidden = true,
        .scan_type = WIFI_SCAN_TYPE_ACTIVE,
    };
    if (esp_wifi_scan_start(&cfg, true) != ESP_OK) return;   // blocks until the dwell elapses
    uint16_t num = 0;
    if (esp_wifi_scan_get_ap_num(&num) != ESP_OK || num == 0) return;
    if (num > SCAN_MAX_AP) num = SCAN_MAX_AP;
    wifi_ap_record_t *recs = calloc(num, sizeof(wifi_ap_record_t));
    if (!recs) return;
    uint16_t got = num;
    if (esp_wifi_scan_get_ap_records(&got, recs) == ESP_OK) {
        for (uint16_t i = 0; i < got && s_streaming; i++) emit_ap(&recs[i]);
    }
    free(recs);
}

static void scan_task(void *arg) {
    (void)arg;
    s_ap_count = 0;
    wd_emit("WD:BEGIN type=wifi interval=0 channel=auto");
    uint32_t cycles = 0;
    while (s_streaming && s_conn_handle != BLE_HS_CONN_HANDLE_NONE) {
        for (size_t i = 0; i < SCAN_CHANNEL_COUNT && s_streaming; i++) {
            scan_channel(SCAN_CHANNELS[i]);
            vTaskDelay(pdMS_TO_TICKS(5));
        }
        if (++cycles % STATUS_EVERY_CYCLES == 0) {
            wd_emit("WD:STATUS aps=%lu scans=%lu", (unsigned long)s_ap_count, (unsigned long)cycles);
        }
    }
    wd_emit("WD:END reason=stop");
    s_streaming = false;
    s_scan_task = NULL;
    vTaskDelete(NULL);
}

static void stream_start(void) {
    if (s_streaming || s_conn_handle == BLE_HS_CONN_HANDLE_NONE) return;
    s_streaming = true;
    if (xTaskCreate(scan_task, "wd_scan", 6144, NULL, 5, &s_scan_task) != pdPASS) {
        s_streaming = false;
        s_scan_task = NULL;
        ESP_LOGE(TAG, "scan task create failed");
    } else {
        status_led_set(STATUS_LED_STREAMING);
        ESP_LOGI(TAG, "wardrive stream started");
    }
}

static void stream_stop(void) {
    s_streaming = false;   // scan_task observes this, emits WD:END and exits
    (void)esp_wifi_scan_stop();
    if (s_conn_handle != BLE_HS_CONN_HANDLE_NONE) status_led_set(STATUS_LED_ADVERTISING);
}

// ─── Inbound command handling (RX + CTRL writes) ───────────────────────────
static void handle_command(const uint8_t *data, uint16_t len) {
    // The frame may be a raw "stop" (CTRL) or a GB CMD frame carrying a command
    // string. Pull out the command text either way.
    const char *cmd = (const char *)data;
    uint16_t cmd_len = len;
    if (len >= GB_HDR_LEN && data[0] == GB_MAGIC0 && data[1] == GB_MAGIC1) {
        uint16_t plen = (uint16_t)(data[10] | (data[11] << 8));
        if ((size_t)GB_HDR_LEN + plen <= len) {
            s_active_cmd_id = (uint32_t)data[6] | ((uint32_t)data[7] << 8) |
                              ((uint32_t)data[8] << 16) | ((uint32_t)data[9] << 24);
            if (data[3] == GB_TYPE_CMD) {
                cmd = (const char *)(data + GB_HDR_LEN);
                cmd_len = plen;
                gb_send_frame(GB_TYPE_ACK, 0, s_active_cmd_id, NULL, 0);
            }
        }
    }
    char buf[64];
    size_t n = cmd_len < sizeof(buf) - 1 ? cmd_len : sizeof(buf) - 1;
    memcpy(buf, cmd, n);
    buf[n] = '\0';
    ESP_LOGI(TAG, "cmd: '%s'", buf);
    if (strstr(buf, "stop")) {
        stream_stop();
    } else {
        // Any "start"-style command (the app sends "wdstream start -wifi") just
        // turns the stream on. No terminal, no arguments to get right.
        stream_start();
    }
}

static int gatt_rx_write(uint16_t conn, uint16_t attr, struct ble_gatt_access_ctxt *ctxt, void *arg) {
    (void)conn; (void)attr; (void)arg;
    if (ctxt->op != BLE_GATT_ACCESS_OP_WRITE_CHR) return BLE_ATT_ERR_UNLIKELY;
    uint8_t buf[256];
    uint16_t out = 0;
    if (ble_hs_mbuf_to_flat(ctxt->om, buf, sizeof(buf), &out) != 0) return BLE_ATT_ERR_UNLIKELY;
    handle_command(buf, out);
    return 0;
}

static int gatt_tx_access(uint16_t conn, uint16_t attr, struct ble_gatt_access_ctxt *ctxt, void *arg) {
    (void)conn; (void)attr; (void)ctxt; (void)arg;
    return 0;   // notify-only; nothing to read
}

static const struct ble_gatt_chr_def CHRS[] = {
    { .uuid = &RX_UUID.u,   .access_cb = gatt_rx_write,  .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP },
    { .uuid = &TX_UUID.u,   .access_cb = gatt_tx_access, .flags = BLE_GATT_CHR_F_NOTIFY, .val_handle = &s_tx_val_handle },
    { .uuid = &CTRL_UUID.u, .access_cb = gatt_rx_write,  .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP },
    { 0 },
};
static const struct ble_gatt_svc_def SVCS[] = {
    { .type = BLE_GATT_SVC_TYPE_PRIMARY, .uuid = &SVC_UUID.u, .characteristics = CHRS },
    { 0 },
};

// ─── GAP ───────────────────────────────────────────────────────────────────
static void bridge_advertise(void) {
    struct ble_hs_adv_fields fields = {0};
    fields.flags = BLE_HS_ADV_F_DISC_GEN | BLE_HS_ADV_F_BREDR_UNSUP;
    fields.uuids128 = (ble_uuid128_t *)&SVC_UUID;
    fields.num_uuids128 = 1;
    fields.uuids128_is_complete = 1;
    if (ble_gap_adv_set_fields(&fields) != 0) {
        ESP_LOGE(TAG, "adv_set_fields failed");
        return;
    }
    // The 128-bit UUID fills the adv packet; the name rides in the scan response.
    struct ble_hs_adv_fields rsp = {0};
    rsp.name = (const uint8_t *)BRIDGE_NAME;
    rsp.name_len = strlen(BRIDGE_NAME);
    rsp.name_is_complete = 1;
    (void)ble_gap_adv_rsp_set_fields(&rsp);

    struct ble_gap_adv_params params = {0};
    params.conn_mode = BLE_GAP_CONN_MODE_UND;
    params.disc_mode = BLE_GAP_DISC_MODE_GEN;
    int rc = ble_gap_adv_start(s_own_addr_type, NULL, BLE_HS_FOREVER, &params, bridge_gap_event, NULL);
    if (rc != 0) {
        ESP_LOGE(TAG, "adv_start failed: %d", rc);
    } else {
        status_led_set(STATUS_LED_ADVERTISING);
        ESP_LOGI(TAG, "advertising as '%s'", BRIDGE_NAME);
    }
}

static int bridge_gap_event(struct ble_gap_event *event, void *arg) {
    (void)arg;
    switch (event->type) {
    case BLE_GAP_EVENT_CONNECT:
        if (event->connect.status == 0) {
            s_conn_handle = event->connect.conn_handle;
            s_notify_enabled = false;
            ESP_LOGI(TAG, "connected");
        } else {
            bridge_advertise();
        }
        return 0;

    case BLE_GAP_EVENT_DISCONNECT:
        ESP_LOGI(TAG, "disconnected (reason %d)", event->disconnect.reason);
        s_conn_handle = BLE_HS_CONN_HANDLE_NONE;
        s_notify_enabled = false;
        stream_stop();
        bridge_advertise();
        return 0;

    case BLE_GAP_EVENT_SUBSCRIBE:
        if (event->subscribe.attr_handle == s_tx_val_handle) {
            s_notify_enabled = event->subscribe.cur_notify;
            ESP_LOGI(TAG, "notify %s", s_notify_enabled ? "on" : "off");
            // Auto-start the moment the phone subscribes — the app sends its
            // start command right after, but this makes it work regardless.
            if (s_notify_enabled) stream_start();
            else stream_stop();
        }
        return 0;

    case BLE_GAP_EVENT_MTU:
        ESP_LOGI(TAG, "MTU = %u", event->mtu.value);
        return 0;

    default:
        return 0;
    }
}

// ─── NimBLE host plumbing ──────────────────────────────────────────────────
static void on_sync(void) {
    if (ble_hs_util_ensure_addr(0) != 0) { ESP_LOGE(TAG, "no BLE address"); return; }
    if (ble_hs_id_infer_auto(0, &s_own_addr_type) != 0) s_own_addr_type = BLE_OWN_ADDR_PUBLIC;
    bridge_advertise();
}

static void on_reset(int reason) { ESP_LOGW(TAG, "BLE host reset: %d", reason); }

static void host_task(void *param) {
    (void)param;
    nimble_port_run();              // returns only on nimble_port_stop()
    nimble_port_freertos_deinit();
}

static void wifi_boot(void) {
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_wifi_set_storage(WIFI_STORAGE_RAM));
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_start());   // STA up but never associates — we only scan
}

void app_main(void) {
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }

    status_led_init();   // off until BLE comes up

    wifi_boot();   // Wi-Fi + BLE share the radio via ESP-IDF coexistence

    ESP_ERROR_CHECK(nimble_port_init());
    ble_svc_gap_init();
    ble_svc_gatt_init();
    ESP_ERROR_CHECK(ble_gatts_count_cfg(SVCS));
    ESP_ERROR_CHECK(ble_gatts_add_svcs(SVCS));
    ESP_ERROR_CHECK(ble_svc_gap_device_name_set(BRIDGE_NAME));

    ble_hs_cfg.sync_cb = on_sync;
    ble_hs_cfg.reset_cb = on_reset;

    nimble_port_freertos_init(host_task);
    ESP_LOGI(TAG, "WarBLE wardrive bridge up — waiting for the phone");
}
