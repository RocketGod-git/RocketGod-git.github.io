// SPDX-License-Identifier: MIT
#pragma once

typedef enum {
    STATUS_LED_IDLE = 0,     // off
    STATUS_LED_ADVERTISING,  // slow blue blink
    STATUS_LED_STREAMING,    // solid green
} status_led_state_t;

void status_led_init(void);
void status_led_set(status_led_state_t state);
