// SPDX-License-Identifier: MIT
#include "status_led.h"
#include "sdkconfig.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"

static const char *TAG = "status_led";
static volatile status_led_state_t s_state = STATUS_LED_IDLE;

#if CONFIG_IOSESP_LED_RGB
#include "led_strip.h"
static led_strip_handle_t s_strip;

static void led_hw_init(void) {
    led_strip_config_t strip_cfg = {
        .strip_gpio_num = CONFIG_IOSESP_LED_GPIO,
        .max_leds = 1,
        .led_pixel_format = LED_PIXEL_FORMAT_GRB,
        .led_model = LED_MODEL_WS2812,
        .flags.invert_out = false,
    };
    led_strip_rmt_config_t rmt_cfg = {
        .clk_src = RMT_CLK_SRC_DEFAULT,
        .resolution_hz = 10 * 1000 * 1000,
        .flags.with_dma = false,
    };
    if (led_strip_new_rmt_device(&strip_cfg, &rmt_cfg, &s_strip) != ESP_OK) {
        s_strip = NULL;
        ESP_LOGW(TAG, "WS2812 init failed on GPIO %d", CONFIG_IOSESP_LED_GPIO);
    }
}

static void led_hw_set(uint8_t r, uint8_t g, uint8_t b) {
    if (!s_strip) return;
    if (r == 0 && g == 0 && b == 0) { led_strip_clear(s_strip); return; }
    led_strip_set_pixel(s_strip, 0, r, g, b);
    led_strip_refresh(s_strip);
}

#elif CONFIG_IOSESP_LED_SIMPLE
#include "driver/gpio.h"
static void led_hw_init(void) {
    gpio_reset_pin(CONFIG_IOSESP_LED_GPIO);
    gpio_set_direction(CONFIG_IOSESP_LED_GPIO, GPIO_MODE_OUTPUT);
}
static void led_hw_set(uint8_t r, uint8_t g, uint8_t b) {
    int on = (r || g || b) ? 1 : 0;
#if CONFIG_IOSESP_LED_ACTIVE_LOW
    on = !on;
#endif
    gpio_set_level(CONFIG_IOSESP_LED_GPIO, on);
}

#else
static void led_hw_init(void) {}
static void led_hw_set(uint8_t r, uint8_t g, uint8_t b) { (void)r; (void)g; (void)b; }
#endif

#define LEVEL 24

static void led_task(void *arg) {
    (void)arg;
    for (;;) {
        switch (s_state) {
        case STATUS_LED_ADVERTISING:
            led_hw_set(0, 0, LEVEL);
            vTaskDelay(pdMS_TO_TICKS(800));
            led_hw_set(0, 0, 0);
            vTaskDelay(pdMS_TO_TICKS(800));
            break;
        case STATUS_LED_STREAMING:
            led_hw_set(0, LEVEL, 0);
            vTaskDelay(pdMS_TO_TICKS(250));
            break;
        case STATUS_LED_IDLE:
        default:
            led_hw_set(0, 0, 0);
            vTaskDelay(pdMS_TO_TICKS(250));
            break;
        }
    }
}

void status_led_init(void) {
    led_hw_init();
    led_hw_set(0, 0, 0);
    xTaskCreate(led_task, "status_led", 2560, NULL, 3, NULL);
}

void status_led_set(status_led_state_t state) {
    s_state = state;
}
