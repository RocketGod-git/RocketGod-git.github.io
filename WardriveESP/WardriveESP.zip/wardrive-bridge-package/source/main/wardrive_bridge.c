// WardriveESP — Wi-Fi and Bluetooth scanner for Wardrive Go over BLE and USB. Protocol: PROTOCOL.md
// SPDX-License-Identifier: MIT

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include "sdkconfig.h"
#include "soc/soc_caps.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/stream_buffer.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "esp_ota_ops.h"
#include "esp_system.h"

#include "esp_log.h"
#include "esp_timer.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "nvs_flash.h"
#include "esp_chip_info.h"
#include "esp_flash.h"
#include "esp_mac.h"
#include "esp_attr.h"
#include "esp_heap_caps.h"
#include "esp_private/panic_internal.h"

#include "driver/uart.h"
#include "driver/uart_vfs.h"
#if SOC_USB_SERIAL_JTAG_SUPPORTED
#include "driver/usb_serial_jtag.h"
#include "driver/usb_serial_jtag_vfs.h"
#endif

#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "host/ble_att.h"
#include "host/util/util.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"

#include "status_led.h"

static const char *TAG = "WardriveESP";

#define FW_VERSION     "1.6.2"
#define NAME_PREFIX    "WardriveESP"

// USB transports (PROTOCOL.md "USB"): USB-Serial-JTAG on chips with native USB, UART0 for USB-UART bridge boards.
#define USB_JTAG_LINK  SOC_USB_SERIAL_JTAG_SUPPORTED
#if CONFIG_ESP_CONSOLE_UART && CONFIG_ESP_CONSOLE_UART_NUM == 0 && \
    !(defined(CONFIG_WARDRIVEESP_GPS_UART_NUM) && CONFIG_WARDRIVEESP_GPS_UART_NUM == 0)
#define UART_LINK      1
#define LINK_UART      UART_NUM_0
#else
#define UART_LINK      0
#endif

enum {
    FR_MAGIC_0 = 0x47, FR_MAGIC_1 = 0x42, FR_VERSION = 0x01, FR_HEADER = 12,
    FR_CMD = 1, FR_ACK = 2, FR_DATA = 3, FR_END = 4, FR_ERR = 5,
};

// What the board was doing, kept current in the hot paths and saved by the panic handler so the next boot can
// report it in WD:CRASH.
enum { CR_IDLE = 0, CR_SCAN, CR_RESULTS, CR_SEND_AP, CR_BT, CR_CAP, CR_OTA, CR_CMD, CR_GPS };
static volatile uint8_t  s_crumb = CR_IDLE;
static volatile uint8_t  s_crumb_ch = 0;
static volatile uint32_t s_heap_min_seen = 0;

#define CRASH_MAGIC 0x10E5C0DEu
typedef struct {
    uint32_t magic;
    uint32_t up_ms;
    uint32_t pc;
    uint32_t heap_min;
    uint8_t  crumb, ch, kind, core;
    char     task[16];
    char     reason[56];
} crash_rec_t;
enum { CK_PANIC = 1, CK_STACK = 2 };
static RTC_NOINIT_ATTR crash_rec_t s_crash;

static void IRAM_ATTR crash_copy(char *dst, size_t cap, const char *src) {
    size_t i = 0;
    if (src) for (; i + 1 < cap && src[i]; i++) dst[i] = src[i];
    dst[i] = '\0';
}

static void IRAM_ATTR crash_fill(uint8_t kind, const char *task, const char *reason, uint32_t pc, int core) {
    if (s_crash.magic == CRASH_MAGIC && s_crash.kind == CK_STACK) return;   // keep the more specific record
    s_crash.up_ms = (uint32_t)(esp_timer_get_time() / 1000);
    s_crash.pc = pc;
    s_crash.heap_min = s_heap_min_seen;
    s_crash.crumb = s_crumb;
    s_crash.ch = s_crumb_ch;
    s_crash.kind = kind;
    s_crash.core = (uint8_t)core;
    crash_copy(s_crash.task, sizeof(s_crash.task), task);
    crash_copy(s_crash.reason, sizeof(s_crash.reason), reason);
    s_crash.magic = CRASH_MAGIC;
}

void vApplicationStackOverflowHook(TaskHandle_t task, char *name) {
    (void)task;
    crash_fill(CK_STACK, name, "stack overflow", 0, 0);
    static char msg[48] = "Stack overflow in task ";   // static: this stack is already exhausted
    crash_copy(msg + 23, sizeof(msg) - 23, name ? name : "?");
    esp_system_abort(msg);
}

extern void __real_esp_panic_handler(panic_info_t *info);
void IRAM_ATTR __wrap_esp_panic_handler(panic_info_t *info) {
    TaskHandle_t cur = xTaskGetCurrentTaskHandle();
    crash_fill(CK_PANIC, cur ? pcTaskGetName(cur) : "?", info ? info->reason : NULL,
               info ? (uint32_t)(uintptr_t)info->addr : 0, info ? info->core : 0);
    __real_esp_panic_handler(info);
}

// UUIDs are least-significant byte first.
static const ble_uuid128_t SVC_UUID  = BLE_UUID128_INIT(
    0x76,0x53,0x65,0x67,0x64,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47);
static const ble_uuid128_t RX_UUID   = BLE_UUID128_INIT(
    0x52,0x58,0x67,0x64,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x01);
static const ble_uuid128_t TX_UUID   = BLE_UUID128_INIT(
    0x54,0x58,0x67,0x64,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x02);
static const ble_uuid128_t CTRL_UUID = BLE_UUID128_INIT(
    0x43,0x54,0x52,0x4C,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x03);
static const ble_uuid128_t OTA_UUID  = BLE_UUID128_INIT(
    0x44,0x41,0x54,0x4F,0x69,0x72,0x42,0x50,0x53,0x45,0x74,0x73,0x6F,0x68,0x47,0x04);

#define OTA_BUF_BYTES   (24 * 1024)
#define OTA_WINDOW      (12 * 1024)   // max bytes the phone sends ahead of the last ack
#define OTA_ACK_STEP    (4 * 1024)

static StreamBufferHandle_t s_ota_buf;
static TaskHandle_t s_ota_task;
static esp_ota_handle_t s_ota_handle;
static const esp_partition_t *s_ota_part;
static volatile bool s_ota_active = false;
static volatile bool s_ota_end_req = false;
static volatile bool s_ota_abort_req = false;
static volatile uint32_t s_ota_size = 0;

// Output sinks: the BLE phone and one session per USB port. Every line goes to every linked host.
enum { SINK_BLE = 1, SINK_USB = 2, SINK_UART = 4, SINK_ALL = 7 };
static volatile uint8_t s_usb_sessions = 0;      // SINK_USB / SINK_UART ports with an open session
static volatile uint8_t s_ota_src = SINK_BLE;    // host running the update; gets the WD:OTA lines
static volatile uint8_t s_cmd_src = SINK_BLE;    // host whose command is running (under s_cmd_lock)

// Every channel the radio can tune. 5 GHz is always a passive scan / promiscuous RX here.
static const uint8_t CH_ORDER[] = { 1, 6, 11, 36, 40, 44, 48, 149, 153, 157, 161,
                                    52, 56, 60, 64, 100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144,
                                    165, 169, 173, 177,
                                    2, 3, 4, 5, 7, 8, 9, 10, 12, 13, 14 };
#define CH_ORDER_N       (sizeof(CH_ORDER) / sizeof(CH_ORDER[0]))
#define MAX_CHANNELS     CH_ORDER_N
#define PASSIVE_DWELL_MS 120
#define MAX_AP_PER_SCAN  60
#define CMD_MAX          240

static uint8_t  s_supported[MAX_CHANNELS];
static size_t   s_supported_n = 0;
static bool     s_has_5g = false;

static uint8_t  s_plan[MAX_CHANNELS];
static size_t   s_plan_n = 0;
static portMUX_TYPE s_plan_lock = portMUX_INITIALIZER_UNLOCKED;

static char     s_name[24] = NAME_PREFIX;
static uint8_t  s_own_addr_type;
static uint16_t s_conn_handle   = BLE_HS_CONN_HANDLE_NONE;
static uint16_t s_tx_val_handle = 0;
static volatile bool s_notify_enabled = false;
static volatile bool s_streaming      = false;
static TaskHandle_t  s_scan_task      = NULL;
static volatile uint32_t s_reply_id   = 1;
static volatile uint32_t s_ap_count   = 0;
static volatile uint32_t s_sweeps     = 0;
static volatile uint32_t s_last_aps   = 0;

static bool host_linked(void) { return s_conn_handle != BLE_HS_CONN_HANDLE_NONE || s_usb_sessions; }

// Scan role: the board does exactly one of these at a time. A role switch lets any running task finish first,
// then the task that ends starts the new role (see set_role / stream_start). Reset to Wi-Fi when a host connects
// or disconnects with no other host linked. ROLE_CAP (1.5+) is passive 802.11 promiscuous capture — handshakes, PMKIDs, client sightings.
typedef enum { ROLE_WIFI = 0, ROLE_BT, ROLE_CAP } scan_role_t;
static volatile scan_role_t s_role = ROLE_WIFI;

// Bluetooth role: the board scans BLE instead of Wi-Fi.
#define BT_WINDOW_MS  10000
#define BT_QUEUE_LEN  48

typedef struct {
    uint8_t  mac[6];      // most significant byte first
    uint8_t  addr_type;
    int8_t   rssi;
    uint8_t  conn;
    uint8_t  name_len;
    char     name[29];
    uint8_t  has_company;
    uint16_t company;
} bt_rec_t;

static QueueHandle_t s_bt_queue;
static TaskHandle_t  s_bt_task          = NULL;
static volatile bool s_bt_running       = false;
static volatile bool s_bt_window_done   = false;
static volatile bool s_switch_pending   = false;
static volatile uint32_t s_bt_count     = 0;
static volatile uint32_t s_bt_windows   = 0;
static volatile uint32_t s_bt_last      = 0;
static volatile uint32_t s_bt_dropped   = 0;

// GPS role (PROTOCOL.md "GPS", firmware 1.4+): an optional UART NMEA receiver. The task runs continuously and
// emits WD:GPS whenever it parses a valid fix; the phone uses it as a location source when its own fix is stale
// or absent. `s_gps_present` is set only once a valid fix is parsed (runtime presence-detection, like s_has_5g),
// so a board without a GPS wired up never claims the capability. It's read by WD:CAPS whether or not GPS is
// compiled in (always 0 then), so it lives outside the build guard; the fix fields only exist when GPS is on.
static volatile bool s_gps_present = false;

static int  on_gap_event(struct ble_gap_event *event, void *arg);
static void start_advertising(void);
static void stream_start(void);

static bool is_5ghz(uint8_t ch) { return ch > 14; }
static bool is_dfs(uint8_t ch) { return (ch >= 52 && ch <= 64) || (ch >= 100 && ch <= 144); }

static bool channel_supported(uint8_t ch) {
    for (size_t i = 0; i < s_supported_n; i++) if (s_supported[i] == ch) return true;
    return false;
}

// Open the radio to every channel it can tune (2.4 GHz 1-14, all 5 GHz) so the scan list isn't trimmed.
static void open_all_channels(void) {
    wifi_country_t all = {
        .cc = "01",
        .schan = 1,
        .nchan = 14,
        .policy = WIFI_COUNTRY_POLICY_MANUAL,
    };
#if SOC_WIFI_SUPPORT_5G
    all.wifi_5g_channel_mask = 0xFFFFFFFFu;
#endif
    esp_err_t err = esp_wifi_set_country(&all);
    if (err != ESP_OK) ESP_LOGW(TAG, "set_country: %s", esp_err_to_name(err));
}

static void build_supported_channels(void) {
    s_supported_n = 0;
    for (size_t i = 0; i < CH_ORDER_N; i++) {
        uint8_t ch = CH_ORDER[i];
        if (is_5ghz(ch) && !s_has_5g) continue;
        s_supported[s_supported_n++] = ch;
    }
}

static void plan_reset_to_all(void) {
    portENTER_CRITICAL(&s_plan_lock);
    memcpy(s_plan, s_supported, s_supported_n);
    s_plan_n = s_supported_n;
    portEXIT_CRITICAL(&s_plan_lock);
}

static size_t plan_copy(uint8_t *out) {
    portENTER_CRITICAL(&s_plan_lock);
    size_t n = s_plan_n;
    memcpy(out, s_plan, n);
    portEXIT_CRITICAL(&s_plan_lock);
    return n;
}

static size_t parse_channel_list(const char *s, uint8_t *out) {
    size_t n = 0;
    while (*s && n < MAX_CHANNELS) {
        while (*s == ',' || *s == ' ') s++;
        if (*s < '0' || *s > '9') break;
        long v = strtol(s, (char **)&s, 10);
        if (v <= 0 || v > 255 || !channel_supported((uint8_t)v)) continue;
        bool dup = false;
        for (size_t i = 0; i < n; i++) if (out[i] == (uint8_t)v) dup = true;
        if (!dup) out[n++] = (uint8_t)v;
    }
    return n;
}

static int format_channel_list(char *buf, int len, int cap, const uint8_t *ch, size_t n) {
    for (size_t i = 0; i < n && len < cap - 5; i++)
        len += snprintf(buf + len, cap - len, i ? ",%u" : "%u", (unsigned)ch[i]);
    return len;
}

static size_t max_payload_per_notify(void) {
    uint16_t mtu = (s_conn_handle != BLE_HS_CONN_HANDLE_NONE) ? ble_att_mtu(s_conn_handle) : 23;
    if (mtu < 23) mtu = 23;
    size_t room = (size_t)mtu - 3;
    return room > FR_HEADER ? room - FR_HEADER : 1;
}

// Serializes each line to every host, so one line's BLE frames and USB bytes are never interleaved with another's
// (scan, GPS, health and command tasks all send).
static SemaphoreHandle_t s_send_lock;

// Not put_le32: NimBLE's os/endian.h defines that name.
static void frame_put_u32(uint8_t *p, uint32_t v) { p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24; }

// Buffers shared by every sender; only touched while s_send_lock is held. Kept off the task stacks.
static uint8_t s_frame[FR_HEADER + 256];
static char    s_line[256];

static void send_frame(uint8_t type, const uint8_t *payload, size_t len) {
    if (s_conn_handle == BLE_HS_CONN_HANDLE_NONE || !s_notify_enabled || s_tx_val_handle == 0) return;
    uint8_t *frame = s_frame;
    if (len > sizeof(s_frame) - FR_HEADER) len = sizeof(s_frame) - FR_HEADER;
    memset(frame, 0, FR_HEADER);
    frame[0] = FR_MAGIC_0; frame[1] = FR_MAGIC_1; frame[2] = FR_VERSION; frame[3] = type;
    frame_put_u32(frame + 6, s_reply_id);
    frame[10] = len & 0xff; frame[11] = (len >> 8) & 0xff;
    if (len) memcpy(frame + FR_HEADER, payload, len);
    struct os_mbuf *om = ble_hs_mbuf_from_flat(frame, (uint16_t)(FR_HEADER + len));
    if (om) (void)ble_gatts_notify_custom(s_conn_handle, s_tx_val_handle, om);
}

static void send_ack(void) {
    if (s_conn_handle == BLE_HS_CONN_HANDLE_NONE || !s_notify_enabled || s_tx_val_handle == 0) return;
    uint8_t frame[FR_HEADER] = { FR_MAGIC_0, FR_MAGIC_1, FR_VERSION, FR_ACK };
    frame_put_u32(frame + 6, s_reply_id);
    struct os_mbuf *om = ble_hs_mbuf_from_flat(frame, FR_HEADER);
    if (om) (void)ble_gatts_notify_custom(s_conn_handle, s_tx_val_handle, om);
}

static void send_chunks_locked(const char *buf, size_t n) {
    size_t step = max_payload_per_notify();
    for (size_t off = 0; off < n; off += step) {
        size_t chunk = (n - off < step) ? n - off : step;
        send_frame(FR_DATA, (const uint8_t *)buf + off, chunk);
    }
}

static void usb_emit_locked(uint8_t sinks, const char *buf, size_t n);

// The one output path: a built line (newline included) to the selected hosts. BLE gets MTU-sized DATA frames,
// USB sessions get the raw line.
static void emit_locked(uint8_t sinks, const char *buf, size_t n) {
    if (sinks & SINK_BLE) send_chunks_locked(buf, n);
    if (sinks & s_usb_sessions) usb_emit_locked(sinks, buf, n);
}

// For lines longer than s_line (the capture role's WD:HS).
static void send_chunks(const char *buf, size_t n) {
    if (!s_send_lock) return;
    xSemaphoreTake(s_send_lock, portMAX_DELAY);
    emit_locked(SINK_ALL, buf, n);
    xSemaphoreGive(s_send_lock);
}

static void send_vline(uint8_t sinks, const char *fmt, va_list ap) {
    if (!s_send_lock) return;
    xSemaphoreTake(s_send_lock, portMAX_DELAY);
    int n = vsnprintf(s_line, sizeof(s_line) - 1, fmt, ap);
    if (n > 0) {
        if (n > (int)sizeof(s_line) - 2) n = (int)sizeof(s_line) - 2;
        s_line[n++] = '\n';
        emit_locked(sinks, s_line, (size_t)n);
    }
    xSemaphoreGive(s_send_lock);
}

static void send_line_to(uint8_t sinks, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    send_vline(sinks, fmt, ap);
    va_end(ap);
}

static void send_line(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    send_vline(SINK_ALL, fmt, ap);
    va_end(ap);
}

struct auth_name { wifi_auth_mode_t mode; const char *token; };
static const struct auth_name AUTH_NAMES[] = {
    { WIFI_AUTH_OPEN,            "OPEN" },
    { WIFI_AUTH_WEP,             "WEP" },
    { WIFI_AUTH_WPA_PSK,         "WPA" },
    { WIFI_AUTH_WPA2_PSK,        "WPA2" },
    { WIFI_AUTH_WPA_WPA2_PSK,    "WPA2" },
    { WIFI_AUTH_WPA2_ENTERPRISE, "WPA2" },
    { WIFI_AUTH_WPA3_PSK,        "WPA3" },
    { WIFI_AUTH_WPA2_WPA3_PSK,   "WPA2_WPA3" },
};

static const char *auth_name(wifi_auth_mode_t mode) {
    for (size_t i = 0; i < sizeof(AUTH_NAMES) / sizeof(AUTH_NAMES[0]); i++)
        if (AUTH_NAMES[i].mode == mode) return AUTH_NAMES[i].token;
    return "UNKNOWN";
}

static char lower_hex_digit(uint8_t v) { return (char)(v < 10 ? '0' + v : 'a' + (v - 10)); }

static void send_ap_line(const wifi_ap_record_t *ap) {
    size_t ssid_len = 0;
    while (ssid_len < sizeof(ap->ssid) && ap->ssid[ssid_len]) ssid_len++;
    char ssid_hex[2 * sizeof(ap->ssid) + 1];
    for (size_t i = 0; i < ssid_len; i++) {
        ssid_hex[2 * i]     = lower_hex_digit(ap->ssid[i] >> 4);
        ssid_hex[2 * i + 1] = lower_hex_digit(ap->ssid[i] & 0x0F);
    }
    ssid_hex[2 * ssid_len] = '\0';
    const uint8_t *b = ap->bssid;
    send_line("WD:AP ts=%lu bssid=%02X:%02X:%02X:%02X:%02X:%02X ssid_hex=%s rssi=%d ch=%u auth=%s hidden=%u",
              (unsigned long)(esp_timer_get_time() / 1000), b[0], b[1], b[2], b[3], b[4], b[5],
              ssid_hex, ap->rssi, (unsigned)ap->primary, auth_name(ap->authmode), ssid_len ? 0u : 1u);
    s_ap_count++;
}

static const char *sink_name(uint8_t sink) { return sink == SINK_USB ? "usb" : sink == SINK_UART ? "uart" : "ble"; }

// One WD:CAPS per host, each naming the transport it is sent on.
static void send_caps_to(uint8_t sinks) {
    static const uint8_t EACH[] = { SINK_BLE, SINK_USB, SINK_UART };
    char buf[256];
    for (size_t i = 0; i < sizeof(EACH); i++) {
        if (!(sinks & EACH[i]) || (EACH[i] != SINK_BLE && !(s_usb_sessions & EACH[i]))) continue;
        int len = snprintf(buf, sizeof(buf), "WD:CAPS fw=%s chip=%s bands=%s ota=1 bt=1 gps=%d cap=1 usb=1 link=%s chans=",
                           FW_VERSION, CONFIG_IDF_TARGET, s_has_5g ? "2g,5g" : "2g", s_gps_present ? 1 : 0,
                           sink_name(EACH[i]));
        format_channel_list(buf, len, sizeof(buf), s_supported, s_supported_n);
        send_line_to(EACH[i], "%s", buf);
    }
}

static void send_caps_line(void) { send_caps_to(SINK_ALL); }

static void send_plan_to(uint8_t sinks) {
    uint8_t plan[MAX_CHANNELS];
    size_t n = plan_copy(plan);
    char buf[200];
    int len = snprintf(buf, sizeof(buf), "WD:PLAN chans=");
    format_channel_list(buf, len, sizeof(buf), plan, n);
    send_line_to(sinks, "%s", buf);
}

static void send_plan_line(void) { send_plan_to(SINK_ALL); }

// ─── Bluetooth role (PROTOCOL.md "Bluetooth") ─────────────────────────────
// Discovery runs in BT_WINDOW_MS windows with duplicate filtering, so each device is reported about once per
// window. Reports are queued from the host task and sent from bt_task.
static const char *bt_addr_type_name(uint8_t t) {
    return (t == BLE_ADDR_PUBLIC || t == BLE_ADDR_PUBLIC_ID) ? "public" : "random";
}

static void send_bt_line(const bt_rec_t *r) {
    char name_hex[2 * sizeof(r->name) + 1];
    for (size_t i = 0; i < r->name_len; i++) {
        name_hex[2 * i]     = lower_hex_digit((uint8_t)r->name[i] >> 4);
        name_hex[2 * i + 1] = lower_hex_digit((uint8_t)r->name[i] & 0x0F);
    }
    name_hex[2 * r->name_len] = '\0';
    char mfg[8] = "";
    if (r->has_company) snprintf(mfg, sizeof(mfg), "%04X", (unsigned)r->company);
    const uint8_t *m = r->mac;
    send_line("WD:BT ts=%lu mac=%02X:%02X:%02X:%02X:%02X:%02X type=%s rssi=%d name_hex=%s mfg=%s conn=%u",
              (unsigned long)(esp_timer_get_time() / 1000), m[0], m[1], m[2], m[3], m[4], m[5],
              bt_addr_type_name(r->addr_type), r->rssi, name_hex, mfg, (unsigned)r->conn);
    s_bt_count++;
}

static int on_disc_event(struct ble_gap_event *event, void *arg) {
    (void)arg;
    if (event->type == BLE_GAP_EVENT_DISC) {
        const struct ble_gap_disc_desc *d = &event->disc;
        bt_rec_t r = {0};
        for (int i = 0; i < 6; i++) r.mac[i] = d->addr.val[5 - i];
        r.addr_type = d->addr.type;
        r.rssi = d->rssi;
        r.conn = (d->event_type == BLE_HCI_ADV_RPT_EVTYPE_ADV_IND || d->event_type == BLE_HCI_ADV_RPT_EVTYPE_DIR_IND);
        struct ble_hs_adv_fields f;
        if (ble_hs_adv_parse_fields(&f, d->data, d->length_data) == 0) {
            if (f.name && f.name_len) {
                r.name_len = f.name_len > sizeof(r.name) ? sizeof(r.name) : f.name_len;
                memcpy(r.name, f.name, r.name_len);
            }
            if (f.mfg_data && f.mfg_data_len >= 2) {
                r.company = (uint16_t)(f.mfg_data[0] | (f.mfg_data[1] << 8));
                r.has_company = 1;
            }
        }
        if (!s_bt_queue || xQueueSend(s_bt_queue, &r, 0) != pdTRUE) s_bt_dropped++;
    } else if (event->type == BLE_GAP_EVENT_DISC_COMPLETE) {
        s_bt_window_done = true;
    }
    return 0;
}

static int bt_disc_start(void) {
    struct ble_gap_disc_params p = {
        .itvl = 0x50, .window = 0x30,   // 50 ms interval, 30 ms window: leaves room for the phone link
        .filter_policy = 0, .limited = 0, .passive = 0, .filter_duplicates = 1,
    };
    s_bt_window_done = false;
    return ble_gap_disc(s_own_addr_type, BT_WINDOW_MS, &p, on_disc_event, NULL);
}

static void bt_task(void *arg) {
    (void)arg;
    s_crumb = CR_BT;
    send_line("WD:MODE mode=bt");
    send_line("WD:BEGIN type=bt interval=0 channel=auto");
    s_bt_windows = 0;
    s_bt_count = 0;
    s_bt_dropped = 0;
    int fails = 0;
    int rc = bt_disc_start();
    bool scanning = (rc == 0);
    if (!scanning) { send_line("WD:ERR reason=bt_scan_failed rc=%d", rc); fails = 1; }
    bt_rec_t r;
    while (s_bt_running && host_linked()) {
        if (xQueueReceive(s_bt_queue, &r, pdMS_TO_TICKS(100)) == pdTRUE) { send_bt_line(&r); continue; }
        if (scanning && !s_bt_window_done) continue;
        if (scanning) {
            s_bt_windows++;
            s_bt_last = s_bt_count;
            send_line("WD:STATUS bt=%lu scans=%lu dropped=%lu", (unsigned long)s_bt_count,
                      (unsigned long)s_bt_windows, (unsigned long)s_bt_dropped);
            s_bt_count = 0;
            s_bt_dropped = 0;
        }
        rc = bt_disc_start();
        scanning = (rc == 0);
        if (scanning) { fails = 0; continue; }
        send_line("WD:ERR reason=bt_scan_failed rc=%d", rc);
        if (++fails >= 5) break;
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
    if (ble_gap_disc_active()) ble_gap_disc_cancel();
    xQueueReset(s_bt_queue);
    send_line("WD:END reason=stop");
    s_bt_running = false;
    s_bt_task = NULL;
    if (s_switch_pending) { s_switch_pending = false; stream_start(); }
    else if (host_linked()) status_led_set(STATUS_LED_ADVERTISING);
    vTaskDelete(NULL);
}

static void bt_start(void) {
    if (s_bt_running || s_bt_task || s_ota_active || !host_linked()) return;
    if (!s_bt_queue) s_bt_queue = xQueueCreate(BT_QUEUE_LEN, sizeof(bt_rec_t));
    if (!s_bt_queue) { send_line("WD:ERR reason=no_memory"); return; }
    s_bt_running = true;
    if (xTaskCreate(bt_task, "wd_bt", 6144, NULL, 5, &s_bt_task) != pdPASS) {
        s_bt_running = false;
        s_bt_task = NULL;
        send_line("WD:ERR reason=no_task");
        return;
    }
    status_led_set(STATUS_LED_STREAMING);
    ESP_LOGI(TAG, "bluetooth scan started");
}

// ─── GPS role (PROTOCOL.md "GPS", firmware 1.4+) ──────────────────────────
#if CONFIG_WARDRIVEESP_GPS_ENABLE
static volatile double s_gps_lat = 0, s_gps_lon = 0, s_gps_alt = 0;
static volatile bool   s_gps_has_alt = false;
static volatile int    s_gps_sats = 0;
static volatile bool   s_gps_dirty = false;   // a new valid fix parsed since the last WD:GPS emit

// Fixed-point format a signed double into `buf` with `dec` fractional digits (scale = 10^dec), using only
// integer printf conversions — the firmware may be built with newlib's nano formatting, which drops %f, so
// WD:GPS coordinates must not go through %f. lat/lon/alt all fit comfortably in a 32-bit long after scaling.
static void fmt_fixed(char *buf, size_t cap, double v, long scale, int dec) {
    bool neg = v < 0; if (neg) v = -v;
    long scaled = (long)(v * (double)scale + 0.5);
    snprintf(buf, cap, "%s%ld.%0*ld", neg ? "-" : "", scaled / scale, dec, scaled % scale);
}

// NMEA ddmm.mmmm (lat) / dddmm.mmmm (lon) → signed decimal degrees. Hemisphere 'S'/'W' negates.
static double nmea_coord(const char *v, const char *hemi) {
    if (!v || !*v) return 0;
    double raw = atof(v);
    double deg = (double)((int)(raw / 100.0));
    double val = deg + (raw - deg * 100.0) / 60.0;
    if (hemi && (*hemi == 'S' || *hemi == 's' || *hemi == 'W' || *hemi == 'w')) val = -val;
    return val;
}

// Parse one NMEA sentence (NUL-terminated, no trailing CR/LF). We read $??GGA (lat/lon/alt/fix/sats) and
// $??RMC (lat/lon/fix) — any talker id (GP/GN/GA/GL/GB). A fix updates the shared state and flags an emit.
static void handle_nmea(char *line) {
    if (line[0] != '$' || strlen(line) < 7) return;
    const char *type = line + 3;                 // skip '$' + 2-char talker id
    bool gga = (strncmp(type, "GGA", 3) == 0);
    bool rmc = (strncmp(type, "RMC", 3) == 0);
    if (!gga && !rmc) return;
    char *star = strchr(line, '*'); if (star) *star = '\0';   // drop the *CS checksum
    // Split on commas, preserving empty fields (strtok would collapse them — NMEA has many).
    char *f[20]; int nf = 0; f[nf++] = line;
    for (char *p = line; *p && nf < 20; p++) if (*p == ',') { *p = '\0'; f[nf++] = p + 1; }

    double lat, lon;
    if (gga) {
        if (nf < 10 || atoi(f[6]) <= 0) return;  // fix quality 0 = no fix
        lat = nmea_coord(f[2], f[3]); lon = nmea_coord(f[4], f[5]);
        if (lat == 0 && lon == 0) return;
        s_gps_lat = lat; s_gps_lon = lon;
        s_gps_sats = atoi(f[7]);
        if (f[9][0]) { s_gps_alt = atof(f[9]); s_gps_has_alt = true; }
    } else {                                     // RMC — no altitude/sats; keep the last GGA's
        if (nf < 7 || f[2][0] != 'A') return;    // status V = void (no fix)
        lat = nmea_coord(f[3], f[4]); lon = nmea_coord(f[5], f[6]);
        if (lat == 0 && lon == 0) return;
        s_gps_lat = lat; s_gps_lon = lon;
    }
    s_gps_present = true;                         // runtime presence-detect: now WD:CAPS can advertise gps=1
    s_gps_dirty = true;
}

static void gps_task(void *arg) {
    (void)arg;
    const uart_port_t port = CONFIG_WARDRIVEESP_GPS_UART_NUM;
    uart_config_t cfg = {
        .baud_rate = CONFIG_WARDRIVEESP_GPS_BAUD,
        .data_bits = UART_DATA_8_BITS,
        .parity    = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    if (uart_driver_install(port, 1024, 0, 0, NULL, 0) != ESP_OK) { vTaskDelete(NULL); return; }
    uart_param_config(port, &cfg);
    int tx = CONFIG_WARDRIVEESP_GPS_TX_GPIO;
    uart_set_pin(port, tx >= 0 ? tx : UART_PIN_NO_CHANGE, CONFIG_WARDRIVEESP_GPS_RX_GPIO,
                 UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    ESP_LOGI(TAG, "GPS: UART%d rx=%d tx=%d @ %d baud", (int)port, CONFIG_WARDRIVEESP_GPS_RX_GPIO, tx,
             CONFIG_WARDRIVEESP_GPS_BAUD);
    char line[128]; int li = 0;
    uint8_t buf[128];
    uint32_t last_emit = 0;
    for (;;) {
        int n = uart_read_bytes(port, buf, sizeof(buf), pdMS_TO_TICKS(200));
        for (int i = 0; i < n; i++) {
            char c = (char)buf[i];
            if (c == '\n' || c == '\r') { if (li > 0) { line[li] = '\0'; handle_nmea(line); li = 0; } }
            else if (li < (int)sizeof(line) - 1) line[li++] = c;
            else li = 0;                           // oversized/garbled line — drop it
        }
        // Emit at most once a second, only while connected (send_line no-ops when there's no link).
        uint32_t now = (uint32_t)(esp_timer_get_time() / 1000);
        if (s_gps_dirty && now - last_emit >= 1000) {
            s_gps_dirty = false; last_emit = now;
            char latb[20], lonb[20], altb[16];
            fmt_fixed(latb, sizeof(latb), s_gps_lat, 1000000, 6);
            fmt_fixed(lonb, sizeof(lonb), s_gps_lon, 1000000, 6);
            if (s_gps_has_alt) {
                fmt_fixed(altb, sizeof(altb), s_gps_alt, 10, 1);
                send_line("WD:GPS ts=%lu lat=%s lon=%s alt=%s fix=1 sats=%d",
                          (unsigned long)now, latb, lonb, altb, s_gps_sats);
            } else {
                send_line("WD:GPS ts=%lu lat=%s lon=%s fix=1 sats=%d",
                          (unsigned long)now, latb, lonb, s_gps_sats);
            }
        }
    }
}
#endif  // CONFIG_WARDRIVEESP_GPS_ENABLE

static void scan_one_channel(uint8_t ch) {
    wifi_scan_config_t cfg = { .channel = ch, .show_hidden = true };
    if (is_5ghz(ch) || is_dfs(ch)) {
        cfg.scan_type = WIFI_SCAN_TYPE_PASSIVE;
        cfg.scan_time.passive = PASSIVE_DWELL_MS;
    } else {
        cfg.scan_type = WIFI_SCAN_TYPE_ACTIVE;   // default dwell; coex rejects custom active times
    }
    s_crumb_ch = ch;
    s_crumb = CR_SCAN;
    if (esp_wifi_scan_start(&cfg, true) != ESP_OK) { s_crumb = CR_IDLE; return; }
    s_crumb = CR_RESULTS;
    uint16_t found = 0;
    if (esp_wifi_scan_get_ap_num(&found) != ESP_OK || found == 0) { s_crumb = CR_IDLE; return; }
    if (found > MAX_AP_PER_SCAN) found = MAX_AP_PER_SCAN;
    wifi_ap_record_t *aps = calloc(found, sizeof(*aps));
    if (!aps) return;
    s_crumb = CR_SEND_AP;
    if (esp_wifi_scan_get_ap_records(&found, aps) == ESP_OK)
        for (uint16_t i = 0; i < found && s_streaming; i++) send_ap_line(&aps[i]);
    free(aps);
    s_crumb = CR_IDLE;
}

static char s_boot_line[220];   // built at boot by boot_diag_begin()
static char s_crash_line[200];  // WD:CRASH for the previous run, when it ended in a crash or watchdog reset

static volatile uint32_t s_conns = 0, s_last_disc_reason = 0, s_last_disc_ms = 0;

static void send_link_line(uint8_t sinks) {
    uint16_t mtu = s_conn_handle != BLE_HS_CONN_HANDLE_NONE ? ble_att_mtu(s_conn_handle) : 0;
    uint32_t now = (uint32_t)(esp_timer_get_time() / 1000);
    if (s_last_disc_ms)
        send_line_to(sinks, "WD:LINK conns=%lu mtu=%u prev_disc=0x%03lx prev_disc_ago=%lus", (unsigned long)s_conns,
                     (unsigned)mtu, (unsigned long)s_last_disc_reason, (unsigned long)((now - s_last_disc_ms) / 1000));
    else
        send_line_to(sinks, "WD:LINK conns=%lu mtu=%u prev_disc=none", (unsigned long)s_conns, (unsigned)mtu);
}

/// Ask the phone for link timing inside Apple's accessory guidelines. Normal: 30-50 ms interval, no latency, 5 s
/// supervision timeout. A phone holding many boards fits them into its radio schedule more easily, and a board busy on
/// Wi-Fi (radio coexistence) can miss a few connection events without the link dropping. Scan lines need far less than
/// this carries at a 247-byte MTU. A firmware update over BLE asks for 15-30 ms while it runs. The phone may refuse.
static void request_link_params(bool fast) {
    if (s_conn_handle == BLE_HS_CONN_HANDLE_NONE) return;
    struct ble_gap_upd_params p = {
        .itvl_min = fast ? 12 : 24,      // 1.25 ms units: 15 / 30 ms
        .itvl_max = fast ? 24 : 40,      // 30 / 50 ms
        .latency = 0,
        .supervision_timeout = 500,      // 10 ms units: 5 s
        .min_ce_len = 0,
        .max_ce_len = 0,
    };
    int rc = ble_gap_update_params(s_conn_handle, &p);
    if (rc != 0) ESP_LOGW(TAG, "link timing request failed: %d", rc);
}

/// The link timing in use after the phone answered a request (or changed it on its own).
static void send_conn_line(int status) {
    struct ble_gap_conn_desc d;
    if (s_conn_handle == BLE_HS_CONN_HANDLE_NONE || ble_gap_conn_find(s_conn_handle, &d) != 0) return;
    ESP_LOGI(TAG, "link timing: status %d, interval %u x 1.25 ms, latency %u, timeout %u x 10 ms", status,
             (unsigned)d.conn_itvl, (unsigned)d.conn_latency, (unsigned)d.supervision_timeout);
    send_line_to(SINK_BLE, "WD:CONN itvl_ms=%u latency=%u timeout_ms=%u status=%d", (unsigned)(d.conn_itvl * 5 / 4),
                 (unsigned)d.conn_latency, (unsigned)d.supervision_timeout * 10, status);
}

static void send_header(uint8_t sinks) {
    send_caps_to(sinks);
    if (s_boot_line[0]) send_line_to(sinks, "%s", s_boot_line);
    if (s_crash_line[0]) send_line_to(sinks, "%s", s_crash_line);
    send_link_line(sinks);
}

static void scan_task(void *arg) {
    (void)arg;
    send_header(SINK_ALL);
    send_line("WD:MODE mode=wifi");
    send_line("WD:BEGIN type=wifi interval=0 channel=auto");
    send_plan_line();
    s_sweeps = 0;
    uint8_t plan[MAX_CHANNELS];
    while (s_streaming && host_linked()) {
        size_t n = plan_copy(plan);
        s_ap_count = 0;   // APs heard this sweep (one record per AP per channel scan)
        for (size_t i = 0; i < n && s_streaming; i++) {
            scan_one_channel(plan[i]);
            vTaskDelay(pdMS_TO_TICKS(5));
        }
        if (n == 0) vTaskDelay(pdMS_TO_TICKS(200));
        s_sweeps++;
        s_last_aps = s_ap_count;
        send_line("WD:STATUS aps=%lu scans=%lu", (unsigned long)s_ap_count, (unsigned long)s_sweeps);
    }
    send_line("WD:END reason=stop");
    s_streaming = false;
    s_scan_task = NULL;
    if (s_switch_pending) { s_switch_pending = false; stream_start(); }
    vTaskDelete(NULL);
}

static void wifi_start(void) {
    if (s_streaming || s_scan_task || s_ota_active || !host_linked()) return;
    s_streaming = true;
    if (xTaskCreate(scan_task, "wd_scan", 10240, NULL, 5, &s_scan_task) != pdPASS) {
        s_streaming = false;
        s_scan_task = NULL;
        ESP_LOGE(TAG, "scan task create failed");
        return;
    }
    status_led_set(STATUS_LED_STREAMING);
    ESP_LOGI(TAG, "stream started");
}

// ─── Capture role (PROTOCOL.md "Capture", firmware 1.5+) ──────────────────────
// PASSIVE 802.11 promiscuous capture: WPA 4-way handshakes (WD:HS, hashcat-22000), RSN PMKIDs (WD:PMKID) and
// station sightings (WD:CLIENT). RX ONLY — the board never transmits, deauths or injects; a crackable artifact
// only appears when a client associates on its own. A C port of the Android PmkidCapture (EAPOL M1..M4, ANonce/M2
// replay pairing, MIC-zeroed hashcat line, PMKID KDE) plus MonitorCapture's client/BSSID derivation. The
// promiscuous rx callback runs in the Wi-Fi task and must not block, so it copies each frame (truncated) into a
// queue; cap_task drains it and does all the parsing.
#define CAP_SNAP        256   // bytes copied per frame — EAPOL key frames are ~155 B, SSID sits near a beacon's front
#define CAP_QUEUE_LEN   32
#define CAP_DWELL_MS    300   // longer than a scan dwell: a handshake only happens if a client associates while we camp
#define CAP_M1_CACHE    16    // M1 ANonces awaiting their M2
#define CAP_AP_CACHE    160   // BSSID→SSID/best-RSSI table: feeds WD:AP so capture is a superset of a Wi-Fi scan
#define CAP_SEEN_CAP    512   // session dedup fingerprints (handshake MIC / PMKID / client) before it rolls over

typedef struct {
    uint16_t len;
    int8_t   rssi;
    uint8_t  channel;
    uint8_t  data[CAP_SNAP];
} cap_rec_t;

static QueueHandle_t s_cap_queue;
static TaskHandle_t  s_cap_task        = NULL;
static volatile bool s_cap_running     = false;
static volatile uint32_t s_cap_hs      = 0;
static volatile uint32_t s_cap_pmkid   = 0;
static volatile uint32_t s_cap_clients = 0;
static volatile uint32_t s_cap_aps     = 0;
static volatile uint32_t s_cap_data    = 0;
static volatile uint32_t s_cap_dropped = 0;

typedef struct {   // M1 ANonce cache (raw bytes), keyed AP+STA, paired with the matching M2 by replay counter
    bool     used;
    uint8_t  ap[6], sta[6], anonce[32], replay[8];
    uint32_t time;
} cap_m1_t;
static cap_m1_t s_cap_m1[CAP_M1_CACHE];

typedef struct { bool used; uint8_t bssid[6], ssid[32], ssid_len; int8_t best_rssi; uint32_t last_emit; } cap_ap_t;
static cap_ap_t s_cap_aps_tbl[CAP_AP_CACHE];
#define CAP_AP_REEMIT_MS 20000   // re-report a still-heard AP at least this often so the phone's "in range" count stays live

static uint32_t s_cap_seen[CAP_SEEN_CAP];   // open set of 32-bit artifact fingerprints; cleared when full
static size_t   s_cap_seen_n = 0;

static uint32_t cap_fnv(const uint8_t *p, size_t n, uint32_t seed) {
    uint32_t h = seed ? seed : 2166136261u;
    for (size_t i = 0; i < n; i++) { h ^= p[i]; h *= 16777619u; }
    return h;
}
static bool cap_seen_add(uint32_t fp) {
    for (size_t i = 0; i < s_cap_seen_n; i++) if (s_cap_seen[i] == fp) return false;
    if (s_cap_seen_n >= CAP_SEEN_CAP) s_cap_seen_n = 0;   // roll over; the phone dedups by pmkid/mic too
    s_cap_seen[s_cap_seen_n++] = fp;
    return true;
}
static void cap_reset_session(void) {
    memset(s_cap_m1, 0, sizeof(s_cap_m1));
    memset(s_cap_aps_tbl, 0, sizeof(s_cap_aps_tbl));
    s_cap_seen_n = 0;
    s_cap_hs = s_cap_pmkid = s_cap_clients = s_cap_aps = s_cap_data = s_cap_dropped = 0;
}

static int cap_hex(char *out, const uint8_t *p, size_t n) {
    for (size_t i = 0; i < n; i++) { out[2 * i] = lower_hex_digit(p[i] >> 4); out[2 * i + 1] = lower_hex_digit(p[i] & 0x0F); }
    out[2 * n] = '\0';
    return (int)(2 * n);
}

// Upsert a beacon/probe-response's BSSID into the AP table (SSID + best RSSI). Returns true when the phone should
// get a WD:AP for it — the first time it's seen, or when a later sighting is notably stronger — so capture mode
// reports APs like a Wi-Fi scan without flooding the link with one line per beacon. Evicts the weakest when full.
static bool cap_ap_touch(const uint8_t *bssid, const uint8_t *ssid, int ssid_len, int rssi) {
    int slot = -1, freeslot = -1, weakest = 0; int8_t weakest_rssi = 127;
    for (int i = 0; i < CAP_AP_CACHE; i++) {
        if (s_cap_aps_tbl[i].used && memcmp(s_cap_aps_tbl[i].bssid, bssid, 6) == 0) { slot = i; break; }
        if (!s_cap_aps_tbl[i].used && freeslot < 0) freeslot = i;
        if (s_cap_aps_tbl[i].used && s_cap_aps_tbl[i].best_rssi < weakest_rssi) { weakest_rssi = s_cap_aps_tbl[i].best_rssi; weakest = i; }
    }
    bool fresh = (slot < 0);
    if (fresh) {
        slot = (freeslot >= 0) ? freeslot : weakest;
        s_cap_aps_tbl[slot].used = true;
        memcpy(s_cap_aps_tbl[slot].bssid, bssid, 6);
        s_cap_aps_tbl[slot].ssid_len = 0;
        s_cap_aps_tbl[slot].best_rssi = -128;
    }
    cap_ap_t *a = &s_cap_aps_tbl[slot];
    if (ssid_len > 0 && ssid_len <= 32) { memcpy(a->ssid, ssid, ssid_len); a->ssid_len = (uint8_t)ssid_len; }
    uint32_t now = (uint32_t)(esp_timer_get_time() / 1000);
    // Emit on first sight, a notably stronger RSSI, or if it's been a while — so the phone keeps counting it "in range".
    if (fresh || rssi > (int)a->best_rssi + 4 || now - a->last_emit > CAP_AP_REEMIT_MS) {
        if (rssi > (int)a->best_rssi) a->best_rssi = (int8_t)rssi;
        a->last_emit = now;
        return true;
    }
    return false;
}
static const cap_ap_t *cap_find_ssid(const uint8_t *bssid) {
    for (int i = 0; i < CAP_AP_CACHE; i++)
        if (s_cap_aps_tbl[i].used && memcmp(s_cap_aps_tbl[i].bssid, bssid, 6) == 0 && s_cap_aps_tbl[i].ssid_len)
            return &s_cap_aps_tbl[i];
    return NULL;
}

// The WPA/WPA2/WPA3 token for a beacon/probe-response, from its capability + RSN/WPA information elements — the
// same token set a Wi-Fi scan reports (auth_name), so capture-mode WD:AP lines read identically to scan-mode ones.
static const char *cap_beacon_auth(const uint8_t *b, int end) {
    if (end < 36) return "OPEN";
    int capinfo = b[34] | (b[35] << 8);
    if (!(capinfo & 0x10)) return "OPEN";                       // Privacy bit clear → open
    bool rsn = false, wpa = false, sae = false, psk = false;
    for (int i = 36; i + 2 <= end; ) {
        int id = b[i], len = b[i + 1];
        if (i + 2 + len > end) break;
        const uint8_t *p = b + i + 2;
        if (id == 0x30 && len >= 8) {                           // RSN IE
            rsn = true;
            int off = 2 + 4;                                    // skip version + group cipher
            if (off + 2 <= len) {
                int pc = p[off] | (p[off + 1] << 8); off += 2 + 4 * pc;   // skip pairwise ciphers
                if (off + 2 <= len) {
                    int ac = p[off] | (p[off + 1] << 8); off += 2;
                    for (int k = 0; k < ac && off + 4 <= len; k++, off += 4) {
                        if (p[off] == 0x00 && p[off + 1] == 0x0F && p[off + 2] == 0xAC) {
                            uint8_t suite = p[off + 3];
                            if (suite == 8 || suite == 9) sae = true;    // SAE / FT-SAE → WPA3
                            if (suite == 2 || suite == 6) psk = true;    // PSK / FT-PSK
                        }
                    }
                }
            }
        } else if (id == 0xDD && len >= 4 && p[0] == 0x00 && p[1] == 0x50 && p[2] == 0xF2 && p[3] == 0x01) {
            wpa = true;                                         // Microsoft WPA1 vendor IE
        }
        i += 2 + len;
    }
    if (sae) return (rsn && psk) ? "WPA2_WPA3" : "WPA3";
    if (rsn) return "WPA2";
    if (wpa) return "WPA";
    return "WEP";                                               // privacy set but no RSN/WPA IE → WEP
}

// Emit a WD:AP line from a beacon/probe-response, identical in shape to the scan-mode AP line.
static void cap_emit_ap(const uint8_t *b, const uint8_t *ssid, int ssid_len, int rssi, int ch, const char *auth) {
    char ssid_hex[2 * 32 + 1] = "";
    if (ssid_len > 0 && ssid_len <= 32) cap_hex(ssid_hex, ssid, (size_t)ssid_len);
    send_line("WD:AP ts=%lu bssid=%02X:%02X:%02X:%02X:%02X:%02X ssid_hex=%s rssi=%d ch=%d auth=%s hidden=%u",
              (unsigned long)(esp_timer_get_time() / 1000), b[0], b[1], b[2], b[3], b[4], b[5],
              ssid_hex, rssi, ch, auth, ssid_len ? 0u : 1u);
    s_cap_aps++;
}

// A station sighting, deduped once per capture session. Broadcast/multicast/zero MACs are not devices.
static void cap_emit_client(const uint8_t *mac, const uint8_t *bssid, int rssi, int ch) {
    if (mac[0] & 0x01) return;
    bool zero = true; for (int i = 0; i < 6; i++) if (mac[i]) zero = false;
    if (zero) return;
    uint32_t fp = cap_fnv(mac, 6, 0x515ad70bu);
    if (!cap_seen_add(fp)) return;
    char bss[20] = "";
    if (bssid) snprintf(bss, sizeof(bss), "%02X:%02X:%02X:%02X:%02X:%02X",
                        bssid[0], bssid[1], bssid[2], bssid[3], bssid[4], bssid[5]);
    send_line("WD:CLIENT ts=%lu mac=%02X:%02X:%02X:%02X:%02X:%02X bssid=%s rssi=%d ch=%d",
              (unsigned long)(esp_timer_get_time() / 1000), mac[0], mac[1], mac[2], mac[3], mac[4], mac[5],
              bss, rssi, ch);
    s_cap_clients++;
}

// Port of PmkidCapture.scan: locate EAPOL in a data frame, classify M1..M4, pair M1/M2 into a hashcat-22000
// handshake line, and lift the RSN PMKID KDE. `buf` is the 802.11 frame at offset 0; `end` excludes the FCS.
static void cap_parse_eapol(const uint8_t *buf, int end, int ch, int rssi) {
    if (end < 2 || ((buf[0] >> 2) & 3) != 2) return;          // data frames only
    int fromDs = (buf[1] >> 1) & 1;
    int p = -1, hi = end - 8; if (hi > 40) hi = 40;           // scan the header/pad window for AA AA 03 .. .. .. 88 8E
    for (int q = 24; q <= hi; q++)
        if (buf[q] == 0xAA && buf[q + 1] == 0xAA && buf[q + 2] == 0x03 && buf[q + 6] == 0x88 && buf[q + 7] == 0x8E) { p = q; break; }
    if (p < 0) return;
    int eapol = p + 8;
    if (eapol + 7 > end || buf[eapol + 1] != 3) return;       // EAPOL-Key
    int keyInfo = (buf[eapol + 5] << 8) | buf[eapol + 6];
    bool ack = keyInfo & 0x080, hasMic = keyInfo & 0x100, install = keyInfo & 0x040, secure = keyInfo & 0x200;
    int m = (ack && !hasMic) ? 1 : (hasMic && !ack && !secure && !install) ? 2
          : (hasMic && ack && install) ? 3 : (hasMic && secure && !ack) ? 4 : 0;
    const uint8_t *ap  = fromDs ? buf + 10 : buf + 4;         // M1: AP=addr2; M2: AP=addr1
    const uint8_t *sta = fromDs ? buf + 4  : buf + 10;
    uint32_t now = (uint32_t)(esp_timer_get_time() / 1000);

    if (m == 1 && eapol + 49 <= end) {                        // cache the ANonce for M2 pairing
        int slot = -1, freeslot = -1, oldest = 0; uint32_t oldest_t = 0xffffffffu;
        for (int i = 0; i < CAP_M1_CACHE; i++) {
            if (s_cap_m1[i].used && !memcmp(s_cap_m1[i].ap, ap, 6) && !memcmp(s_cap_m1[i].sta, sta, 6)) { slot = i; break; }
            if (!s_cap_m1[i].used && freeslot < 0) freeslot = i;
            if (s_cap_m1[i].time < oldest_t) { oldest_t = s_cap_m1[i].time; oldest = i; }
        }
        if (slot < 0) slot = (freeslot >= 0) ? freeslot : oldest;
        s_cap_m1[slot].used = true;
        memcpy(s_cap_m1[slot].ap, ap, 6); memcpy(s_cap_m1[slot].sta, sta, 6);
        memcpy(s_cap_m1[slot].anonce, buf + eapol + 17, 32);
        memcpy(s_cap_m1[slot].replay, buf + eapol + 9, 8);
        s_cap_m1[slot].time = now;
    }
    if (m == 2 && eapol + 99 <= end) {                        // pair with the cached M1 by replay counter
        int bodyLen = (buf[eapol + 2] << 8) | buf[eapol + 3];
        int frameLen = 4 + bodyLen;
        cap_m1_t *m1 = NULL;
        for (int i = 0; i < CAP_M1_CACHE; i++)
            if (s_cap_m1[i].used && !memcmp(s_cap_m1[i].ap, ap, 6) && !memcmp(s_cap_m1[i].sta, sta, 6)) { m1 = &s_cap_m1[i]; break; }
        if (m1 && !memcmp(m1->replay, buf + eapol + 9, 8) && frameLen >= 99 && eapol + frameLen <= end) {
            const uint8_t *mic = buf + eapol + 81;
            bool mic_zero = true; for (int i = 0; i < 16; i++) if (mic[i]) mic_zero = false;
            if (!mic_zero && cap_seen_add(cap_fnv(mic, 16, 0x48530001u))) {
                if (frameLen > CAP_SNAP) frameLen = CAP_SNAP;
                uint8_t fr[CAP_SNAP];
                memcpy(fr, buf + eapol, frameLen);
                for (int k = 81; k < 97 && k < frameLen; k++) fr[k] = 0;   // zero the MIC field in the EAPOL copy
                char michex[33], anoncehex[65], eapolhex[2 * CAP_SNAP + 1], essidhex[2 * 32 + 1] = "";
                cap_hex(michex, mic, 16);
                cap_hex(anoncehex, m1->anonce, 32);
                cap_hex(eapolhex, fr, frameLen);
                const cap_ap_t *ss = cap_find_ssid(ap);
                if (ss) cap_hex(essidhex, ss->ssid, ss->ssid_len);
                // Worst case (256-byte EAPOL → 512 hex, 64-byte ESSID, 64 ANonce) reaches ~880 bytes; size for it.
                // send_chunks splits it across MTU-sized DATA frames, so only this build buffer caps the length.
                char line[1100];
                int n = snprintf(line, sizeof(line) - 1,
                    "WD:HS ts=%lu bssid=%02X:%02X:%02X:%02X:%02X:%02X sta=%02X:%02X:%02X:%02X:%02X:%02X ssid_hex=%s ch=%d rssi=%d "
                    "hc22000=WPA*02*%s*%02x%02x%02x%02x%02x%02x*%02x%02x%02x%02x%02x%02x*%s*%s*%s*00",
                    (unsigned long)now, ap[0], ap[1], ap[2], ap[3], ap[4], ap[5],
                    sta[0], sta[1], sta[2], sta[3], sta[4], sta[5], essidhex, ch, rssi,
                    michex, ap[0], ap[1], ap[2], ap[3], ap[4], ap[5],
                    sta[0], sta[1], sta[2], sta[3], sta[4], sta[5], essidhex, anoncehex, eapolhex);
                if (n > 0) {
                    if (n > (int)sizeof(line) - 2) n = (int)sizeof(line) - 2;
                    line[n++] = '\n';
                    send_chunks(line, (size_t)n);
                    s_cap_hs++;
                    m1->used = false;
                }
            }
        }
    }
    for (int i = eapol, limit = end - 22; i <= limit; i++) {  // PMKID KDE: DD 14 00 0F AC 04 <16 bytes>
        if (buf[i] == 0xDD && buf[i + 1] == 0x14 && buf[i + 2] == 0x00 && buf[i + 3] == 0x0F &&
            buf[i + 4] == 0xAC && buf[i + 5] == 0x04) {
            const uint8_t *pm = buf + i + 6;
            bool zero = true; for (int k = 0; k < 16; k++) if (pm[k]) zero = false;
            if (zero) return;
            if (!cap_seen_add(cap_fnv(pm, 16, 0x504d4b31u))) return;
            char pmhex[33], essidhex[2 * 32 + 1] = "";
            cap_hex(pmhex, pm, 16);
            const cap_ap_t *ss = cap_find_ssid(ap);
            if (ss) cap_hex(essidhex, ss->ssid, ss->ssid_len);
            send_line("WD:PMKID ts=%lu bssid=%02X:%02X:%02X:%02X:%02X:%02X sta=%02X:%02X:%02X:%02X:%02X:%02X "
                      "ssid_hex=%s ch=%d rssi=%d pmkid=%s",
                      (unsigned long)now, ap[0], ap[1], ap[2], ap[3], ap[4], ap[5],
                      sta[0], sta[1], sta[2], sta[3], sta[4], sta[5], essidhex, ch, rssi, pmhex);
            s_cap_pmkid++;
            return;
        }
    }
}

static void cap_process(const cap_rec_t *r) {
    const uint8_t *b = r->data;
    int end = r->len;
    if (end < 24) return;                                     // a full MAC header is 24 bytes
    int fc = b[0], ftype = (fc >> 2) & 3, sub = (fc >> 4) & 0xF;
    if (ftype == 0) {                                         // management
        const uint8_t *addr2 = b + 10, *addr3 = b + 16;       // transmitter / BSSID
        if (sub == 8 || sub == 5) {                           // beacon / probe-response → AP (WD:AP) + learn SSID
            const uint8_t *ssid = NULL; int sl = 0;
            int t = 24 + 12;                                  // after 24-byte header + 12 fixed params
            if (t + 2 <= end && b[t] == 0) {                  // element id 0 = SSID
                int l = b[t + 1];
                if (l > 0 && l <= 32 && t + 2 + l <= end) { ssid = b + t + 2; sl = l; }
            }
            if (cap_ap_touch(addr3, ssid, sl, r->rssi))
                cap_emit_ap(addr3, ssid, sl, r->rssi, r->channel, cap_beacon_auth(b, end));
        } else if (sub == 4) {
            cap_emit_client(addr2, NULL, r->rssi, r->channel);          // probe-request — client, BSSID unknown
        } else if (sub <= 3 || sub == 11) {
            cap_emit_client(addr2, addr3, r->rssi, r->channel);         // assoc/reassoc/auth — client + BSSID
        }
    } else if (ftype == 2) {                                  // data
        s_cap_data++;
        cap_parse_eapol(b, end, r->channel, r->rssi);
        int fromDs = (b[1] >> 1) & 1, toDs = b[1] & 1;
        const uint8_t *a1 = b + 4, *a2 = b + 10;
        if (toDs && !fromDs)       cap_emit_client(a2, a1, r->rssi, r->channel);   // client→AP: client=addr2 bssid=addr1
        else if (!toDs && fromDs)  cap_emit_client(a1, a2, r->rssi, r->channel);   // AP→client: client=addr1 bssid=addr2
        else if (!toDs && !fromDs) cap_emit_client(a2, a1, r->rssi, r->channel);   // IBSS
        // WDS (toDs && fromDs): four addresses, no simple client/BSSID — skip
    }
}

static void cap_rx_cb(void *buf, wifi_promiscuous_pkt_type_t type) {
    if (!s_cap_running || (type != WIFI_PKT_MGMT && type != WIFI_PKT_DATA)) return;
    const wifi_promiscuous_pkt_t *pkt = (const wifi_promiscuous_pkt_t *)buf;
    int end = pkt->rx_ctrl.sig_len - 4;                       // drop the trailing FCS
    if (end <= 0) return;
    cap_rec_t r;
    r.len = end > CAP_SNAP ? CAP_SNAP : (uint16_t)end;
    r.rssi = pkt->rx_ctrl.rssi;
    r.channel = pkt->rx_ctrl.channel;
    memcpy(r.data, pkt->payload, r.len);
    if (!s_cap_queue || xQueueSend(s_cap_queue, &r, 0) != pdTRUE) s_cap_dropped++;
}

static void cap_task(void *arg) {
    (void)arg;
    s_crumb = CR_CAP;
    cap_reset_session();
    send_caps_line();
    send_line("WD:MODE mode=cap");
    send_line("WD:BEGIN type=cap interval=0 channel=auto");
    send_plan_line();

    (void)esp_wifi_scan_stop();
    wifi_promiscuous_filter_t filt = { .filter_mask = WIFI_PROMIS_FILTER_MASK_MGMT | WIFI_PROMIS_FILTER_MASK_DATA };
    esp_wifi_set_promiscuous_filter(&filt);
    esp_wifi_set_promiscuous_rx_cb(cap_rx_cb);
    if (esp_wifi_set_promiscuous(true) != ESP_OK) send_line("WD:ERR reason=promisc_failed");

    uint8_t plan[MAX_CHANNELS];
    uint32_t sweeps = 0;
    cap_rec_t r;
    while (s_cap_running && host_linked()) {
        size_t n = plan_copy(plan);
        if (n == 0) { vTaskDelay(pdMS_TO_TICKS(200)); continue; }
        for (size_t i = 0; i < n && s_cap_running; i++) {
            esp_wifi_set_channel(plan[i], WIFI_SECOND_CHAN_NONE);
            uint32_t until = (uint32_t)(esp_timer_get_time() / 1000) + CAP_DWELL_MS;
            while ((uint32_t)(esp_timer_get_time() / 1000) < until && s_cap_running)
                if (xQueueReceive(s_cap_queue, &r, pdMS_TO_TICKS(20)) == pdTRUE) cap_process(&r);
        }
        sweeps++;
        send_line("WD:STATUS cap=1 aps=%lu hs=%lu pmkid=%lu clients=%lu data=%lu scans=%lu dropped=%lu",
                  (unsigned long)s_cap_aps, (unsigned long)s_cap_hs, (unsigned long)s_cap_pmkid,
                  (unsigned long)s_cap_clients, (unsigned long)s_cap_data, (unsigned long)sweeps,
                  (unsigned long)s_cap_dropped);
    }
    esp_wifi_set_promiscuous(false);
    esp_wifi_set_promiscuous_rx_cb(NULL);
    if (s_cap_queue) xQueueReset(s_cap_queue);
    send_line("WD:END reason=stop");
    s_cap_running = false;
    s_cap_task = NULL;
    if (s_switch_pending) { s_switch_pending = false; stream_start(); }
    else if (host_linked()) status_led_set(STATUS_LED_ADVERTISING);
    vTaskDelete(NULL);
}

static void cap_start(void) {
    if (s_cap_running || s_cap_task || s_ota_active || !host_linked()) return;
    if (!s_cap_queue) s_cap_queue = xQueueCreate(CAP_QUEUE_LEN, sizeof(cap_rec_t));
    if (!s_cap_queue) { send_line("WD:ERR reason=no_memory"); return; }
    s_cap_running = true;
    if (xTaskCreate(cap_task, "wd_cap", 10240, NULL, 5, &s_cap_task) != pdPASS) {
        s_cap_running = false;
        s_cap_task = NULL;
        send_line("WD:ERR reason=no_task");
        return;
    }
    status_led_set(STATUS_LED_STREAMING);
    ESP_LOGI(TAG, "capture started");
}

/// Starts scanning in this board's current role.
static void stream_start(void) {
    switch (s_role) {
    case ROLE_BT:  bt_start();  break;
    case ROLE_CAP: cap_start(); break;
    default:       wifi_start(); break;
    }
}

static void stream_stop(void) {
    s_streaming = false;
    s_bt_running = false;
    s_cap_running = false;
    (void)esp_wifi_scan_stop();
    if (host_linked()) status_led_set(STATUS_LED_ADVERTISING);
}

/// Switches the board between Wi-Fi, Bluetooth and Capture roles. A running task finishes first; the task that
/// ends then starts the new role.
static const char *role_name(scan_role_t role) { return role == ROLE_BT ? "bt" : role == ROLE_CAP ? "cap" : "wifi"; }

static void set_role(scan_role_t role) {
    const char *name = role_name(role);
    if (role == s_role) {
        send_line("WD:MODE mode=%s", name);
        if (!s_streaming && !s_bt_running && !s_cap_running && !s_scan_task && !s_bt_task && !s_cap_task) stream_start();
        return;
    }
    s_role = role;
    send_line("WD:MODE mode=%s", name);
    if (s_scan_task || s_bt_task || s_cap_task) {
        s_switch_pending = true;
        stream_stop();
    } else {
        stream_start();
    }
}

/// A host linked (BLE subscribe or USB hello): start scanning, or bring it up to date with the scan already running.
static void host_joined(uint8_t sink) {
    if (s_streaming || s_bt_running || s_cap_running) {
        const char *m = role_name(s_role);
        send_header(sink);
        send_line_to(sink, "WD:MODE mode=%s", m);
        send_line_to(sink, "WD:BEGIN type=%s interval=0 channel=auto", m);
        if (s_role != ROLE_BT) send_plan_to(sink);
        return;
    }
    if (s_role != ROLE_WIFI || s_ota_active) send_header(sink);   // only the Wi-Fi scan task sends the header itself
    if (s_scan_task || s_bt_task || s_cap_task) s_switch_pending = true;   // still finishing: it restarts the role
    else stream_start();
}

// ─── Firmware update over BLE and USB (PROTOCOL.md "Firmware update") ──────
// Image bytes arrive on the OTA characteristic and are queued; this task writes them to the spare app slot
// (sequential writes erase sector by sector, so nothing blocks the BLE host for long) and acks progress.
// The receive buffer is created once and only reset, never freed, so a late BLE write can't land in freed memory.
static void ota_cleanup(void) {
    bool was_ble = s_ota_active && s_ota_src == SINK_BLE;
    s_ota_active = false;
    s_ota_end_req = false;
    s_ota_abort_req = false;
    s_ota_task = NULL;
    if (was_ble) request_link_params(false);   // back to the normal link timing
}

static void ota_task(void *arg) {
    (void)arg;
    static uint8_t chunk[1024];
    uint32_t written = 0, next_ack = OTA_ACK_STEP;
    const char *err = "unknown";
    bool ended = false;
    for (;;) {
        if (s_ota_abort_req) { err = "aborted"; break; }
        size_t n = xStreamBufferReceive(s_ota_buf, chunk, sizeof(chunk), pdMS_TO_TICKS(100));
        if (n > 0) {
            if (written + n > s_ota_size) { err = "too_much_data"; break; }
            s_crumb = CR_OTA;
            if (esp_ota_write(s_ota_handle, chunk, n) != ESP_OK) { err = "write_failed"; break; }
            written += n;
            if (written >= next_ack || written == s_ota_size) {
                send_line_to(s_ota_src, "WD:OTA ack=%lu", (unsigned long)written);
                next_ack = written + OTA_ACK_STEP;
            }
        }
        if (s_ota_end_req && xStreamBufferIsEmpty(s_ota_buf)) {
            if (written != s_ota_size) { err = "short_image"; break; }
            ended = true;   // esp_ota_end releases the handle whatever it returns
            if (esp_ota_end(s_ota_handle) != ESP_OK) { err = "invalid_image"; break; }
            if (esp_ota_set_boot_partition(s_ota_part) != ESP_OK) { err = "set_boot_failed"; break; }
            send_line_to(s_ota_src, "WD:OTA done");
            ESP_LOGI(TAG, "update written (%lu bytes) — restarting", (unsigned long)written);
            vTaskDelay(pdMS_TO_TICKS(800));
            esp_restart();
        }
    }
    if (!ended) esp_ota_abort(s_ota_handle);
    send_line_to(s_ota_src, "WD:OTA error=%s", err);
    ESP_LOGW(TAG, "update failed: %s", err);
    ota_cleanup();
    vTaskDelete(NULL);
}

static void usb_arm_raw(uint8_t sink, uint32_t size);

static void ota_begin(const char *args) {
    const uint8_t src = s_cmd_src;
    if (s_ota_active) { send_line_to(src, "WD:OTA error=busy"); return; }
    unsigned long size = strtoul(args, NULL, 10);
    s_ota_part = esp_ota_get_next_update_partition(NULL);
    if (!s_ota_part) { send_line_to(src, "WD:OTA error=no_update_slot"); return; }
    if (size == 0 || size > s_ota_part->size) { send_line_to(src, "WD:OTA error=bad_size"); return; }
    stream_stop();
    if (esp_ota_begin(s_ota_part, OTA_WITH_SEQUENTIAL_WRITES, &s_ota_handle) != ESP_OK) {
        send_line_to(src, "WD:OTA error=begin_failed"); return;
    }
    if (!s_ota_buf) s_ota_buf = xStreamBufferCreate(OTA_BUF_BYTES, 1);
    else xStreamBufferReset(s_ota_buf);
    if (!s_ota_buf) { esp_ota_abort(s_ota_handle); send_line_to(src, "WD:OTA error=no_memory"); return; }
    s_ota_size = (uint32_t)size;
    s_ota_src = src;
    s_ota_end_req = false;
    s_ota_abort_req = false;
    s_ota_active = true;
    if (xTaskCreate(ota_task, "ota", 6144, NULL, 4, &s_ota_task) != pdPASS) {
        esp_ota_abort(s_ota_handle);
        ota_cleanup();
        send_line_to(src, "WD:OTA error=no_task");
        return;
    }
    if (src != SINK_BLE) usb_arm_raw(src, s_ota_size);
    else request_link_params(true);   // faster link timing while the image transfers
    ESP_LOGI(TAG, "update started: %lu bytes → %s", size, s_ota_part->label);
    send_line_to(src, "WD:OTA ready window=%u", (unsigned)OTA_WINDOW);
}

static int on_ota_write(uint16_t conn, uint16_t attr, struct ble_gatt_access_ctxt *ctxt, void *arg) {
    (void)conn; (void)attr; (void)arg;
    if (ctxt->op != BLE_GATT_ACCESS_OP_WRITE_CHR) return BLE_ATT_ERR_UNLIKELY;
    if (!s_ota_active || !s_ota_buf || s_ota_src != SINK_BLE) return BLE_ATT_ERR_WRITE_NOT_PERMITTED;
    uint8_t buf[512];
    uint16_t got = 0;
    if (ble_hs_mbuf_to_flat(ctxt->om, buf, sizeof(buf), &got) != 0) return BLE_ATT_ERR_UNLIKELY;
    if (xStreamBufferSend(s_ota_buf, buf, got, 0) != got) s_ota_abort_req = true;   // phone ignored the window
    return 0;
}

static void ota_mark_valid_if_pending(void) {
    esp_ota_img_states_t st;
    const esp_partition_t *run = esp_ota_get_running_partition();
    if (run && esp_ota_get_state_partition(run, &st) == ESP_OK && st == ESP_OTA_IMG_PENDING_VERIFY) {
        esp_ota_mark_app_valid_cancel_rollback();
        ESP_LOGI(TAG, "new firmware confirmed");
    }
}

// ─── Boot diagnostics ──────────────────────────────────────────────────────
// Each boot saves how far it got (NVS, shared by both app slots), so after a hang, crash or rollback the next
// boot can report it. Freshly updated firmware that isn't up within BOOT_WATCHDOG_S restarts itself, and the
// bootloader then rolls back to the previous slot.
enum { STAGE_NONE = 0, STAGE_STORAGE, STAGE_LED, STAGE_WIFI, STAGE_BLUETOOTH, STAGE_READY, STAGE_WATCHDOG };
#define BOOT_WATCHDOG_S 30

static esp_timer_handle_t s_boot_wd;

static const char *reset_reason_key(esp_reset_reason_t r) {
    switch (r) {
    case ESP_RST_POWERON:   return "power_on";
    case ESP_RST_EXT:       return "reset_pin";
    case ESP_RST_SW:        return "software";
    case ESP_RST_PANIC:     return "crash";
    case ESP_RST_INT_WDT:
    case ESP_RST_TASK_WDT:
    case ESP_RST_WDT:       return "watchdog";
    case ESP_RST_BROWNOUT:  return "brownout";
    case ESP_RST_DEEPSLEEP: return "deep_sleep";
    default:                return "other";
    }
}

static const char *stage_name(uint8_t s) {
    switch (s) {
    case STAGE_STORAGE:   return "storage";
    case STAGE_LED:       return "led";
    case STAGE_WIFI:      return "wifi";
    case STAGE_BLUETOOTH: return "bluetooth";
    case STAGE_READY:     return "ready";
    case STAGE_WATCHDOG:  return "boot_watchdog";
    default:              return "none";
    }
}

static const char *image_state_name(esp_ota_img_states_t s) {
    switch (s) {
    case ESP_OTA_IMG_NEW:            return "new";
    case ESP_OTA_IMG_PENDING_VERIFY: return "trial";
    case ESP_OTA_IMG_VALID:          return "confirmed";
    case ESP_OTA_IMG_INVALID:        return "invalid";
    case ESP_OTA_IMG_ABORTED:        return "aborted";
    default:                         return "undefined";
    }
}

static void boot_stage(uint8_t stage) {
    nvs_handle_t h;
    if (nvs_open("iosesp", NVS_READWRITE, &h) != ESP_OK) return;
    nvs_set_u8(h, "stage", stage);
    nvs_set_str(h, "stfw", FW_VERSION);
    nvs_commit(h);
    nvs_close(h);
}

static void boot_watchdog_fire(void *arg) {
    (void)arg;
    esp_ota_img_states_t st;
    const esp_partition_t *run = esp_ota_get_running_partition();
    if (run && esp_ota_get_state_partition(run, &st) == ESP_OK && st == ESP_OTA_IMG_PENDING_VERIFY) {
        boot_stage(STAGE_WATCHDOG);
        esp_restart();   // still on trial → the bootloader rolls back to the previous firmware
    }
}

static const char *crumb_name(uint8_t c) {
    switch (c) {
    case CR_SCAN:    return "wifi_scan";
    case CR_RESULTS: return "wifi_results";
    case CR_SEND_AP: return "sending_aps";
    case CR_BT:      return "bt_scan";
    case CR_CAP:     return "capture";
    case CR_OTA:     return "ota_write";
    case CR_CMD:     return "command";
    case CR_GPS:     return "gps";
    default:         return "idle";
    }
}

/// WD:CRASH from the record the panic handler left in RTC memory (lost on power loss, kept across a crash reset).
static void crash_report_build(void) {
    esp_reset_reason_t r = esp_reset_reason();
    bool bad = r == ESP_RST_PANIC || r == ESP_RST_INT_WDT || r == ESP_RST_TASK_WDT || r == ESP_RST_WDT;
    if (bad && s_crash.magic == CRASH_MAGIC) {
        char reason[sizeof(s_crash.reason)];
        size_t i = 0;
        for (; i + 1 < sizeof(reason) && s_crash.reason[i]; i++) {
            char c = s_crash.reason[i];
            reason[i] = (c == ' ' || c == '=') ? '_' : (c < 32 || c > 126) ? '?' : c;
        }
        reason[i] = '\0';
        s_crash.task[sizeof(s_crash.task) - 1] = '\0';
        snprintf(s_crash_line, sizeof(s_crash_line),
                 "WD:CRASH kind=%s reason=%s task=%s pc=0x%08lx core=%u up_ms=%lu last=%s ch=%u heap_min=%lu",
                 s_crash.kind == CK_STACK ? "stack_overflow" : "panic", reason[0] ? reason : "?",
                 s_crash.task[0] ? s_crash.task : "?", (unsigned long)s_crash.pc, (unsigned)s_crash.core,
                 (unsigned long)s_crash.up_ms, crumb_name(s_crash.crumb), (unsigned)s_crash.ch,
                 (unsigned long)s_crash.heap_min);
    } else if (bad) {
        snprintf(s_crash_line, sizeof(s_crash_line), "WD:CRASH kind=%s reason=unrecorded",
                 r == ESP_RST_PANIC ? "panic" : "watchdog");
    }
    if (s_crash_line[0]) ESP_LOGW(TAG, "%s", s_crash_line);
    s_crash.magic = 0;
}

/// Call right after NVS is up: reads the previous boot's progress, counts this boot, builds the WD:BOOT line,
/// and arms the boot watchdog when this firmware is on trial after an update.
static void boot_diag_begin(void) {
    uint8_t prev_stage = STAGE_NONE;
    char prev_fw[16] = "?";
    uint32_t boots = 0;
    nvs_handle_t h;
    if (nvs_open("iosesp", NVS_READWRITE, &h) == ESP_OK) {
        size_t len = sizeof(prev_fw);
        nvs_get_u8(h, "stage", &prev_stage);
        if (nvs_get_str(h, "stfw", prev_fw, &len) != ESP_OK) strcpy(prev_fw, "?");
        nvs_get_u32(h, "boots", &boots);
        boots++;
        nvs_set_u32(h, "boots", boots);
        nvs_commit(h);
        nvs_close(h);
    }
    const esp_partition_t *run = esp_ota_get_running_partition();
    esp_ota_img_states_t st = ESP_OTA_IMG_UNDEFINED;
    if (run) esp_ota_get_state_partition(run, &st);
    const esp_partition_t *bad = esp_ota_get_last_invalid_partition();
    snprintf(s_boot_line, sizeof(s_boot_line),
             "WD:BOOT fw=%s slot=%s image=%s reset=%s boots=%lu prev_fw=%s prev_stage=%s rolled_back=%s",
             FW_VERSION, run ? run->label : "?", image_state_name(st),
             reset_reason_key(esp_reset_reason()), (unsigned long)boots, prev_fw, stage_name(prev_stage),
             bad ? bad->label : "none");
    ESP_LOGI(TAG, "%s", s_boot_line);
    crash_report_build();
    boot_stage(STAGE_STORAGE);
    if (st == ESP_OTA_IMG_PENDING_VERIFY) {
        const esp_timer_create_args_t args = { .callback = boot_watchdog_fire, .name = "boot_wd" };
        if (esp_timer_create(&args, &s_boot_wd) == ESP_OK)
            esp_timer_start_once(s_boot_wd, (uint64_t)BOOT_WATCHDOG_S * 1000000ULL);
    }
}

// ─── Terminal commands (PROTOCOL.md "Commands") ────────────────────────────
static bool apply_channel_list(const char *list) {
    uint8_t chans[MAX_CHANNELS];
    size_t count = parse_channel_list(list, chans);
    if (count == 0) return false;
    portENTER_CRITICAL(&s_plan_lock);
    memcpy(s_plan, chans, count);
    s_plan_n = count;
    portEXIT_CRITICAL(&s_plan_lock);
    if (s_streaming) send_plan_line();
    return true;
}

static void led_pref_save(bool on) {
    nvs_handle_t h;
    if (nvs_open("iosesp", NVS_READWRITE, &h) != ESP_OK) return;
    nvs_set_u8(h, "led", on ? 1 : 0);
    nvs_commit(h);
    nvs_close(h);
}

static bool led_pref_load(void) {
    nvs_handle_t h;
    uint8_t v = 1;
    if (nvs_open("iosesp", NVS_READONLY, &h) == ESP_OK) { nvs_get_u8(h, "led", &v); nvs_close(h); }
    return v != 0;
}

static const char *reset_reason_name(esp_reset_reason_t r) {
    switch (r) {
    case ESP_RST_POWERON:  return "power-on";
    case ESP_RST_EXT:      return "reset pin";
    case ESP_RST_SW:       return "software restart";
    case ESP_RST_PANIC:    return "crash";
    case ESP_RST_INT_WDT:
    case ESP_RST_TASK_WDT:
    case ESP_RST_WDT:      return "watchdog";
    case ESP_RST_BROWNOUT: return "brownout (low power)";
    case ESP_RST_DEEPSLEEP:return "deep sleep";
    default:               return "other";
    }
}

static void cmd_help(void) {
    send_line("WardriveESP %s commands:", FW_VERSION);
    send_line("  info          firmware, chip, memory, uptime");
    send_line("  status        scanning, sweeps, channels");
    send_line("  ch            show channels  ·  ch 1,6,11  ·  ch all");
    send_line("  start | stop  resume or pause scanning");
    send_line("  bt on|off     scan Bluetooth instead of Wi-Fi");
    send_line("  cap on|off    passive capture (handshakes, PMKIDs, clients)");
    send_line("  led on|off    status LED (saved)");
    send_line("  reboot        restart the board");
}

static void cmd_info(void) {
    esp_chip_info_t ci;
    esp_chip_info(&ci);
    uint32_t flash = 0;
    esp_flash_get_size(NULL, &flash);
    uint8_t mac[6] = {0};
    esp_read_mac(mac, ESP_MAC_WIFI_STA);
    const esp_partition_t *run = esp_ota_get_running_partition();
    unsigned long up = (unsigned long)(esp_timer_get_time() / 1000000);
    send_line("WardriveESP %s  ·  %s rev %d.%d  ·  %s", FW_VERSION, CONFIG_IDF_TARGET,
              ci.revision / 100, ci.revision % 100, s_name);
    send_line("Wi-Fi MAC %02x:%02x:%02x:%02x:%02x:%02x", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    send_line("uptime %luh %02lum %02lus  ·  last reset: %s", up / 3600, (up / 60) % 60, up % 60,
              reset_reason_name(esp_reset_reason()));
    send_line("memory %lu KB free (low %lu KB)  ·  flash %lu MB",
              (unsigned long)(esp_get_free_heap_size() / 1024),
              (unsigned long)(esp_get_minimum_free_heap_size() / 1024),
              (unsigned long)(flash / (1024 * 1024)));
    send_line("slot %s  ·  %s  ·  %u channels", run ? run->label : "?",
              s_has_5g ? "2.4 + 5 GHz" : "2.4 GHz", (unsigned)s_supported_n);
    send_line("%s", s_boot_line);
    if (s_crash_line[0]) send_line("%s", s_crash_line);
}

static void cmd_status(void) {
    uint8_t plan[MAX_CHANNELS];
    size_t n = plan_copy(plan);
    char chans[200] = "";
    format_channel_list(chans, 0, sizeof(chans), plan, n);
    uint16_t mtu = s_conn_handle != BLE_HS_CONN_HANDLE_NONE ? ble_att_mtu(s_conn_handle) : 0;
    if (s_role == ROLE_BT) {
        send_line("mode Bluetooth  ·  scanning %s  ·  %lu windows  ·  %lu devices last window",
                  s_bt_running ? "on" : (s_ota_active ? "paused (updating)" : "off"),
                  (unsigned long)s_bt_windows, (unsigned long)s_bt_last);
    } else if (s_role == ROLE_CAP) {
        send_line("mode Capture  ·  scanning %s  ·  %lu APs  ·  %lu handshakes  ·  %lu pmkid  ·  %lu clients",
                  s_cap_running ? "on" : (s_ota_active ? "paused (updating)" : "off"),
                  (unsigned long)s_cap_aps, (unsigned long)s_cap_hs, (unsigned long)s_cap_pmkid,
                  (unsigned long)s_cap_clients);
        send_line("channels %s", n ? chans : "none");
    } else {
        send_line("mode Wi-Fi  ·  scanning %s  ·  %lu sweeps  ·  %lu APs last sweep",
                  s_streaming ? "on" : (s_ota_active ? "paused (updating)" : "off"),
                  (unsigned long)s_sweeps, (unsigned long)s_last_aps);
        send_line("channels %s", n ? chans : "none");
    }
    uint8_t u = s_usb_sessions;
    send_line("BLE MTU %u  ·  USB %s  ·  LED %s", (unsigned)mtu,
              (u & SINK_USB) && (u & SINK_UART) ? "usb+uart" : (u & SINK_USB) ? "usb" : (u & SINK_UART) ? "uart" : "off",
              status_led_enabled() ? "on" : "off");
}

static void cmd_channels(const char *arg) {
    if (!*arg) {
        char sup[200] = "", cur[200] = "";
        uint8_t plan[MAX_CHANNELS];
        size_t n = plan_copy(plan);
        format_channel_list(sup, 0, sizeof(sup), s_supported, s_supported_n);
        format_channel_list(cur, 0, sizeof(cur), plan, n);
        send_line("supported %s", sup);
        send_line("scanning  %s", n ? cur : "none");
        return;
    }
    if (!strcmp(arg, "all")) {
        plan_reset_to_all();
        if (s_streaming) send_plan_line();
        send_line("scanning all %u channels", (unsigned)s_supported_n);
        return;
    }
    if (!apply_channel_list(arg)) { send_line("none of those channels are supported"); cmd_channels(""); return; }
    send_line("ok — the app re-splits channels when a board links or drops");
}

static void cmd_led(const char *arg) {
    if (!strcmp(arg, "on") || !strcmp(arg, "off")) {
        bool on = !strcmp(arg, "on");
        status_led_enable(on);
        led_pref_save(on);
    }
    send_line("LED %s", status_led_enabled() ? "on" : "off");
}

static void reboot_task(void *arg) {
    (void)arg;
    vTaskDelay(pdMS_TO_TICKS(400));
    esp_restart();
}

static void cmd_reboot(void) {
    send_line("rebooting");
    xTaskCreate(reboot_task, "reboot", 2048, NULL, 5, NULL);
}

static SemaphoreHandle_t s_cmd_lock;   // commands from BLE and USB run one at a time

static void exec_command(char *p) {
    char word[16];
    size_t wlen = strcspn(p, " ");
    if (wlen >= sizeof(word)) wlen = sizeof(word) - 1;
    memcpy(word, p, wlen);
    word[wlen] = '\0';
    const char *rest = p + strcspn(p, " ");
    while (*rest == ' ') rest++;

    if (!strcmp(word, "ota")) {
        if (!strncmp(rest, "begin ", 6)) ota_begin(rest + 6);
        else if (!strcmp(rest, "end")) { if (s_ota_active) s_ota_end_req = true; }
        else if (!strcmp(rest, "abort")) { if (s_ota_active) s_ota_abort_req = true; }
    }
    else if (!strcmp(word, "help"))     cmd_help();
    else if (!strcmp(word, "info"))     cmd_info();
    else if (!strcmp(word, "status"))   cmd_status();
    else if (!strcmp(word, "caps"))     send_caps_line();
    else if (!strcmp(word, "ch"))       cmd_channels(rest);
    else if (!strcmp(word, "led"))      cmd_led(rest);
    else if (!strcmp(word, "reboot"))   cmd_reboot();
    else if (!strcmp(word, "stop"))     stream_stop();
    else if (!strcmp(word, "start"))    stream_start();
    else if (!strcmp(word, "bt")) {
        if (!strcmp(rest, "on"))       set_role(ROLE_BT);
        else if (!strcmp(rest, "off")) set_role(ROLE_WIFI);
        else send_line("mode %s  ·  bt on | bt off",
                       s_role == ROLE_BT ? "Bluetooth" : s_role == ROLE_CAP ? "Capture" : "Wi-Fi");
    }
    else if (!strcmp(word, "cap")) {
        if (!strcmp(rest, "on"))       set_role(ROLE_CAP);
        else if (!strcmp(rest, "off")) set_role(ROLE_WIFI);
        else send_line("mode %s  ·  cap on | cap off",
                       s_role == ROLE_CAP ? "Capture" : s_role == ROLE_BT ? "Bluetooth" : "Wi-Fi");
    }
    else if (!strcmp(word, "wdstream")) {
        if (strstr(rest, "stop")) { stream_stop(); return; }
        const char *ch_arg = strstr(rest, "-ch ");
        if (ch_arg && !apply_channel_list(ch_arg + 4)) send_line("WD:ERR reason=no_supported_channels");
        if (strstr(rest, "-promisc") || strstr(rest, "-cap")) { set_role(ROLE_CAP); return; }
        if (strstr(rest, "-bt"))   { set_role(ROLE_BT);   return; }
        if (strstr(rest, "-wifi")) { set_role(ROLE_WIFI); return; }
        stream_start();
    }
    else { send_line("unknown command '%s'", word); cmd_help(); }
}

static void run_command(const uint8_t *text, size_t len, uint8_t src) {
    char cmd[CMD_MAX + 1];
    size_t n = len < CMD_MAX ? len : CMD_MAX;
    memcpy(cmd, text, n);
    cmd[n] = '\0';
    ESP_LOGI(TAG, "cmd: '%s'", cmd);

    char *p = cmd;
    while (*p == ' ') p++;
    size_t plen = strlen(p);
    while (plen && (p[plen - 1] == ' ' || p[plen - 1] == '\r' || p[plen - 1] == '\n')) p[--plen] = '\0';
    if (!*p) return;
    xSemaphoreTake(s_cmd_lock, portMAX_DELAY);
    s_cmd_src = src;
    exec_command(p);
    xSemaphoreGive(s_cmd_lock);
}

static void handle_command(const uint8_t *data, uint16_t len) {
    const uint8_t *text = data;
    uint16_t text_len = len;
    if (len >= FR_HEADER && data[0] == FR_MAGIC_0 && data[1] == FR_MAGIC_1) {
        uint16_t plen = (uint16_t)(data[10] | (data[11] << 8));
        if (FR_HEADER + (size_t)plen <= len) {
            s_reply_id = (uint32_t)data[6] | ((uint32_t)data[7] << 8) | ((uint32_t)data[8] << 16) | ((uint32_t)data[9] << 24);
            if (data[3] == FR_CMD) {
                text = data + FR_HEADER;
                text_len = plen;
                send_ack();
            }
        }
    }
    run_command(text, text_len, SINK_BLE);
}

// ─── USB transport (PROTOCOL.md "USB") ─────────────────────────────────────
// One task serves both ports. A port shows ESP-IDF logs until `wdusb hello`, then carries only protocol lines
// until `wdusb bye`, 60 s of silence, or (native USB) unplug / a host that stops reading.
#define USB_IDLE_MS      60000
#define USB_STALL_MS     5000
#define USB_LOST_MS      1000
#define USB_RAW_IDLE_MS  10000

typedef struct {
    uint8_t  sink;
    bool     up;               // driver installed
    bool     overflow;         // current line is too long; dropped at its newline
    size_t   len;
    char     line[CMD_MAX + 1];
    uint32_t last_rx_ms;
    uint32_t lost_ms;          // first moment the host looked gone, 0 = present
    uint32_t raw_left;         // firmware image bytes still due after WD:OTA ready
} usb_port_t;

static usb_port_t s_usj  = { .sink = SINK_USB };
static usb_port_t s_uart = { .sink = SINK_UART };
static volatile uint32_t s_usj_fail_ms = 0;   // first failed write of the current stall, 0 = writes go through
static TaskHandle_t s_usb_task = NULL;
static vprintf_like_t s_log_orig = NULL;
static SemaphoreHandle_t s_log_lock;
static char s_log_buf[256];

static uint32_t now_ms(void) { return (uint32_t)(esp_timer_get_time() / 1000); }

// Called under s_send_lock. Never blocks: a line that doesn't fit the TX buffer is dropped.
static void usb_emit_locked(uint8_t sinks, const char *buf, size_t n) {
    uint8_t s = sinks & s_usb_sessions;
    (void)s; (void)buf; (void)n;
#if USB_JTAG_LINK
    if ((s & SINK_USB) && s_usj.up) {
        if (usb_serial_jtag_write_bytes(buf, n, 0) == (int)n) s_usj_fail_ms = 0;
        else if (!s_usj_fail_ms) s_usj_fail_ms = now_ms() | 1;
    }
#endif
#if UART_LINK
    if ((s & SINK_UART) && s_uart.up) {
        size_t room = 0;
        if (uart_get_tx_buffer_free_size(LINK_UART, &room) == ESP_OK && room >= n) uart_write_bytes(LINK_UART, buf, n);
    }
#endif
}

// Log text stays off a port while it carries a session; the other port keeps getting it.
static int log_vprintf(const char *fmt, va_list ap) {
    uint8_t sess = s_usb_sessions;
    if (!sess) return s_log_orig ? s_log_orig(fmt, ap) : vprintf(fmt, ap);
    if (xPortInIsrContext() || xTaskGetSchedulerState() != taskSCHEDULER_RUNNING || !s_log_lock) return 0;
    if (xSemaphoreTake(s_log_lock, pdMS_TO_TICKS(50)) != pdTRUE) return 0;
    int n = vsnprintf(s_log_buf, sizeof(s_log_buf), fmt, ap);
    if (n > (int)sizeof(s_log_buf) - 1) n = (int)sizeof(s_log_buf) - 1;
    if (n > 0) {
#if UART_LINK
        if (!(sess & SINK_UART) && s_uart.up) uart_write_bytes(LINK_UART, s_log_buf, (size_t)n);
#endif
#if USB_JTAG_LINK
        if (!(sess & SINK_USB) && s_usj.up) usb_serial_jtag_write_bytes(s_log_buf, (size_t)n, 0);
#endif
    }
    xSemaphoreGive(s_log_lock);
    return n;
}

static usb_port_t *usb_port(uint8_t sink) { return sink == SINK_USB ? &s_usj : &s_uart; }

// Called from ota_begin (in the USB task) once the board is ready for the image.
static void usb_arm_raw(uint8_t sink, uint32_t size) { usb_port(sink)->raw_left = size; }

// Called under s_cmd_lock.
static void usb_session_end(usb_port_t *p, const char *reason) {
    if (!(s_usb_sessions & p->sink)) return;
    if (reason) send_line_to(p->sink, "WD:USB bye reason=%s", reason);
    s_usb_sessions &= (uint8_t)~p->sink;
    if (p->sink == SINK_USB) s_usj_fail_ms = 0;
    if (s_ota_active && s_ota_src == p->sink) s_ota_abort_req = true;
    p->raw_left = 0;
    if (!host_linked()) {
        s_switch_pending = false;
        stream_stop();
        s_role = ROLE_WIFI;
        plan_reset_to_all();
    }
    ESP_LOGI(TAG, "%s session closed (%s)", sink_name(p->sink), reason ? reason : "host gone");
}

// Called under s_cmd_lock.
static void usb_hello(usb_port_t *p) {
    if (!(s_usb_sessions & p->sink)) {
        ESP_LOGI(TAG, "%s session open", sink_name(p->sink));
        if (!host_linked()) {
            s_role = ROLE_WIFI;
            s_switch_pending = false;
            plan_reset_to_all();
        }
        if (p->sink == SINK_USB) s_usj_fail_ms = 0;
        p->lost_ms = 0;
        s_usb_sessions |= p->sink;
    }
    host_joined(p->sink);
}

static void usb_line(usb_port_t *p) {
    p->line[p->len] = '\0';
    char *s = p->line;
    while (*s == ' ') s++;
    if (!strncmp(s, "wdusb", 5) && (s[5] == '\0' || s[5] == ' ')) {
        const char *arg = s + 5;
        while (*arg == ' ') arg++;
        bool in_session = s_usb_sessions & p->sink;
        xSemaphoreTake(s_cmd_lock, portMAX_DELAY);
        if (!strncmp(arg, "hello", 5)) usb_hello(p);
        else if (in_session && !strncmp(arg, "ping", 4)) send_line_to(p->sink, "WD:USB pong");
        else if (in_session && !strncmp(arg, "bye", 3)) usb_session_end(p, "host");
        xSemaphoreGive(s_cmd_lock);
        return;
    }
    if (s_usb_sessions & p->sink) run_command((const uint8_t *)s, strlen(s), p->sink);
}

static void usb_rx(usb_port_t *p, const uint8_t *buf, size_t n) {
    p->last_rx_ms = now_ms();
    for (size_t i = 0; i < n;) {
        if (p->raw_left) {
            size_t take = n - i < p->raw_left ? n - i : p->raw_left;
            if (s_ota_active && s_ota_src == p->sink && s_ota_buf &&
                xStreamBufferSend(s_ota_buf, buf + i, take, pdMS_TO_TICKS(2000)) != take)
                s_ota_abort_req = true;   // host ignored the window
            p->raw_left -= take;
            i += take;
            continue;
        }
        char c = (char)buf[i++];
        if (c == '\n' || c == '\r') {
            if (p->len && !p->overflow) usb_line(p);
            p->len = 0;
            p->overflow = false;
        } else if (p->len < CMD_MAX) {
            p->line[p->len++] = c;
        } else {
            p->overflow = true;
        }
    }
}

static void usb_watch(usb_port_t *p, uint32_t now, bool gone) {
    if (p->raw_left && now - p->last_rx_ms > USB_RAW_IDLE_MS) {
        p->raw_left = 0;
        if (s_ota_active && s_ota_src == p->sink) s_ota_abort_req = true;
    }
    if (!(s_usb_sessions & p->sink)) return;
    if (!gone) p->lost_ms = 0;
    else if (!p->lost_ms) p->lost_ms = now | 1;
    bool lost = p->lost_ms && now - p->lost_ms > USB_LOST_MS;
    bool idle = now - p->last_rx_ms > USB_IDLE_MS;
    if (!lost && !idle) return;
    xSemaphoreTake(s_cmd_lock, portMAX_DELAY);
    usb_session_end(p, lost ? NULL : "idle");
    xSemaphoreGive(s_cmd_lock);
}

static void usb_task(void *arg) {
    (void)arg;
    static uint8_t buf[512];
    for (;;) {
#if USB_JTAG_LINK
        if (s_usj.up) {
            int n = usb_serial_jtag_read_bytes(buf, sizeof(buf), pdMS_TO_TICKS(10));
            if (n > 0) usb_rx(&s_usj, buf, (size_t)n);
        } else {
            vTaskDelay(pdMS_TO_TICKS(10));
        }
#else
        vTaskDelay(pdMS_TO_TICKS(10));
#endif
#if UART_LINK
        size_t avail = 0;
        while (s_uart.up && uart_get_buffered_data_len(LINK_UART, &avail) == ESP_OK && avail) {
            int m = uart_read_bytes(LINK_UART, buf, avail < sizeof(buf) ? avail : sizeof(buf), 0);
            if (m <= 0) break;
            usb_rx(&s_uart, buf, (size_t)m);
        }
#endif
        uint32_t now = now_ms();
#if USB_JTAG_LINK
        uint32_t fail = s_usj_fail_ms;
        usb_watch(&s_usj, now, !usb_serial_jtag_is_connected() || (fail && now - fail > USB_STALL_MS));
#endif
#if UART_LINK
        usb_watch(&s_uart, now, false);
#endif
    }
}

static void usb_link_start(void) {
    s_log_lock = xSemaphoreCreateMutex();
#if USB_JTAG_LINK
    usb_serial_jtag_driver_config_t ucfg = USB_SERIAL_JTAG_DRIVER_CONFIG_DEFAULT();
    ucfg.tx_buffer_size = 4096;
    ucfg.rx_buffer_size = 1024;
    if (usb_serial_jtag_driver_install(&ucfg) == ESP_OK) {
        usb_serial_jtag_vfs_use_driver();
        s_usj.up = true;
    } else {
        ESP_LOGW(TAG, "USB-Serial-JTAG link unavailable");
    }
#endif
#if UART_LINK
    if (uart_driver_install(LINK_UART, 2048, 4096, 0, NULL, 0) == ESP_OK) {
        uart_vfs_dev_use_driver(LINK_UART);
        s_uart.up = true;
    } else {
        ESP_LOGW(TAG, "UART0 link unavailable");
    }
#endif
    if (!s_usj.up && !s_uart.up) return;
    s_log_orig = esp_log_set_vprintf(log_vprintf);
    if (xTaskCreate(usb_task, "wd_usb", 8192, NULL, 4, &s_usb_task) != pdPASS) ESP_LOGE(TAG, "USB task create failed");
}

static int on_command_write(uint16_t conn, uint16_t attr, struct ble_gatt_access_ctxt *ctxt, void *arg) {
    (void)conn; (void)attr; (void)arg;
    if (ctxt->op != BLE_GATT_ACCESS_OP_WRITE_CHR) return BLE_ATT_ERR_UNLIKELY;
    uint8_t buf[256];
    uint16_t got = 0;
    if (ble_hs_mbuf_to_flat(ctxt->om, buf, sizeof(buf), &got) != 0) return BLE_ATT_ERR_UNLIKELY;
    handle_command(buf, got);
    return 0;
}

static int on_tx_access(uint16_t conn, uint16_t attr, struct ble_gatt_access_ctxt *ctxt, void *arg) {
    (void)conn; (void)attr; (void)ctxt; (void)arg;
    return 0;
}

static const struct ble_gatt_chr_def CHARACTERISTICS[] = {
    { .uuid = &RX_UUID.u,   .access_cb = on_command_write, .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP },
    { .uuid = &TX_UUID.u,   .access_cb = on_tx_access,     .flags = BLE_GATT_CHR_F_NOTIFY, .val_handle = &s_tx_val_handle },
    { .uuid = &CTRL_UUID.u, .access_cb = on_command_write, .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP },
    { .uuid = &OTA_UUID.u,  .access_cb = on_ota_write,     .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP },
    { 0 },
};
static const struct ble_gatt_svc_def SERVICES[] = {
    { .type = BLE_GATT_SVC_TYPE_PRIMARY, .uuid = &SVC_UUID.u, .characteristics = CHARACTERISTICS },
    { 0 },
};

static void start_advertising(void) {
    struct ble_hs_adv_fields adv = {0};
    adv.flags = BLE_HS_ADV_F_DISC_GEN | BLE_HS_ADV_F_BREDR_UNSUP;
    adv.uuids128 = (ble_uuid128_t *)&SVC_UUID;
    adv.num_uuids128 = 1;
    adv.uuids128_is_complete = 1;
    if (ble_gap_adv_set_fields(&adv) != 0) { ESP_LOGE(TAG, "adv fields rejected"); return; }

    struct ble_hs_adv_fields scan_rsp = {0};
    scan_rsp.name = (const uint8_t *)s_name;
    scan_rsp.name_len = strlen(s_name);
    scan_rsp.name_is_complete = 1;
    (void)ble_gap_adv_rsp_set_fields(&scan_rsp);

    struct ble_gap_adv_params params = { .conn_mode = BLE_GAP_CONN_MODE_UND, .disc_mode = BLE_GAP_DISC_MODE_GEN };
    if (ble_gap_adv_start(s_own_addr_type, NULL, BLE_HS_FOREVER, &params, on_gap_event, NULL) != 0) {
        ESP_LOGE(TAG, "advertising failed to start");
        return;
    }
    status_led_set(STATUS_LED_ADVERTISING);
    ESP_LOGI(TAG, "advertising as '%s'", s_name);
}

static int on_gap_event(struct ble_gap_event *event, void *arg) {
    (void)arg;
    switch (event->type) {
    case BLE_GAP_EVENT_CONNECT:
        if (event->connect.status != 0) { start_advertising(); return 0; }
        s_conn_handle = event->connect.conn_handle;
        s_conns++;
        s_notify_enabled = false;
        if (!s_usb_sessions) {
            s_role = ROLE_WIFI;
            s_switch_pending = false;
            plan_reset_to_all();
        }
        ESP_LOGI(TAG, "phone connected");
        request_link_params(false);
        return 0;

    case BLE_GAP_EVENT_DISCONNECT:
        ESP_LOGI(TAG, "phone disconnected (reason %d)", event->disconnect.reason);
        s_last_disc_reason = (uint32_t)event->disconnect.reason;
        s_last_disc_ms = (uint32_t)(esp_timer_get_time() / 1000);
        s_conn_handle = BLE_HS_CONN_HANDLE_NONE;
        s_notify_enabled = false;
        if (s_ota_active && s_ota_src == SINK_BLE) s_ota_abort_req = true;
        if (!s_usb_sessions) {
            s_switch_pending = false;
            stream_stop();
            s_role = ROLE_WIFI;
            plan_reset_to_all();
        }
        start_advertising();
        return 0;

    case BLE_GAP_EVENT_SUBSCRIBE:
        if (event->subscribe.attr_handle != s_tx_val_handle) return 0;
        s_notify_enabled = event->subscribe.cur_notify;
        ESP_LOGI(TAG, "notifications %s", s_notify_enabled ? "on" : "off");
        if (s_notify_enabled) host_joined(SINK_BLE);
        else if (!s_usb_sessions) stream_stop();
        return 0;

    case BLE_GAP_EVENT_MTU:
        ESP_LOGI(TAG, "MTU %u", event->mtu.value);
        return 0;

    case BLE_GAP_EVENT_CONN_UPDATE:
        send_conn_line(event->conn_update.status);
        return 0;

    default:
        return 0;
    }
}

static void on_ble_sync(void) {
    if (ble_hs_util_ensure_addr(0) != 0) { ESP_LOGE(TAG, "no BLE address"); return; }
    if (ble_hs_id_infer_auto(0, &s_own_addr_type) != 0) s_own_addr_type = BLE_OWN_ADDR_PUBLIC;
    uint8_t addr[6] = {0};
    if (ble_hs_id_copy_addr(s_own_addr_type, addr, NULL) == 0)
        snprintf(s_name, sizeof(s_name), NAME_PREFIX "-%02X%02X", addr[1], addr[0]);
    (void)ble_svc_gap_device_name_set(s_name);
    start_advertising();
    ota_mark_valid_if_pending();   // Wi-Fi + BLE came up: keep this firmware (otherwise the next boot rolls back)
    if (s_boot_wd) esp_timer_stop(s_boot_wd);
    boot_stage(STAGE_READY);
}

static void on_ble_reset(int reason) { ESP_LOGW(TAG, "BLE host reset: %d", reason); }

static void ble_host_task(void *param) {
    (void)param;
    nimble_port_run();
    nimble_port_freertos_deinit();
}

static void wifi_bring_up(void) {
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_wifi_set_storage(WIFI_STORAGE_RAM));
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_start());
    // Crank the radio to its hardware/regulatory ceiling. Wardriving's 2.4 GHz scan is ACTIVE — the board sends
    // probe requests — so a stronger TX makes distant APs hear the probe and reply, catching more of them per
    // sweep. Only 2.4 GHz probes use it: 5 GHz (DFS 52-144 included) is passive and never transmits. The driver
    // clamps the request to what the chip and country setting allow (units of 0.25 dBm; 84 is the API max). RX
    // sensitivity is fixed silicon on these ESP32 parts — there is no external PA/LNA to enable — so this is the
    // one knob that widens coverage. Set after esp_wifi_start(), which resets it to the default.
    if (esp_wifi_set_max_tx_power(84) == ESP_OK) {
        int8_t p = 0;   // 0.25 dBm units; print as whole + quarter dBm without %f (newlib-nano may drop it)
        if (esp_wifi_get_max_tx_power(&p) == ESP_OK)
            ESP_LOGI(TAG, "max TX power %d units (%d.%02d dBm)", p, p / 4, (p % 4) * 25);
    }
#if SOC_WIFI_SUPPORT_5G
    esp_err_t err = esp_wifi_set_band_mode(WIFI_BAND_MODE_AUTO);
    s_has_5g = (err == ESP_OK);
    if (!s_has_5g) ESP_LOGW(TAG, "dual-band mode unavailable (%s), 2.4 GHz only", esp_err_to_name(err));
#endif
    open_all_channels();
    build_supported_channels();
    plan_reset_to_all();
    ESP_LOGI(TAG, "%s: %u channels (%s)", CONFIG_IDF_TARGET, (unsigned)s_supported_n, s_has_5g ? "2.4 + 5 GHz" : "2.4 GHz");
}

static TaskHandle_t s_gps_task = NULL;

static long stack_free(TaskHandle_t t) { return t ? (long)uxTaskGetStackHighWaterMark(t) : -1; }

/// WD:HEALTH every 15 s while a host listens: memory, the least stack each task has had left (bytes), the link.
static void health_task(void *arg) {
    (void)arg;
    uint32_t last = 0;
    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(1000));
        s_heap_min_seen = esp_get_minimum_free_heap_size();
        uint32_t now = (uint32_t)(esp_timer_get_time() / 1000);
        bool listening = (s_conn_handle != BLE_HS_CONN_HANDLE_NONE && s_notify_enabled) || s_usb_sessions;
        if (!listening || now - last < 15000) continue;
        last = now;
        long scan = stack_free(s_scan_task), bt = stack_free(s_bt_task), cap = stack_free(s_cap_task);
        long gps = stack_free(s_gps_task), usb = stack_free(s_usb_task);
        long self = (long)uxTaskGetStackHighWaterMark(NULL);   // NULL = this task
        const char *low = (scan >= 0 && scan < 768) ? "wd_scan" : (bt >= 0 && bt < 768) ? "wd_bt" :
                          (cap >= 0 && cap < 768) ? "wd_cap" : (gps >= 0 && gps < 768) ? "wd_gps" :
                          (usb >= 0 && usb < 768) ? "wd_usb" : "none";
        send_line("WD:HEALTH up=%lu heap=%lu heap_min=%lu largest=%lu stack_scan=%ld stack_bt=%ld stack_cap=%ld "
                  "stack_gps=%ld stack_usb=%ld stack_health=%ld low_stack=%s mtu=%u last=%s",
                  (unsigned long)(now / 1000), (unsigned long)esp_get_free_heap_size(),
                  (unsigned long)s_heap_min_seen,
                  (unsigned long)heap_caps_get_largest_free_block(MALLOC_CAP_8BIT), scan, bt, cap, gps, usb, self, low,
                  (unsigned)(s_conn_handle != BLE_HS_CONN_HANDLE_NONE ? ble_att_mtu(s_conn_handle) : 0),
                  crumb_name(s_crumb));
    }
}

void app_main(void) {
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }
    s_send_lock = xSemaphoreCreateMutex();
    s_cmd_lock = xSemaphoreCreateMutex();
    boot_diag_begin();
    status_led_init();
    status_led_enable(led_pref_load());
    boot_stage(STAGE_LED);
    wifi_bring_up();
    boot_stage(STAGE_WIFI);

    ESP_ERROR_CHECK(nimble_port_init());
    ble_svc_gap_init();
    ble_svc_gatt_init();
    ESP_ERROR_CHECK(ble_gatts_count_cfg(SERVICES));
    ESP_ERROR_CHECK(ble_gatts_add_svcs(SERVICES));
    ESP_ERROR_CHECK(ble_svc_gap_device_name_set(s_name));

    ble_hs_cfg.sync_cb = on_ble_sync;
    ble_hs_cfg.reset_cb = on_ble_reset;
    boot_stage(STAGE_BLUETOOTH);   // before the host task starts: on_ble_sync can record STAGE_READY right away
    nimble_port_freertos_init(ble_host_task);
#if CONFIG_WARDRIVEESP_GPS_ENABLE
    // Optional GPS receiver: runs continuously, emitting WD:GPS when it has a fix. A board with nothing wired to
    // the UART simply never parses a sentence, never advertises gps, and costs only an idle blocked read.
    xTaskCreate(gps_task, "wd_gps", 6144, NULL, 4, &s_gps_task);
#endif
    usb_link_start();
    xTaskCreate(health_task, "wd_health", 6144, NULL, 3, NULL);
    ESP_LOGI(TAG, "WardriveESP %s ready", FW_VERSION);
}
