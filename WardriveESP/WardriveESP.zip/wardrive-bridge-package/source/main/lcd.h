// WardriveESP — color status screens over SPI: the Koko Marauder V8's 240x320 ILI9341 and the Marauder Mini v3's
// 128x128 ST7735. Only ever driven once a probe has read the panel's ID; every other board never touches these pins.
// SPDX-License-Identifier: MIT
#pragma once

#include <stdbool.h>
#include <stdint.h>

/// What the dashboard shows, filled by wardrive_bridge.c a few times a second.
typedef struct {
    uint8_t  channel;        // channel being scanned (0 = none)
    char     mode[5];        // "WIFI", "CAP", "BT", "CSI"
    bool     ble, usb;       // who holds the board
    char     holder[17];     // the app's nickname ("" = didn't say)
    uint32_t captures;       // handshakes + PMKIDs this session
    uint32_t bt_devices;     // Bluetooth devices last window (BT mode)
    int      batt_pct;       // -1 = no gauge
} lcd_status_t;

typedef void (*lcd_fill_fn)(lcd_status_t *st);

/// Koko Marauder V8 check: only when a pin of its shared SPI bus already reads pulled up (input-only sense), reads the
/// panel ID over SPI and keeps the bus when it is an ILI9341. Logs what it saw either way.
bool lcd_probe_koko(void);
/// Marauder Mini v3 check: same pulled-up gate, then reads the ST7735's ID (3-wire on the bus's MOSI, then MISO). `stored`:
/// the board was told it is a Mini, which stands in for an ID the panel can't give back (the gate still applies).
bool lcd_probe_mini(bool stored);
/// Splash, then the live dashboard on a low-priority task.
void lcd_start(const char *board, const char *version, lcd_fill_fn fill);
bool lcd_running(void);
/// "240x320" / "128x128" while a screen runs, else "".
const char *lcd_size(void);
/// A Wi-Fi AP sighting (Wi-Fi scan or capture): unique count, "+new" ticker, channel activity.
void lcd_note_ap(const uint8_t *bssid, uint8_t channel);
/// Full-screen flashing banner for `ms` (0 ends it). `soft` banners never replace one already showing.
void lcd_alert(const char *label, uint32_t ms, bool soft);
/// Stealth: panel and backlight off.
void lcd_set_stealth(bool on);
