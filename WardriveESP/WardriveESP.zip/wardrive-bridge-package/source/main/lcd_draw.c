// WardriveESP — the color screens' scenes: boot splash (radar sweep), live dashboard, alert banner, each in a
// 240x320 and a compact 128x128 layout.
// Anti-aliased text from lcd_fonts.h; everything is drawn per 16-row strip, clipped, straight into the wire buffer.
// SPDX-License-Identifier: MIT

#include <stdio.h>
#include <string.h>
#include "lcd_draw.h"
#include "lcd_fonts.h"
#include "lcd_sprites.h"

#define W  s_w
#define H  s_h
#define SH LCD_SH

#define RGB(r, g, b) ((uint16_t)((((r) & 0xF8) << 8) | (((g) & 0xFC) << 3) | ((b) >> 3)))
#define C_BLACK  RGB(0, 0, 0)
#define C_NAVY   RGB(8, 18, 34)
#define C_HEAD0  RGB(12, 28, 50)
#define C_HEAD1  RGB(4, 10, 20)
#define C_PANEL  RGB(14, 24, 38)
#define C_EDGE   RGB(34, 52, 76)
#define C_FAINT  RGB(44, 58, 78)
#define C_DIM    RGB(122, 142, 164)
#define C_WHITE  RGB(255, 255, 255)
#define C_CYAN   RGB(0, 229, 255)
#define C_TEAL   RGB(0, 96, 120)
#define C_MAG    RGB(255, 46, 214)
#define C_GREEN  RGB(60, 255, 140)
#define C_AMBER  RGB(255, 178, 36)
#define C_YEL    RGB(255, 232, 0)
#define C_BLUE   RGB(86, 146, 255)
#define C_RED    RGB(255, 36, 60)
#define C_BLOOD  RGB(96, 0, 14)
#define C_PINK   RGB(255, 79, 163)
#define C_PLUM   RGB(64, 0, 38)

static uint16_t *s_px;
static int s_y0, s_w = LCD_W, s_h = LCD_H;

// Angle of (dx, dy) in 1/256 turns, counterclockwise from +x with y down (within about a quarter of a step).
static int iatan2(int dy, int dx) {
    int ax = dx < 0 ? -dx : dx, ay = dy < 0 ? -dy : dy;
    if (!ax && !ay) return 0;
    int mx = ax > ay ? ax : ay, mn = ax > ay ? ay : ax;
    int z = mn * 256 / mx;
    int a = (32 * z + 11 * z * (256 - z) / 256) / 256;   // atan(z), 0-32
    if (ay > ax) a = 64 - a;
    if (dx < 0) a = 128 - a;
    if (dy < 0) a = 256 - a;
    return a & 255;
}

// ── pixels ──
static inline uint16_t sw(uint16_t c) { return (uint16_t)((c >> 8) | (c << 8)); }
static inline bool in_strip(int x, int y) { return (unsigned)x < (unsigned)W && y >= s_y0 && y < s_y0 + SH; }

static uint16_t mix(uint16_t a, uint16_t b, int t, int n) {   // a → b, step t of n
    if (n <= 0 || t >= n) return b;
    if (t <= 0) return a;
    int r = ((a >> 11) * (n - t) + (b >> 11) * t) / n, g = (((a >> 5) & 63) * (n - t) + ((b >> 5) & 63) * t) / n,
        bl = ((a & 31) * (n - t) + (b & 31) * t) / n;
    return (uint16_t)((r << 11) | (g << 5) | bl);
}

// `a` is coverage 0-16.
static inline void blend(int x, int y, uint16_t c, int a) {
    if (a <= 0 || !in_strip(x, y)) return;
    uint16_t *p = &s_px[(y - s_y0) * W + x];
    *p = a >= 16 ? sw(c) : sw(mix(sw(*p), c, a, 16));
}

static void fill(int x, int y, int w, int h, uint16_t c) {
    if (x < 0) { w += x; x = 0; }
    if (x + w > W) w = W - x;
    int ya = y < s_y0 ? s_y0 : y, yb = y + h > s_y0 + SH ? s_y0 + SH : y + h;
    if (w <= 0 || ya >= yb) return;
    uint16_t v = sw(c);
    for (int j = ya; j < yb; j++) {
        uint16_t *row = s_px + (j - s_y0) * W + x;
        for (int i = 0; i < w; i++) row[i] = v;
    }
}
static void fill_a(int x, int y, int w, int h, uint16_t c, int a) {
    int ya = y < s_y0 ? s_y0 : y, yb = y + h > s_y0 + SH ? s_y0 + SH : y + h;
    for (int j = ya; j < yb; j++) for (int i = x; i < x + w; i++) blend(i, j, c, a);
}
// Vertical gradient c1 (row y) → c2 (row y + h - 1).
static void vgrad(int x, int y, int w, int h, uint16_t c1, uint16_t c2) {
    int ya = y < s_y0 ? s_y0 : y, yb = y + h > s_y0 + SH ? s_y0 + SH : y + h;
    for (int j = ya; j < yb; j++) fill(x, j, w, 1, mix(c1, c2, j - y, h - 1));
}
static void hgrad(int x, int y, int w, int h, uint16_t c1, uint16_t c2) {
    if (y + h <= s_y0 || y >= s_y0 + SH) return;
    for (int i = 0; i < w; i++) fill(x + i, y, 1, h, mix(c1, c2, i, w - 1));
}

// Coverage (0-16, 4×4 samples) of pixel (i, j) by a rounded rectangle.
static int rr_cov(int i, int j, int x, int y, int w, int h, int r) {
    if (i < x || i >= x + w || j < y || j >= y + h) return 0;
    int cx = i < x + r ? x + r : i >= x + w - r ? x + w - r : -1;
    int cy = j < y + r ? y + r : j >= y + h - r ? y + h - r : -1;
    if (cx < 0 || cy < 0) return 16;
    int n = 0, rr = r * 8 * r * 8;
    for (int sy = 0; sy < 4; sy++)
        for (int sx = 0; sx < 4; sx++) {
            int dx = i * 8 + sx * 2 + 1 - cx * 8, dy = j * 8 + sy * 2 + 1 - cy * 8;
            if (dx * dx + dy * dy <= rr) n++;
        }
    return n;
}
static void rrect(int x, int y, int w, int h, int r, uint16_t c, int a) {
    int ya = y < s_y0 ? s_y0 : y, yb = y + h > s_y0 + SH ? s_y0 + SH : y + h;
    for (int j = ya; j < yb; j++)
        for (int i = x; i < x + w; i++) {
            int cov = rr_cov(i, j, x, y, w, h, r);
            if (cov) blend(i, j, c, cov * a / 16);
        }
}
static void rrect_line(int x, int y, int w, int h, int r, int t, uint16_t c, int a) {
    int ya = y < s_y0 ? s_y0 : y, yb = y + h > s_y0 + SH ? s_y0 + SH : y + h;
    for (int j = ya; j < yb; j++)
        for (int i = x; i < x + w; i++) {
            if (i >= x + t + r && i < x + w - t - r && j >= y + t && j < y + h - t) { i = x + w - t - r - 1; continue; }
            int cov = rr_cov(i, j, x, y, w, h, r) - rr_cov(i, j, x + t, y + t, w - 2 * t, h - 2 * t, r > t ? r - t : 0);
            if (cov > 0) blend(i, j, c, cov * a / 16);
        }
}
// Disc (th = 0) or ring of thickness th, anti-aliased.
static void circle(int cx, int cy, int r, int th, uint16_t c, int a) {
    if (cy + r < s_y0 || cy - r >= s_y0 + SH) return;
    int ya = cy - r - 1 < s_y0 ? s_y0 : cy - r - 1, yb = cy + r + 1 >= s_y0 + SH ? s_y0 + SH - 1 : cy + r + 1;
    int ro = r * 8 * r * 8, ri = th ? (r - th) * 8 * (r - th) * 8 : -1;
    for (int j = ya; j <= yb; j++)
        for (int i = cx - r - 1; i <= cx + r + 1; i++) {
            int n = 0;
            for (int sy = 0; sy < 4; sy++)
                for (int sx = 0; sx < 4; sx++) {
                    int dx = i * 8 + sx * 2 + 1 - cx * 8 - 4, dy = j * 8 + sy * 2 + 1 - cy * 8 - 4, d = dx * dx + dy * dy;
                    if (d <= ro && d > ri) n++;
                }
            if (n) blend(i, j, c, n * a / 16);
        }
}

// ── text ──
static const lcd_glyph_t *glyph_of(const lcd_font_t *f, char c) {
    if ((uint8_t)c < f->first || (uint8_t)c > f->last) c = '?';
    if ((uint8_t)c < f->first || (uint8_t)c > f->last) return NULL;
    return &f->g[(uint8_t)c - f->first];
}
static int text_w(const lcd_font_t *f, const char *s, int sp) {
    int w = 0;
    for (; *s; s++) { const lcd_glyph_t *g = glyph_of(f, *s); if (g) w += g->adv + sp; }
    return w > 0 ? w - sp : 0;
}
enum { SOLID, VERT, HORIZ };
// Text with its baseline at `base`. VERT shades c1 (cap top) → c2 (baseline), HORIZ c1 (left) → c2 (right end).
static void text_ex(const lcd_font_t *f, int x, int base, const char *s, int sp, uint16_t c1, uint16_t c2, int mode, int a) {
    int top = base - f->ascent, span = text_w(f, s, sp), x0 = x, cap = f->ascent * 3 / 4;
    if (top + f->height <= s_y0 || top >= s_y0 + SH) return;
    for (; *s; s++) {
        const lcd_glyph_t *g = glyph_of(f, *s);
        if (!g) continue;
        int gy = top + g->yo, gx = x + g->xo;
        if (g->w && gy < s_y0 + SH && gy + g->h > s_y0) {
            int ra = s_y0 - gy > 0 ? s_y0 - gy : 0, rb = s_y0 + SH - gy < g->h ? s_y0 + SH - gy : g->h;
            for (int row = ra; row < rb; row++) {
                uint16_t c = c1;
                if (mode == VERT) c = mix(c1, c2, gy + row - (base - cap), cap);
                for (int col = 0; col < g->w; col++) {
                    int k = row * g->w + col;
                    int v = (f->bits[g->off + k / 2] >> ((k & 1) ? 0 : 4)) & 15;
                    if (!v) continue;
                    if (mode == HORIZ) c = mix(c1, c2, gx + col - x0, span);
                    blend(gx + col, gy + row, c, (v * a + 7) / 15);
                }
            }
        }
        x += g->adv + sp;
    }
}
static void text(const lcd_font_t *f, int x, int base, const char *s, uint16_t c) { text_ex(f, x, base, s, 0, c, c, SOLID, 16); }
static void text_r(const lcd_font_t *f, int xr, int base, const char *s, uint16_t c) { text(f, xr - text_w(f, s, 0), base, s, c); }
// A soft halo: the text smeared around itself, faint.
static void glow(const lcd_font_t *f, int x, int base, const char *s, uint16_t c, int a) {
    static const int8_t D[][2] = { {-3,0},{3,0},{0,-3},{0,3},{-2,-2},{2,-2},{-2,2},{2,2},{-1,0},{1,0},{0,-1},{0,1} };
    for (size_t i = 0; i < sizeof(D) / sizeof(D[0]); i++) text_ex(f, x + D[i][0], base + D[i][1], s, 0, c, c, SOLID, a);
}

// ── pieces ──
static void background(void) {
    vgrad(0, s_y0, W, SH, mix(C_NAVY, C_BLACK, s_y0, H), mix(C_NAVY, C_BLACK, s_y0 + SH - 1, H));
    for (int y = 8; y < H; y += 16) {   // HUD dot grid
        if (y < s_y0 || y >= s_y0 + SH) continue;
        for (int x = 8; x < W; x += 16) blend(x, y, C_FAINT, 9);
    }
}

static void esp_pill(int x, int y) {
    int pw = text_w(&font_title, "ESP", 0) + 10;
    rrect(x, y, pw, 20, 5, C_CYAN, 16);
    text(&font_title, x + 5, y + 16, "ESP", C_BLACK);
}

static void battery(int pct, int x, int y) {
    if (pct < 0) return;
    if (pct > 100) pct = 100;
    uint16_t c = pct > 40 ? C_GREEN : pct > 15 ? C_AMBER : C_RED;
    rrect_line(x, y, 36, 18, 4, 1, C_DIM, 16);
    rrect(x + 36, y + 5, 3, 8, 1, C_DIM, 16);
    int lw = 32 * pct / 100;
    if (lw > 0) rrect(x + 2, y + 2, lw, 14, 3, mix(c, C_BLACK, 7, 16), 16);
    if (lw > 0) rrect(x + 2, y + 2, lw, 3, 2, c, 10);
    char b[8];
    snprintf(b, sizeof(b), "%d", pct);
    text(&font_small, x + 18 - text_w(&font_small, b, 0) / 2, y + 14, b, C_WHITE);
}

static void header(const lcd_frame_t *f) {
    vgrad(0, 0, W, 42, C_HEAD0, C_HEAD1);
    text_ex(&font_head, 9, 29, "WARDRIVE", 0, C_CYAN, C_MAG, HORIZ, 16);
    esp_pill(9 + text_w(&font_head, "WARDRIVE", 0) + 6, 11);
    battery(f->st.batt_pct, 196, 12);
    hgrad(0, 41, W, 2, C_CYAN, C_MAG);
    int gx = (int)((f->now / 6) % (W + 80)) - 40;   // a glint runs along the edge
    for (int i = -40; i <= 40; i++) {
        int a = 12 - (i < 0 ? -i : i) * 12 / 40;
        blend(gx + i, 41, C_WHITE, a);
        blend(gx + i, 42, C_WHITE, a / 2);
    }
}

static void status_pill(const lcd_frame_t *f) {
    const lcd_status_t *st = &f->st;
    uint16_t c = st->usb ? C_GREEN : st->ble ? C_CYAN : C_AMBER;
    rrect(8, 50, 224, 28, 14, c, 3);
    rrect_line(8, 50, 224, 28, 14, 1, c, 11);
    bool linked = st->usb || st->ble;
    int pulse = linked ? 16 : (int)((f->now / 90) % 16);
    if (!linked && pulse > 8) pulse = 16 - pulse;
    circle(25, 64, 9, 0, c, linked ? 4 : pulse / 2);
    circle(25, 64, 5, 0, c, linked ? 16 : 8 + pulse);
    uint32_t up = (f->now - f->t0) / 1000;
    char b[12];
    if (up < 3600) snprintf(b, sizeof(b), "%lu:%02lu", (unsigned long)(up / 60), (unsigned long)(up % 60));
    else snprintf(b, sizeof(b), "%luh%02lu", (unsigned long)(up / 3600), (unsigned long)((up / 60) % 60));
    int clock_x = 222 - text_w(&font_small, b, 0);
    text(&font_small, clock_x, 69, b, C_DIM);
    const char *what = st->usb ? "USB" : st->ble ? "BLUETOOTH" : "NO PHONE";
    text_ex(&font_mid, 38, 71, what, 1, c, c, SOLID, 16);
    if (linked && st->holder[0]) {
        char h[sizeof(st->holder)];
        strncpy(h, st->holder, sizeof(h) - 1);
        h[sizeof(h) - 1] = 0;
        int hx = 38 + text_w(&font_mid, what, 1) + 7, room = clock_x - 8 - hx;
        if (text_w(&font_mid, h, 0) > room) {   // shortened to fit, with an ellipsis
            char t[sizeof(h) + 3];
            for (size_t n = strlen(h); n > 0; n--) {
                h[n - 1] = 0;
                snprintf(t, sizeof(t), "%s...", h);
                if (text_w(&font_mid, t, 0) <= room) break;
            }
            strncpy(h, t, sizeof(h) - 1);
        }
        text(&font_mid, hx, 71, h, C_WHITE);
    }
}

static void ap_block(const lcd_frame_t *f) {
    fill(10, 87, 3, 11, C_CYAN);
    text_ex(&font_small, 18, 97, "IN RANGE", 1, C_DIM, C_DIM, SOLID, 16);
    char b[24];
    snprintf(b, sizeof(b), "%lu TOTAL", (unsigned long)f->session);
    int tx = 230 - text_w(&font_small, b, 0);
    text(&font_small, tx, 97, b, C_DIM);
    if (f->fresh) {
        snprintf(b, sizeof(b), "+%lu", (unsigned long)f->fresh);
        int pw = text_w(&font_title, b, 1) + 12;
        if (tx - 6 - pw > 18 + text_w(&font_small, "IN RANGE", 1) + 4) {   // only when it fits between the two
            rrect(tx - 6 - pw, 85, pw, 16, 8, C_GREEN, 4);
            rrect_line(tx - 6 - pw, 85, pw, 16, 8, 1, C_GREEN, 14);
            text_ex(&font_title, tx - 6 - pw + 6, 98, b, 1, C_GREEN, C_GREEN, SOLID, 16);
        }
    }
    snprintf(b, sizeof(b), "%lu", (unsigned long)f->live);
    const lcd_font_t *nf = text_w(&font_huge, b, 2) <= W - 20 ? &font_huge : &font_big;
    int base = nf == &font_huge ? 158 : 152;
    glow(nf, 10, base, b, C_TEAL, 3);
    text_ex(nf, 10, base, b, 2, C_WHITE, C_CYAN, VERT, 16);
}

static void tile(int x, int y, const char *label, const char *value, const char *unit, uint16_t accent) {
    rrect(x, y, 112, 36, 7, C_PANEL, 16);
    rrect_line(x, y, 112, 36, 7, 1, C_EDGE, 16);
    rrect(x + 4, y + 8, 3, 20, 1, accent, 16);
    text_ex(&font_small, x + 14, y + 14, label, 1, C_DIM, C_DIM, SOLID, 16);
    text(&font_med, x + 14, y + 32, value, C_WHITE);
    if (unit && *unit) text(&font_small, x + 18 + text_w(&font_med, value, 0), y + 31, unit, accent);
}

static void tiles(const lcd_frame_t *f) {
    const lcd_status_t *st = &f->st;
    char b[16];
    uint16_t mc = !strcmp(st->mode, "BT") ? C_BLUE : !strcmp(st->mode, "CAP") ? C_MAG : !strcmp(st->mode, "CSI") ? C_AMBER : C_CYAN;
    tile(6, 168, "MODE", st->mode[0] ? st->mode : "--", NULL, mc);
    if (st->channel) snprintf(b, sizeof(b), "%u", st->channel);
    else snprintf(b, sizeof(b), "--");
    tile(122, 168, "CHANNEL", b, st->channel ? (st->channel <= 14 ? "2.4 GHz" : "5 GHz") : NULL, C_YEL);
    snprintf(b, sizeof(b), "%lu", (unsigned long)st->captures);
    tile(6, 208, "CAPTURES", b, NULL, st->captures ? C_MAG : C_EDGE);
    snprintf(b, sizeof(b), "%lu", (unsigned long)st->bt_devices);
    tile(122, 208, "BT DEVICES", b, NULL, C_BLUE);
}

static void spectrum(const lcd_frame_t *f) {
    const int base = 296, top = 40;
    hgrad(6, base + 1, 228, 1, C_EDGE, C_EDGE);
    for (int i = 0; i < LCD_ACT_N; i++) {
        int x = i < 14 ? 8 + i * 6 : 96 + (i - 14) * 5, bw = i < 14 ? 5 : 4;
        int h = f->act[i] * top / 250;
        if (i == f->cur) {
            if (h < 4) h = 4;
            vgrad(x, base - h, bw, h, C_YEL, C_AMBER);
            fill_a(x - 1, base - h - 2, bw + 2, h + 2, C_YEL, 3);
            for (int k = 0; k < 3; k++) fill(x + k * bw / 6, base + 3 + k, bw - k * bw / 3, 1, C_YEL);
        } else if (f->act[i] < 6) {
            fill(x, base - 2, bw, 2, C_FAINT);
        } else {
            for (int y = 0; y < h; y++) fill(x, base - 1 - y, bw, 1, mix(C_TEAL, C_MAG, y, top));
            fill_a(x, base - h - 1, bw, 1, C_WHITE, 8);
        }
    }
    text(&font_small, 8, 314, "2.4 GHz", C_DIM);
    text(&font_small, 96, 314, "5 GHz", C_DIM);
    text_r(&font_small, 234, 314, f->version, C_FAINT);
}

static void dashboard(const lcd_frame_t *f) {
    background();
    header(f);
    status_pill(f);
    ap_block(f);
    tiles(f);
    spectrum(f);
}

// The radar beam (one turn in 1.6 s) leading a fading wedge.
static void sweep(int cx, int cy, int R, uint32_t t) {
    int ang = (int)(t * 256 / 1600) & 255;
    const int TRAIL = 48;
    int ya = cy - R > s_y0 ? cy - R : s_y0, yb = cy + R < s_y0 + SH ? cy + R : s_y0 + SH;
    for (int y = ya; y < yb; y++)
        for (int x = cx - R; x < cx + R; x++) {
            int dx = x - cx, dy = y - cy, d2 = dx * dx + dy * dy;
            if (d2 > R * R || d2 < 9) continue;
            int behind = (ang - iatan2(dy, dx)) & 255;
            if (behind < 2) blend(x, y, C_WHITE, 14);
            else if (behind < TRAIL) blend(x, y, C_CYAN, (TRAIL - behind) * 9 / TRAIL);
        }
}

static void splash(const lcd_frame_t *f) {
    background();
    uint32_t t = f->now - f->t0;
    const int cx = W / 2, cy = 124;
    for (int r = 34; r <= 102; r += 34) circle(cx, cy, r, 1, C_TEAL, 12);
    fill_a(cx - 104, cy, 208, 1, C_TEAL, 8);
    fill_a(cx, cy - 104, 1, 208, C_TEAL, 8);
    sweep(cx, cy, 102, t);
    circle(cx, cy, 4, 0, C_WHITE, 16);
    int hw = text_w(&font_logo, "WARDRIVE", 2);
    glow(&font_logo, (W - hw) / 2, 266, "WARDRIVE", C_TEAL, 2);
    text_ex(&font_logo, (W - hw) / 2, 266, "WARDRIVE", 2, C_CYAN, C_MAG, HORIZ, 16);
    esp_pill((W - text_w(&font_title, "ESP", 0) - 10) / 2, 274);
    char b[48];
    snprintf(b, sizeof(b), "%s  %s", f->board, f->version);
    text(&font_small, (W - text_w(&font_small, b, 0)) / 2, 314, b, C_DIM);
}

// Filled warning triangle (apex at tx, ty), edges in quarter pixels for smooth sides, with its exclamation mark.
static void warn_triangle(int tx, int ty, int th, int half, uint16_t fg, uint16_t mark) {
    for (int j = 0; j < th; j++) {
        int hw4 = (j * half * 4) / th;
        int full = hw4 / 4, part = hw4 % 4;
        fill(tx - full, ty + j, 2 * full + 1, 1, fg);
        blend(tx - full - 1, ty + j, fg, part * 4);
        blend(tx + full + 1, ty + j, fg, part * 4);
    }
    int bw = th / 9 | 1;
    rrect(tx - bw / 2, ty + th * 31 / 100, bw, th * 40 / 100, bw / 2, mark, 16);
    circle(tx, ty + th * 83 / 100, bw * 6 / 10 + 1, 0, mark, 16);
}

// The alert's color: the app's banner color, so the screen, the LED ring and the phone's banner match. Police swaps
// red and blue every blink, like the banner's light bar. [dark] = the same hue, dimmed, for the gradient's far end.
static void alert_colors(const lcd_frame_t *f, uint16_t *c, uint16_t *dark) {
    uint32_t rgb = f->alert_rgb;
    if (f->alert_police) *c = f->alert_on ? C_RED : C_BLUE;
    else *c = rgb ? RGB((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF) : C_RED;
    *dark = mix(*c, C_BLACK, 62, 100);
}

static void alert(const lcd_frame_t *f) {
    uint16_t c, dark;
    alert_colors(f, &c, &dark);
    bool lit = f->alert_on || f->alert_police;   // police lights stay lit, they swap color instead of blinking
    uint16_t fg = lit ? C_WHITE : c;
    if (lit) vgrad(0, s_y0, W, SH, mix(c, dark, s_y0, H), mix(c, dark, s_y0 + SH - 1, H));
    else { background(); vgrad(0, s_y0, W, SH, mix(dark, C_BLACK, s_y0, H), mix(dark, C_BLACK, s_y0 + SH - 1, H)); }
    rrect_line(6, 6, W - 12, H - 12, 16, 3, fg, 16);
    // warning triangle
    warn_triangle(W / 2, 62, 84, 48, fg, lit ? c : C_BLACK);
    const lcd_font_t *lf = text_w(&font_head, f->alert, 1) <= W - 28 ? &font_head : &font_title;
    text_ex(lf, (W - text_w(lf, f->alert, 1)) / 2, 202, f->alert, 1, fg, fg, SOLID, 16);
    text_ex(&font_small, (W - text_w(&font_small, "ALERT FROM THE APP", 1)) / 2, 236, "ALERT FROM THE APP", 1, fg, fg,
            SOLID, 10);
}

// ── adult-toy alert: the app's toy-shower sprite raining down a hot pink screen ──
static void sprite(const lcd_sprite_t *sp, int x, int y) {
    if (y + sp->h <= s_y0 || y >= s_y0 + SH) return;
    int ra = s_y0 - y > 0 ? s_y0 - y : 0, rb = s_y0 + SH - y < sp->h ? s_y0 + SH - y : sp->h;
    for (int row = ra; row < rb; row++)
        for (int col = 0; col < sp->w; col++) {
            int k = row * sp->w + col;
            int a = (sp->alpha[k / 2] >> ((k & 1) ? 0 : 4)) & 15;
            if (a) blend(x + col, y + row, sp->px[k], (a * 16 + 7) / 15);
        }
}

static bool is_toy(const char *label) { return strstr(label, "TOY") != NULL; }

static void toy_alert(const lcd_frame_t *f) {
    bool mini = W < 200;
    const lcd_sprite_t *sp = mini ? &spr_toy_s : &spr_toy;
    vgrad(0, s_y0, W, SH, mix(C_PINK, C_PLUM, s_y0, H), mix(C_PINK, C_PLUM, s_y0 + SH - 1, H));
    int n = mini ? 6 : 9;
    for (int k = 0; k < n; k++) {   // each one its own lane, speed and start, falling and wrapping around
        uint32_t seed = (uint32_t)(k + 1) * 2654435761u;
        int lane = (W - sp->w) * k / (n - 1);
        int x = lane + (int)((seed >> 9) % 9) - 4;
        int speed = (mini ? 45 : 90) + (int)((seed >> 15) % 70);   // px per second
        int span = H + sp->h;
        int y = (int)(((f->now + (seed >> 3) % 5000) * (uint32_t)speed / 1000) % (uint32_t)span) - sp->h;
        sprite(sp, x, y);
    }
    if (mini) {
        rrect(4, 44, W - 8, 40, 10, C_BLACK, 10);
        rrect_line(4, 44, W - 8, 40, 10, 1, C_PINK, 16);
        const lcd_font_t *lf = text_w(&font_title, f->alert, 0) <= W - 14 ? &font_title : &font_small;
        text(lf, (W - text_w(lf, f->alert, 0)) / 2, 64, f->alert, C_WHITE);
        text_ex(&font_small, (W - text_w(&font_small, "NEARBY", 1)) / 2, 79, "NEARBY", 1, C_PINK, C_PINK, SOLID, 16);
    } else {
        rrect(14, 128, W - 28, 66, 16, C_BLACK, 10);
        rrect_line(14, 128, W - 28, 66, 16, 2, C_PINK, 16);
        const lcd_font_t *lf = text_w(&font_head, f->alert, 1) <= W - 40 ? &font_head : &font_title;
        int lx = (W - text_w(lf, f->alert, 1)) / 2;
        glow(lf, lx, 164, f->alert, C_PINK, 4);
        text_ex(lf, lx, 164, f->alert, 1, C_WHITE, C_WHITE, SOLID, 16);
        text_ex(&font_small, (W - text_w(&font_small, "DETECTED NEARBY", 1)) / 2, 184, "DETECTED NEARBY", 1, C_PINK, C_PINK,
                SOLID, 16);
    }
}

// ── 128x128 ──
static uint16_t link_color(const lcd_status_t *st) { return st->usb ? C_GREEN : st->ble ? C_CYAN : C_AMBER; }

static void mini_dashboard(const lcd_frame_t *f) {
    const lcd_status_t *st = &f->st;
    char b[24];
    background();
    vgrad(0, 0, W, 19, C_HEAD0, C_HEAD1);
    text_ex(&font_title, 4, 15, "WARDRIVE", 0, C_CYAN, C_MAG, HORIZ, 16);
    hgrad(0, 19, W, 1, C_CYAN, C_MAG);
    uint16_t lc = link_color(st);   // who holds the board: green USB, cyan Bluetooth, amber pulsing when nobody
    bool linked = st->usb || st->ble;
    int pulse = linked ? 16 : (int)((f->now / 90) % 16);
    if (!linked && pulse > 8) pulse = 16 - pulse;
    circle(118, 9, 6, 0, lc, linked ? 4 : pulse / 2);
    circle(118, 9, 3, 0, lc, linked ? 16 : 8 + pulse);

    text(&font_small, 4, 32, "IN RANGE", C_DIM);
    if (f->fresh) snprintf(b, sizeof(b), "+%lu NEW", (unsigned long)f->fresh);
    else snprintf(b, sizeof(b), "%lu TOTAL", (unsigned long)f->session);
    if (text_w(&font_small, b, 0) > 124 - 64) snprintf(b, sizeof(b), "%lu", (unsigned long)(f->fresh ? f->fresh : f->session));
    text_r(&font_small, 124, 32, b, f->fresh ? C_GREEN : C_DIM);
    snprintf(b, sizeof(b), "%lu", (unsigned long)f->live);
    const lcd_font_t *nf = text_w(&font_big, b, 1) <= W - 8 ? &font_big : text_w(&font_num, b, 1) <= W - 8 ? &font_num : &font_head;
    int base = nf == &font_big ? 70 : nf == &font_num ? 66 : 62;
    glow(nf, 4, base, b, C_TEAL, 3);
    text_ex(nf, 4, base, b, 1, C_WHITE, C_CYAN, VERT, 16);

    uint16_t mc = !strcmp(st->mode, "BT") ? C_BLUE : !strcmp(st->mode, "CAP") ? C_MAG : !strcmp(st->mode, "CSI") ? C_AMBER : C_CYAN;
    const char *mode = st->mode[0] ? st->mode : "--";
    text_ex(&font_mid, 4, 93, mode, 1, mc, mc, SOLID, 16);
    int used = 4 + text_w(&font_mid, mode, 1);
    if (st->channel) {
        snprintf(b, sizeof(b), "%u", st->channel);
        text(&font_mid, used + 6, 93, b, C_WHITE);
        used += 6 + text_w(&font_mid, b, 0);
    }
    uint16_t rc = C_MAG;
    b[0] = 0;
    if (st->captures) snprintf(b, sizeof(b), "%lu CAP", (unsigned long)st->captures);
    else if (!strcmp(st->mode, "BT")) { snprintf(b, sizeof(b), "%lu BT", (unsigned long)st->bt_devices); rc = C_BLUE; }
    if (b[0] && 124 - text_w(&font_small, b, 0) > used + 6) text_r(&font_small, 124, 92, b, rc);   // only when it fits

    const int sb = 125, top = 21;
    fill(2, sb + 1, W - 4, 1, C_EDGE);
    for (int i = 0; i < LCD_ACT_N; i++) {
        int x = i < 14 ? 3 + i * 3 : 49 + (i - 14) * 27 / 10;
        int h = f->act[i] * top / 250;
        if (i == f->cur) { if (h < 4) h = 4; vgrad(x, sb - h, 2, h, C_YEL, C_AMBER); }
        else if (f->act[i] < 6) fill(x, sb - 1, 2, 1, C_FAINT);
        else for (int y = 0; y < h; y++) fill(x, sb - 1 - y, 2, 1, mix(C_TEAL, C_MAG, y, top));
    }
}

static void mini_splash(const lcd_frame_t *f) {
    background();
    const int cx = W / 2, cy = 50;
    for (int r = 15; r <= 45; r += 15) circle(cx, cy, r, 1, C_TEAL, 12);
    fill_a(cx - 46, cy, 92, 1, C_TEAL, 8);
    fill_a(cx, cy - 46, 1, 92, C_TEAL, 8);
    sweep(cx, cy, 45, f->now - f->t0);
    circle(cx, cy, 3, 0, C_WHITE, 16);
    int hw = text_w(&font_title, "WARDRIVE", 1);
    text_ex(&font_title, (W - hw) / 2, 112, "WARDRIVE", 1, C_CYAN, C_MAG, HORIZ, 16);
    text(&font_small, (W - text_w(&font_small, f->version, 0)) / 2, 126, f->version, C_DIM);
}

static void mini_alert(const lcd_frame_t *f) {
    uint16_t c, dark;
    alert_colors(f, &c, &dark);
    bool lit = f->alert_on || f->alert_police;
    uint16_t fg = lit ? C_WHITE : c;
    if (lit) vgrad(0, s_y0, W, SH, mix(c, dark, s_y0, H), mix(c, dark, s_y0 + SH - 1, H));
    else { background(); vgrad(0, s_y0, W, SH, mix(dark, C_BLACK, s_y0, H), mix(dark, C_BLACK, s_y0 + SH - 1, H)); }
    rrect_line(2, 2, W - 4, H - 4, 9, 2, fg, 16);
    warn_triangle(W / 2, 12, 50, 28, fg, lit ? c : C_BLACK);
    const lcd_font_t *lf = text_w(&font_head, f->alert, 0) <= W - 10 ? &font_head :
                           text_w(&font_title, f->alert, 0) <= W - 10 ? &font_title : &font_small;
    text(lf, (W - text_w(lf, f->alert, 0)) / 2, 94, f->alert, fg);
    text_ex(&font_small, (W - text_w(&font_small, "ALERT", 1)) / 2, 114, "ALERT", 1, fg, fg, SOLID, 10);
}

// ── firmware update: a progress ring filling cyan → magenta, a dashed ring spinning around it, the percent inside ──
enum { RING_FILL, RING_DASH };
// The band r-th..r around (cx, cy), anti-aliased. Each pixel's angle (0 at 12 o'clock, clockwise, 0-255) picks it:
// RING_FILL draws angles below `upto` (256 = all), shaded c0 → c1 along the way; RING_DASH draws 16 dashes, turned by `upto`.
static void ring(int cx, int cy, int r, int th, int kind, int upto, uint16_t c0, uint16_t c1, int a) {
    if (cy + r < s_y0 || cy - r >= s_y0 + SH) return;
    int ya = cy - r - 1 < s_y0 ? s_y0 : cy - r - 1, yb = cy + r + 1 >= s_y0 + SH ? s_y0 + SH - 1 : cy + r + 1;
    int ro = r * 8 * r * 8, ri = (r - th) * 8 * (r - th) * 8;
    int out2 = (r + 2) * (r + 2), in2 = r - th - 2 > 0 ? (r - th - 2) * (r - th - 2) : 0;
    for (int j = ya; j <= yb; j++)
        for (int i = cx - r - 1; i <= cx + r + 1; i++) {
            int dx = i - cx, dy = j - cy, d2 = dx * dx + dy * dy;
            if (d2 > out2 || d2 < in2) continue;   // only the band gets sampled
            int p = (iatan2(dy, dx) - 192) & 255;
            if (kind == RING_FILL ? p >= upto : ((p + upto) & 15) >= 9) continue;
            int n = 0;
            for (int sy = 0; sy < 4; sy++)
                for (int sx = 0; sx < 4; sx++) {
                    int ex = i * 8 + sx * 2 + 1 - cx * 8 - 4, ey = j * 8 + sy * 2 + 1 - cy * 8 - 4, d = ex * ex + ey * ey;
                    if (d <= ro && d > ri) n++;
                }
            if (n) blend(i, j, kind == RING_FILL ? mix(c0, c1, p, 255) : c0, n * a / 16);
        }
}

// The ring's colors: cyan → magenta while it fills, green pulsing once it's installing.
// `gap`: outer dashes this far out from the ring; `inner`: the inner dashes too (only where the number clears them).
static void update_ring(const lcd_frame_t *f, int cx, int cy, int r, int th, int gap, bool inner) {
    const lcd_status_t *st = &f->st;
    int pulse = (int)((f->now / 60) % 16);
    if (pulse > 8) pulse = 16 - pulse;
    ring(cx, cy, r, th, RING_FILL, 256, C_EDGE, C_EDGE, 16);                            // the track
    if (st->ota_installing) {
        ring(cx, cy, r + th / 2 + 2, th + 4, RING_FILL, 256, C_GREEN, C_GREEN, 2 + pulse / 2);   // halo
        ring(cx, cy, r, th, RING_FILL, 256, C_GREEN, C_GREEN, 10 + pulse * 3 / 4);
    } else {
        int upto = st->ota_pct * 256 / 100;
        ring(cx, cy, r + 3, th + 6, RING_FILL, upto, C_TEAL, C_PLUM, 5);                 // soft glow under the fill
        ring(cx, cy, r, th, RING_FILL, upto, C_CYAN, C_MAG, 16);
    }
    // the spinner: 16 dashes turning one way, a thinner set the other way
    ring(cx, cy, r + th / 2 + gap, 3, RING_DASH, (int)(f->now / 14), st->ota_installing ? C_GREEN : C_CYAN, 0, 9);
    if (inner) ring(cx, cy, r - th - 5, 2, RING_DASH, (int)(256 - (f->now / 22) % 256), C_TEAL, 0, 10);
}

// The percent, big, centered on (cx, base) with a small "%" after it; a smaller font when it's wider than `maxw`.
static void update_pct(const lcd_frame_t *f, const lcd_font_t *nf, const lcd_font_t *small, const lcd_font_t *pf, int cx,
                       int base, int maxw) {
    char b[8];
    snprintf(b, sizeof(b), "%u", f->st.ota_pct);
    int pw = text_w(pf, "%", 0);
    if (text_w(nf, b, 1) + 3 + pw > maxw) { base -= (nf->ascent - small->ascent) / 2; nf = small; }
    int nw = text_w(nf, b, 1), x = cx - (nw + 3 + pw) / 2;
    uint16_t top = f->st.ota_installing ? C_GREEN : C_WHITE, bottom = f->st.ota_installing ? C_GREEN : C_CYAN;
    glow(nf, x, base, b, f->st.ota_installing ? C_GREEN : C_TEAL, 3);
    text_ex(nf, x, base, b, 1, top, bottom, VERT, 16);
    text(pf, x + nw + 3, base, "%", f->st.ota_installing ? C_GREEN : C_MAG);
}

// "KEEP POWER ON" breathing in amber (the one thing to know), "RESTARTS BY ITSELF" in green once installing.
static void update_warning(const lcd_frame_t *f, const lcd_font_t *wf, int base) {
    const char *s = f->st.ota_installing ? "RESTARTS BY ITSELF" : "KEEP POWER ON";
    if (text_w(wf, s, 1) > W - 6) s = f->st.ota_installing ? "RESTARTING" : "POWER ON";
    int breathe = (int)((f->now / 70) % 16);
    if (breathe > 8) breathe = 16 - breathe;
    uint16_t c = f->st.ota_installing ? C_GREEN : C_AMBER;
    int x = (W - text_w(wf, s, 1)) / 2;
    glow(wf, x, base, s, c, 1 + breathe / 4);
    text_ex(wf, x, base, s, 1, c, c, SOLID, 9 + breathe * 7 / 8);
}

// A data stream along a row: packets of four blocks running left to right while bytes arrive.
static void update_stream(const lcd_frame_t *f, int y, int x0, int x1, int bs) {
    if (f->st.ota_installing) return;
    int step = bs * 6, off = (int)((f->now / 10) % (uint32_t)step);
    for (int x = x0 - step + off; x < x1; x += step)
        for (int k = 0; k < 4; k++) {
            int xx = x + k * (bs + 2);
            if (xx >= x0 && xx + bs <= x1) fill_a(xx, y, bs, bs, k == 3 ? C_WHITE : C_CYAN, 3 + k * 4);
        }
}

static void update_scene(const lcd_frame_t *f) {
    const lcd_status_t *st = &f->st;
    background();
    header(f);
    const char *title = st->ota_installing ? "INSTALLING" : "FIRMWARE UPDATE";
    int tw = text_w(&font_title, title, 2);
    text_ex(&font_title, (W - tw) / 2, 72, title, 2, C_CYAN, C_MAG, HORIZ, 16);
    const int cx = W / 2, cy = 168;
    update_ring(f, cx, cy, 70, 12, 8, true);
    update_pct(f, &font_big, &font_num, &font_head, cx, cy + 18, 2 * (70 - 12 - 5 - 2 - 6));   // clears the inner dashes
    char b[32];
    if (st->ota_installing) snprintf(b, sizeof(b), "CHECKING THE IMAGE");
    else snprintf(b, sizeof(b), "%lu / %lu KB", (unsigned long)st->ota_kb, (unsigned long)st->ota_total_kb);
    text_ex(&font_small, (W - text_w(&font_small, b, 1)) / 2, 270, b, 1, C_DIM, C_DIM, SOLID, 16);
    update_warning(f, &font_title, 296);
    update_stream(f, 308, 12, W - 12, 4);
}

static void mini_update(const lcd_frame_t *f) {
    const lcd_status_t *st = &f->st;
    background();
    vgrad(0, 0, W, 19, C_HEAD0, C_HEAD1);
    const char *title = st->ota_installing ? "INSTALLING" : "UPDATING";
    text_ex(&font_title, (W - text_w(&font_title, title, 1)) / 2, 15, title, 1, C_CYAN, C_MAG, HORIZ, 16);
    hgrad(0, 19, W, 1, C_CYAN, C_MAG);
    const int cx = W / 2, cy = 63;
    update_ring(f, cx, cy, 33, 7, 5, false);   // no inner dashes: the number fills the ring
    update_pct(f, &font_num, &font_mid, &font_small, cx, cy + 11, 2 * (33 - 7 - 3));
    update_warning(f, &font_small, 120);
    update_stream(f, 124, 8, W - 8, 2);
}

// ── public ──
int lcd_act_index(uint8_t ch) {
    if (ch >= 1 && ch <= 14) return ch - 1;
    if (ch >= 36 && ch <= 64) return 14 + (ch - 36) / 4;            // 36..64: 8
    if (ch >= 100 && ch <= 144) return 22 + (ch - 100) / 4;         // 100..144: 12
    if (ch >= 149 && ch <= 177) return 34 + (ch - 149) / 4;         // 149..177: 8
    return -1;
}

void lcd_draw_strip(uint16_t *strip, int y0, const lcd_frame_t *f) {
    s_px = strip;
    s_y0 = y0;
    s_w = f->w;
    s_h = f->h;
    bool mini = s_w < 200;
    if (f->st.ota) mini ? mini_update(f) : update_scene(f);
    else if (f->alerting && is_toy(f->alert)) toy_alert(f);
    else if (f->alerting) mini ? mini_alert(f) : alert(f);
    else if (f->now - f->t0 < 2200) mini ? mini_splash(f) : splash(f);
    else mini ? mini_dashboard(f) : dashboard(f);
}
