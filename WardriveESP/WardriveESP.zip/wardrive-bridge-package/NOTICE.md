# Notice

WardriveESP is original software under the MIT license. It contains no GhostESP source code; its BLE UUIDs, frame
layout and `WD:AP` line format match GhostESP's GhostLink bridge for interoperability only.

Third-party: ESP-IDF (NimBLE, esp_wifi), Apache-2.0, © Espressif Systems.
